import React, { useState } from "react";
import {
  LanguageProvider,
  useLanguage,
} from "./contexts/LanguageContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { Auth } from "./components/Auth";
import { Header } from "./components/Header";
import { Dashboard } from "./components/Dashboard";
import { CaseForm } from "./components/CaseForm";
import { CaseDetail } from "./components/CaseDetail";
import { ModelingExpertDashboard } from "./components/ModelingExpertDashboard";
import { SupervisorDashboard } from "./components/SupervisorDashboard";
import { PlatformOperatorDashboard } from "./components/PlatformOperatorDashboard";
import { PatientManagement } from "./components/PatientManagement";
import { CaseHistory } from "./components/CaseHistory";
import { AccountManagement } from "./components/AccountManagement";
import { FinancialManagement } from "./components/FinancialManagement";
import { UserProfile } from "./components/UserProfile";
import { AsnanLabsLogo } from "./components/AsnanLabsLogo";
import { Card } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./components/ui/tabs";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "./components/ui/avatar";
import { ScrollArea } from "./components/ui/scroll-area";
import {
  Clock,
  CheckCircle,
  AlertTriangle,
  Building,
  Loader2,
  Shield,
  Crown,
  Mail,
} from "lucide-react";
import { User, Case } from "./types";
import { mockUsers, mockCases } from "./data/mockData";
import { formatDate, getDaysUntilDue } from "./utils/dateUtils";

type ViewType =
  | "dashboard"
  | "create-case"
  | "case-detail"
  | "lab-queue"
  | "patient-management"
  | "case-history"
  | "account-management"
  | "financial-management"
  | "user-profile";

// Pending Account Screen Component
function PendingAccountScreen({ user }: { user: User }) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6">
      <div className="mb-8">
        <AsnanLabsLogo
          width={200}
          height={60}
          color="#030213"
          className="text-gray-900"
        />
      </div>

      <Card className="w-full max-w-md shadow-xl">
        <div className="p-8 text-center">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Account Pending Approval
          </h2>

          <div className="space-y-4 text-gray-600">
            <p>
              Thank you for registering with DentalLab Connect.
              Your account is currently under review by our
              administrators.
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-left">
                  <h3 className="font-medium text-blue-900 mb-1">
                    What happens next?
                  </h3>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>
                      • Our team will verify your professional
                      credentials
                    </li>
                    <li>
                      • License documentation will be reviewed
                    </li>
                    <li>
                      • You'll receive an email notification
                      once approved
                    </li>
                    <li>
                      • Access will be granted based on your
                      professional role
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t">
              <p className="text-sm">
                Account registered on:{" "}
                {formatDate(user.registrationDate)}
              </p>
              <p className="text-sm mt-1">
                Status:{" "}
                <Badge className="bg-yellow-100 text-yellow-800 ml-1">
                  Pending Review
                </Badge>
              </p>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => window.location.reload()}
            >
              <Clock className="w-4 h-4 mr-2" />
              Check Status
            </Button>

            <div className="text-xs text-gray-500">
              Need help? Contact us at{" "}
              <a
                href="mailto:support@asnanlabs.com"
                className="text-blue-600 hover:underline"
              >
                support@asnanlabs.com
              </a>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

// Rejected Account Screen Component
function RejectedAccountScreen({
  message,
}: {
  message: string;
}) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6">
      <div className="mb-8">
        <AsnanLabsLogo
          width={200}
          height={60}
          color="#030213"
          className="text-gray-900"
        />
      </div>

      <Card className="w-full max-w-md shadow-xl">
        <div className="p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Account Not Approved
          </h2>

          <div className="space-y-4 text-gray-600">
            <p>
              Unfortunately, your account registration could not
              be approved at this time.
            </p>

            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-left">
              <h3 className="font-medium text-red-900 mb-2">
                Reason:
              </h3>
              <p className="text-sm text-red-700">{message}</p>
            </div>

            <p className="text-sm">
              If you believe this is an error or would like to
              reapply, please contact our support team.
            </p>
          </div>

          <div className="mt-6 space-y-3">
            <Button variant="outline" className="w-full">
              <Mail className="w-4 h-4 mr-2" />
              Contact Support
            </Button>

            <div className="text-xs text-gray-500">
              Email us at{" "}
              <a
                href="mailto:support@asnanlabs.com"
                className="text-blue-600 hover:underline"
              >
                support@asnanlabs.com
              </a>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function AppContent() {
  const { t } = useLanguage();
  const { user, logout, isLoading, isAuthenticated } =
    useAuth();
  const [currentView, setCurrentView] =
    useState<ViewType>("dashboard");
  const [selectedCaseId, setSelectedCaseId] =
    useState<string>("");
  const [cases, setCases] = useState<Case[]>(mockCases);

  // Show loading screen during authentication check
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Show authentication pages if not logged in
  if (!isAuthenticated || !user) {
    return <Auth />;
  }

  // Handle account status checks
  if (user.status === "pending") {
    return <PendingAccountScreen user={user} />;
  }

  if (user.status === "rejected") {
    const rejectionMessage =
      "Your professional credentials could not be verified. Please ensure all license documents are valid and up to date.";
    return <RejectedAccountScreen message={rejectionMessage} />;
  }

  // Only approved users can access the main application
  if (user.status !== "approved") {
    return <PendingAccountScreen user={user} />;
  }

  const switchRole = (targetRole?: string) => {
    // For demo purposes, allow role switching
    // In production, this would not be available
    if (targetRole) {
      const targetUser = mockUsers.find(
        (u) => u.role === targetRole,
      );
      if (targetUser) {
        // Note: This is demo functionality only
        // In production, role switching should not be possible
        console.log("Demo: Switching to role", targetRole);
        return;
      }
    }

    // For demo - cycle through roles
    const roles = [
      "dentist",
      "lab",
      "supervisor",
      "designer",
      "owner",
    ];
    const currentRoleIndex = roles.indexOf(user.role);
    const nextRoleIndex = (currentRoleIndex + 1) % roles.length;
    const nextRole = roles[nextRoleIndex];

    console.log("Demo: Would switch to", nextRole);
    // In production, this would not be possible
  };

  const handleCreateCase = () => {
    setCurrentView("create-case");
  };

  const handleViewCase = (caseId: string) => {
    setSelectedCaseId(caseId);
    setCurrentView("case-detail");
  };

  const handleCaseSubmit = (caseData: Partial<Case>) => {
    // Ensure minimum 3-day due date
    const minDueDate = new Date();
    minDueDate.setDate(minDueDate.getDate() + 3);

    const newCase = {
      ...caseData,
      id: Date.now().toString(),
      dueDate:
        caseData.dueDate && caseData.dueDate > minDueDate
          ? caseData.dueDate
          : minDueDate,
      workHistory: [
        {
          id: `${Date.now()}-1`,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: "Case Created",
          description: "Initial case submission",
          timestamp: new Date(),
          hoursSpent: 0.5,
        },
      ],
    } as Case;

    setCases((prev) => [newCase, ...prev]);
    setCurrentView("dashboard");
  };

  const handlePatientManagement = () => {
    setCurrentView("patient-management");
  };

  const handleCaseHistory = () => {
    setCurrentView("case-history");
  };

  const handleAccountManagement = () => {
    setCurrentView("account-management");
  };

  const handleFinancialManagement = () => {
    setCurrentView("financial-management");
  };

  const handleViewProfile = () => {
    setCurrentView("user-profile");
  };

  // Lab Case Card Component - moved inside to access useLanguage
  const LabCaseCard = ({
    caseItem,
    onViewCase,
    onAcceptCase,
    isAssigned = false,
  }: {
    caseItem: Case;
    onViewCase: (caseId: string) => void;
    onAcceptCase?: (caseId: string) => void;
    isAssigned?: boolean;
  }) => {
    const getStatusColor = (status: Case["status"]) => {
      const colors = {
        draft: "bg-gray-500",
        submitted: "bg-blue-500",
        assigned: "bg-purple-500",
        in_progress: "bg-yellow-500",
        quality_check: "bg-orange-500",
        completed: "bg-green-500",
        delivered: "bg-emerald-500",
      };
      return colors[status];
    };

    const getPriorityColor = (priority: Case["priority"]) => {
      const colors = {
        low: "border-green-200 bg-green-50",
        medium: "border-yellow-200 bg-yellow-50",
        high: "border-orange-200 bg-orange-50",
        urgent: "border-red-200 bg-red-50",
      };
      return colors[priority];
    };

    const daysUntilDue = getDaysUntilDue(caseItem.dueDate);

    return (
      <Card
        className={`p-6 border-l-4 ${getPriorityColor(caseItem.priority)}`}
      >
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-semibold text-lg">
              {caseItem.title}
            </h3>
            <p className="text-gray-600">
              {t("patient")}: {caseItem.patient.name}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              className={`${getStatusColor(caseItem.status)} text-white`}
            >
              {t(caseItem.status.replace("_", " "))}
            </Badge>
            <Badge variant="outline" className="capitalize">
              {t(caseItem.priority)}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={caseItem.dentist.avatar} />
              <AvatarFallback>
                {caseItem.dentist.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">
                {caseItem.dentist.name}
              </p>
              <p className="text-sm text-gray-600">
                {caseItem.dentist.practice}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600">
              {t("due_in")} {daysUntilDue} {t("days")} (
              {formatDate(caseItem.dueDate)})
            </span>
          </div>
        </div>

        <p className="text-gray-700 mb-4">
          {caseItem.description}
        </p>

        {caseItem.instructions && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded">
            <h4 className="font-medium text-blue-900 mb-1">
              {t("lab_instructions")}
            </h4>
            <p className="text-blue-800 text-sm">
              {caseItem.instructions}
            </p>
          </div>
        )}

        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span className="capitalize">
              {t(caseItem.type)}
            </span>
            <span>•</span>
            <span>
              {t("created")} {formatDate(caseItem.createdAt)}
            </span>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => onViewCase(caseItem.id)}
            >
              {t("view_details")}
            </Button>
            {!isAssigned && onAcceptCase && (
              <Button onClick={() => onAcceptCase(caseItem.id)}>
                {t("accept_case")}
              </Button>
            )}
          </div>
        </div>
      </Card>
    );
  };

  const renderLabQueue = () => {
    const unassignedCases = cases.filter(
      (c) => c.status === "submitted" && !c.lab,
    );
    const assignedCases = cases.filter(
      (c) => c.lab?.id === user.id,
    );

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">
            {t("lab_queue")}
          </h1>
          <p className="text-gray-600 mt-1">
            {t("manage_cases")}
          </p>
        </div>

        <Tabs defaultValue="unassigned" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="unassigned">
              {t("available_cases")} ({unassignedCases.length})
            </TabsTrigger>
            <TabsTrigger value="assigned">
              {t("my_cases")} ({assignedCases.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="unassigned" className="mt-6">
            <ScrollArea className="h-[calc(100vh-350px)]">
              <div className="grid gap-4 pr-4">
                {unassignedCases.length > 0 ? (
                  unassignedCases.map((caseItem) => (
                    <LabCaseCard
                      key={caseItem.id}
                      caseItem={caseItem}
                      onViewCase={handleViewCase}
                      onAcceptCase={(caseId) => {
                        const caseToUpdate = cases.find(
                          (c) => c.id === caseId,
                        );
                        if (caseToUpdate) {
                          setCases((prev) =>
                            prev.map((c) =>
                              c.id === caseId
                                ? {
                                    ...c,
                                    lab: user,
                                    status:
                                      "assigned" as Case["status"],
                                  }
                                : c,
                            ),
                          );
                        }
                      }}
                    />
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">
                      {t("no_available_cases")}
                    </h3>
                    <p className="text-gray-600">
                      {t("all_submitted_assigned")}
                    </p>
                  </Card>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="assigned" className="mt-6">
            <ScrollArea className="h-[calc(100vh-350px)]">
              <div className="grid gap-4 pr-4">
                {assignedCases.length > 0 ? (
                  assignedCases.map((caseItem) => (
                    <LabCaseCard
                      key={caseItem.id}
                      caseItem={caseItem}
                      onViewCase={handleViewCase}
                      isAssigned
                    />
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">
                      {t("no_assigned_cases")}
                    </h3>
                    <p className="text-gray-600">
                      {t("accept_cases_queue")}
                    </p>
                  </Card>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    );
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <Header
        currentUser={user}
        onSwitchRole={switchRole}
        onViewCase={handleViewCase}
        onViewProfile={handleViewProfile}
        onLogout={logout}
      />

      <main className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <div className="container mx-auto px-6 py-8">
            {currentView === "dashboard" && (
              <>
                {user.role === "lab" && renderLabQueue()}
                {user.role === "dentist" && (
                  <Dashboard
                    currentUser={user}
                    onCreateCase={handleCreateCase}
                    onViewCase={handleViewCase}
                    onPatientManagement={
                      handlePatientManagement
                    }
                    onCaseHistory={handleCaseHistory}
                  />
                )}
                {user.role === "designer" && (
                  <ModelingExpertDashboard
                    currentUser={user}
                    onViewCase={handleViewCase}
                  />
                )}
                {user.role === "supervisor" && (
                  <SupervisorDashboard
                    currentUser={user}
                    onViewCase={handleViewCase}
                    onCaseHistory={handleCaseHistory}
                  />
                )}
                {user.role === "owner" && (
                  <PlatformOperatorDashboard
                    currentUser={user}
                    onViewCase={handleViewCase}
                    onCaseHistory={handleCaseHistory}
                    onAccountManagement={
                      handleAccountManagement
                    }
                    onFinancialManagement={
                      handleFinancialManagement
                    }
                  />
                )}
              </>
            )}

            {currentView === "create-case" && (
              <CaseForm
                currentUser={user}
                onClose={() => setCurrentView("dashboard")}
                onSubmit={handleCaseSubmit}
              />
            )}

            {currentView === "case-detail" && (
              <CaseDetail
                caseId={selectedCaseId}
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
              />
            )}

            {currentView === "patient-management" && (
              <PatientManagement
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
              />
            )}

            {currentView === "case-history" && (
              <CaseHistory
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
                onViewCase={handleViewCase}
              />
            )}

            {currentView === "account-management" && (
              <AccountManagement
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
              />
            )}

            {currentView === "financial-management" && (
              <FinancialManagement
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
              />
            )}

            {currentView === "user-profile" && (
              <UserProfile
                currentUser={user}
                onBack={() => setCurrentView("dashboard")}
              />
            )}
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;