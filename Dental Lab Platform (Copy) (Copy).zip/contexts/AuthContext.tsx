import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AccountRequest } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; status?: string; message?: string }>;
  signup: (userData: SignupData) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  isLoading: boolean;
  isAuthenticated: boolean;
  accountRequests: AccountRequest[];
  approveAccount: (requestId: string, assignedRole: string, notes?: string) => Promise<boolean>;
  rejectAccount: (requestId: string, notes: string) => Promise<boolean>;
  getPendingRequests: () => AccountRequest[];
}

export interface SignupData {
  // Basic Info
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone: string;
  
  // Professional Info
  profession: string;
  organization: string;
  experience: string;
  specializations: string[];
  
  // Location
  country: string;
  city: string;
  
  // Role Determination
  primaryActivity: string;
  businessType: string;
  teamSize: string;
  serviceOffering: string;
  
  // License Information
  licenseNumber: string;
  issuingAuthority: string;
  licenseExpiry: string;
  licenseDocuments: string[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Mock approved users database with specific demo emails
const mockApprovedUsers: Array<User & { email: string; password: string }> = [
  // DENTIST ACCOUNT
  {
    id: '1',
    name: 'Dr. Ahmed Salem',
    email: 'ALD@gmail.com',
    password: '1234',
    role: 'dentist',
    avatar: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=100&h=100&fit=crop&crop=face',
    practice: 'Salem Dental Clinic',
    specialization: 'General Dentistry',
    location: 'Dubai, UAE',
    status: 'approved',
    approvedBy: 'ALO@gmail.com',
    approvalDate: new Date('2024-01-15'),
    registrationDate: new Date('2024-01-10')
  },
  
  // LAB ACCOUNT
  {
    id: '2',
    name: 'Advanced Dental Lab',
    email: 'ALL@gmail.com',
    password: '1234',
    role: 'lab',
    avatar: 'https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?w=100&h=100&fit=crop&crop=center',
    practice: 'Advanced Dental Laboratory',
    specialization: 'Crown & Bridge Manufacturing',
    location: 'Sharjah, UAE',
    status: 'approved',
    approvedBy: 'ALO@gmail.com',
    approvalDate: new Date('2024-01-20'),
    registrationDate: new Date('2024-01-18')
  },
  
  // DESIGNER ACCOUNT
  {
    id: '3',
    name: 'Sarah Al-Mansouri',
    email: 'ALM@gmail.com',
    password: '1234',
    role: 'designer',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
    practice: 'Al-Mansouri Digital Design Studio',
    specialization: 'CAD Design & Digital Modeling',
    location: 'Dubai, UAE',
    status: 'approved',
    approvedBy: 'ALO@gmail.com',
    approvalDate: new Date('2024-01-25'),
    registrationDate: new Date('2024-01-22')
  },
  
  // SUPERVISOR ACCOUNT
  {
    id: '4',
    name: 'Dr. Khalid Al-Zahra',
    email: 'ALS@gmail.com',
    password: '1234',
    role: 'supervisor',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    practice: 'Regional Quality Control Center',
    specialization: 'Quality Assurance & Team Management',
    location: 'Dubai Healthcare City, UAE',
    status: 'approved',
    approvedBy: 'ALO@gmail.com',
    approvalDate: new Date('2024-02-01'),
    registrationDate: new Date('2024-01-28')
  },
  
  // OWNER ACCOUNT
  {
    id: '5',
    name: 'Dr. Hassan Al-Mahmoud',
    email: 'ALO@gmail.com',
    password: '1234',
    role: 'owner',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop&crop=face',
    practice: 'DentalLab Connect Platform',
    specialization: 'Platform Operations & Strategy',
    location: 'Dubai International Financial Centre',
    status: 'approved',
    approvedBy: 'system',
    approvalDate: new Date('2024-01-01'),
    registrationDate: new Date('2024-01-01')
  }
];

// Mock pending account requests
const mockAccountRequests: AccountRequest[] = [
  {
    id: 'req-1',
    user: {
      id: 'pending-1',
      name: 'Dr. Maryam Al-Rashid',
      email: 'maryam.rashid@email.com',
      role: 'dentist',
      avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&h=100&fit=crop&crop=face',
      practice: 'Al-Rashid Orthodontics Center',
      specialization: 'Orthodontics',
      location: 'Riyadh, Saudi Arabia',
      status: 'pending',
      registrationDate: new Date('2024-02-10'),
      licenseInfo: {
        licenseNumber: 'SCFHS-2024-0892',
        issuingAuthority: 'Saudi Commission for Health Specialties',
        expiryDate: new Date('2025-12-31'),
        documents: ['license-scan.pdf', 'specialization-cert.pdf']
      }
    },
    requestedRole: 'dentist',
    submittedAt: new Date('2024-02-10'),
    status: 'pending',
    licenseDocuments: ['license-scan.pdf', 'specialization-cert.pdf']
  },
  {
    id: 'req-2',
    user: {
      id: 'pending-2',
      name: 'Elite Dental Lab LLC',
      email: 'info@elitedental.ae',
      role: 'lab',
      avatar: 'https://images.unsplash.com/photo-1628595351029-c2bf17511435?w=100&h=100&fit=crop&crop=center',
      practice: 'Elite Dental Laboratory',
      specialization: 'Digital Prosthetics & CAD/CAM',
      location: 'Abu Dhabi, UAE',
      status: 'pending',
      registrationDate: new Date('2024-02-12'),
      licenseInfo: {
        licenseNumber: 'DHA-LAB-2024-156',
        issuingAuthority: 'Dubai Health Authority',
        expiryDate: new Date('2026-03-15'),
        documents: ['business-license.pdf', 'health-permit.pdf', 'iso-cert.pdf']
      }
    },
    requestedRole: 'lab',
    submittedAt: new Date('2024-02-12'),
    status: 'pending',
    licenseDocuments: ['business-license.pdf', 'health-permit.pdf', 'iso-cert.pdf']
  },
  {
    id: 'req-3',
    user: {
      id: 'pending-3',
      name: 'Ahmed Al-Qassimi',
      email: 'ahmed.qassimi@designstudio.com',
      role: 'designer',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
      practice: 'Digital Smile Design Studio',
      specialization: 'CAD Design & 3D Modeling',
      location: 'Sharjah, UAE',
      status: 'pending',
      registrationDate: new Date('2024-02-14'),
      licenseInfo: {
        licenseNumber: 'CIDA-2024-445',
        issuingAuthority: 'Certified International Dental Assistants',
        expiryDate: new Date('2025-08-20'),
        documents: ['cad-certification.pdf', 'portfolio.pdf']
      }
    },
    requestedRole: 'designer',
    submittedAt: new Date('2024-02-14'),
    status: 'pending',
    licenseDocuments: ['cad-certification.pdf', 'portfolio.pdf']
  }
];

const determineUserRole = (data: SignupData): User['role'] => {
  // Platform Owner - indicated by business management focus
  if (data.primaryActivity === 'platform_management' || 
      data.businessType === 'platform_operator' ||
      data.serviceOffering === 'platform_services') {
    return 'owner';
  }
  
  // Lab - indicated by laboratory services
  if (data.profession === 'dental_technician' ||
      data.businessType === 'dental_laboratory' ||
      data.serviceOffering === 'prosthetic_manufacturing' ||
      data.primaryActivity === 'laboratory_work') {
    return 'lab';
  }
  
  // Designer/Modeling Expert - indicated by CAD/design focus
  if (data.profession === 'cad_designer' ||
      data.specializations.includes('digital_design') ||
      data.primaryActivity === 'digital_modeling' ||
      data.serviceOffering === 'design_services') {
    return 'designer';
  }
  
  // Supervisor - indicated by management/quality control
  if (data.profession === 'quality_manager' ||
      data.primaryActivity === 'quality_control' ||
      data.serviceOffering === 'supervision_services' ||
      (data.experience === 'senior' && data.teamSize === 'large_team')) {
    return 'supervisor';
  }
  
  // Default to dentist for dental professionals
  if (data.profession === 'dentist' ||
      data.profession === 'oral_surgeon' ||
      data.profession === 'orthodontist' ||
      data.profession === 'prosthodontist') {
    return 'dentist';
  }
  
  // Fallback to dentist
  return 'dentist';
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [accountRequests, setAccountRequests] = useState<AccountRequest[]>(mockAccountRequests);

  // Check for stored user session on app start
  useEffect(() => {
    const storedUser = localStorage.getItem('dentallab_user');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUser(userData);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('dentallab_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; status?: string; message?: string }> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check against approved users first
    const foundUser = mockApprovedUsers.find(u => u.email === email && u.password === password);
    
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('dentallab_user', JSON.stringify(userWithoutPassword));
      setIsLoading(false);
      return { success: true };
    }
    
    // Check if user is in pending requests
    const pendingRequest = accountRequests.find(req => 
      req.user.email === email && 
      req.status === 'pending'
    );
    
    if (pendingRequest) {
      setIsLoading(false);
      return { 
        success: false, 
        status: 'pending', 
        message: 'Your account is pending approval. Please wait for administrator review.' 
      };
    }
    
    // Check if user was rejected
    const rejectedRequest = accountRequests.find(req => 
      req.user.email === email && 
      req.status === 'rejected'
    );
    
    if (rejectedRequest) {
      setIsLoading(false);
      return { 
        success: false, 
        status: 'rejected', 
        message: `Your account was rejected. Reason: ${rejectedRequest.notes || 'Please contact support for more information.'}` 
      };
    }
    
    setIsLoading(false);
    return { success: false, message: 'Invalid email or password' };
  };

  const signup = async (userData: SignupData): Promise<{ success: boolean; message?: string }> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Check if email already exists in approved users or pending requests
    const emailExists = mockApprovedUsers.some(u => u.email === userData.email) ||
                       accountRequests.some(req => req.user.email === userData.email);
    
    if (emailExists) {
      setIsLoading(false);
      return { success: false, message: 'Email already registered' };
    }
    
    // Determine suggested role based on signup data
    const suggestedRole = determineUserRole(userData);
    
    // Create new account request (pending approval)
    const newAccountRequest: AccountRequest = {
      id: `req-${Date.now()}`,
      user: {
        id: `pending-${Date.now()}`,
        name: `${userData.firstName} ${userData.lastName}`,
        role: suggestedRole,
        avatar: `https://ui-avatars.com/api/?name=${userData.firstName}+${userData.lastName}&background=2563eb&color=fff&size=100`,
        practice: userData.organization,
        specialization: userData.specializations.join(', ') || userData.profession,
        location: `${userData.city}, ${userData.country}`,
        status: 'pending',
        registrationDate: new Date(),
        licenseInfo: {
          licenseNumber: userData.licenseNumber,
          issuingAuthority: userData.issuingAuthority,
          expiryDate: new Date(userData.licenseExpiry),
          documents: userData.licenseDocuments
        },
        email: userData.email
      } as User & { email: string },
      requestedRole: suggestedRole,
      submittedAt: new Date(),
      status: 'pending',
      licenseDocuments: userData.licenseDocuments
    };
    
    // Add to pending requests
    setAccountRequests(prev => [newAccountRequest, ...prev]);
    
    setIsLoading(false);
    return { 
      success: true, 
      message: 'Account registration submitted successfully. You will receive a notification once approved.' 
    };
  };

  const approveAccount = async (requestId: string, assignedRole: string, notes?: string): Promise<boolean> => {
    const request = accountRequests.find(req => req.id === requestId);
    if (!request) return false;
    
    // Create approved user
    const approvedUser: User & { email: string; password: string } = {
      ...request.user,
      role: assignedRole as User['role'],
      status: 'approved',
      approvedBy: user?.id || 'system',
      approvalDate: new Date(),
      password: '1234' // Default password for approved accounts
    };
    
    // Add to approved users
    mockApprovedUsers.push(approvedUser);
    
    // Update request status
    setAccountRequests(prev => prev.map(req => 
      req.id === requestId 
        ? { 
            ...req, 
            status: 'approved',
            reviewedAt: new Date(),
            reviewedBy: user?.id,
            notes 
          }
        : req
    ));
    
    return true;
  };

  const rejectAccount = async (requestId: string, notes: string): Promise<boolean> => {
    setAccountRequests(prev => prev.map(req => 
      req.id === requestId 
        ? { 
            ...req, 
            status: 'rejected',
            reviewedAt: new Date(),
            reviewedBy: user?.id,
            notes 
          }
        : req
    ));
    
    return true;
  };

  const getPendingRequests = () => {
    return accountRequests.filter(req => req.status === 'pending');
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('dentallab_user');
  };

  const value: AuthContextType = {
    user,
    login,
    signup,
    logout,
    isLoading,
    isAuthenticated: !!user,
    accountRequests,
    approveAccount,
    rejectAccount,
    getPendingRequests
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};