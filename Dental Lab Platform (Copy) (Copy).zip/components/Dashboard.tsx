import React, { useState } from 'react';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';
import { Plus, Eye, MessageSquare, Clock, CheckCircle, AlertCircle, Users, History } from 'lucide-react';
import { Case, User } from '../types';
import { mockCases, mockUsers } from '../data/mockData';
import { useLanguage } from '../contexts/LanguageContext';

interface DashboardProps {
  currentUser: User;
  onCreateCase: () => void;
  onViewCase: (caseId: string) => void;
  onPatientManagement?: () => void;
  onCaseHistory?: () => void;
}

export function Dashboard({ currentUser, onCreateCase, onViewCase, onPatientManagement, onCaseHistory }: DashboardProps) {
  const { t, isRTL } = useLanguage();
  const [cases] = useState<Case[]>(mockCases);

  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'border-green-200 bg-green-50',
      medium: 'border-yellow-200 bg-yellow-50',
      high: 'border-orange-200 bg-orange-50',
      urgent: 'border-red-200 bg-red-50'
    };
    return colors[priority];
  };

  const getProgressPercentage = (caseItem: Case) => {
    if (caseItem.progress.length === 0) return 0;
    const completed = caseItem.progress.filter(step => step.status === 'completed').length;
    return (completed / caseItem.progress.length) * 100;
  };

  const getUserCases = () => {
    if (currentUser.role === 'dentist') {
      return cases.filter(c => c.dentist.id === currentUser.id);
    } else {
      return cases.filter(c => c.lab?.id === currentUser.id);
    }
  };

  const getStatsCards = () => {
    const userCases = getUserCases();
    const totalCases = userCases.length;
    const activeCases = userCases.filter(c => ['submitted', 'assigned', 'in_progress', 'quality_check'].includes(c.status)).length;
    const completedCases = userCases.filter(c => c.status === 'completed').length;
    const urgentCases = userCases.filter(c => c.priority === 'urgent').length;

    return [
      { title: t('total_cases'), value: totalCases, icon: Eye, color: 'text-blue-600' },
      { title: t('active_cases'), value: activeCases, icon: Clock, color: 'text-yellow-600' },
      { title: t('completed'), value: completedCases, icon: CheckCircle, color: 'text-green-600' },
      { title: t('urgent'), value: urgentCases, icon: AlertCircle, color: 'text-red-600' }
    ];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={isRTL ? 'text-right' : 'text-left'}>
          <h1 className="text-3xl font-bold">{t('welcome_back')}، {currentUser.name}</h1>
          <p className="text-gray-600 mt-1">{t('happening_today')}</p>
        </div>
        {currentUser.role === 'dentist' && (
          <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            {onPatientManagement && (
              <Button variant="outline" onClick={onPatientManagement} className={`gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Users className="w-4 h-4" />
                {t('patients')}
              </Button>
            )}
            {onCaseHistory && (
              <Button variant="outline" onClick={onCaseHistory} className={`gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <History className="w-4 h-4" />
                {t('history')}
              </Button>
            )}
            <Button onClick={onCreateCase} className={`gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Plus className="w-4 h-4" />
              {t('new_case')}
            </Button>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {getStatsCards().map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="p-6">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className={isRTL ? 'text-right' : 'text-left'}>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold mt-2">{stat.value}</p>
                </div>
                <Icon className={`w-8 h-8 ${stat.color}`} />
              </div>
            </Card>
          );
        })}
      </div>

      {/* Cases */}
      <Card className="p-6">
        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="active">{t('active_cases_tab')}</TabsTrigger>
            <TabsTrigger value="completed">{t('completed_tab')}</TabsTrigger>
            <TabsTrigger value="all">{t('all_cases')}</TabsTrigger>
            <TabsTrigger value="urgent">{t('urgent_tab')}</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="mt-6">
            <div className="space-y-4">
              {getUserCases()
                .filter(c => ['submitted', 'assigned', 'in_progress', 'quality_check'].includes(c.status))
                .map((caseItem) => (
                  <CaseCard key={caseItem.id} caseItem={caseItem} onViewCase={onViewCase} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <div className="space-y-4">
              {getUserCases()
                .filter(c => c.status === 'completed' || c.status === 'delivered')
                .map((caseItem) => (
                  <CaseCard key={caseItem.id} caseItem={caseItem} onViewCase={onViewCase} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="all" className="mt-6">
            <div className="space-y-4">
              {getUserCases().map((caseItem) => (
                <CaseCard key={caseItem.id} caseItem={caseItem} onViewCase={onViewCase} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="urgent" className="mt-6">
            <div className="space-y-4">
              {getUserCases()
                .filter(c => c.priority === 'urgent')
                .map((caseItem) => (
                  <CaseCard key={caseItem.id} caseItem={caseItem} onViewCase={onViewCase} />
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

function CaseCard({ caseItem, onViewCase }: { caseItem: Case; onViewCase: (caseId: string) => void }) {
  const { t, isRTL } = useLanguage();
  
  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'border-green-200 bg-green-50',
      medium: 'border-yellow-200 bg-yellow-50',
      high: 'border-orange-200 bg-orange-50',
      urgent: 'border-red-200 bg-red-50'
    };
    return colors[priority];
  };

  const getProgressPercentage = (caseItem: Case) => {
    if (caseItem.progress.length === 0) return 0;
    const completed = caseItem.progress.filter(step => step.status === 'completed').length;
    return (completed / caseItem.progress.length) * 100;
  };

  const getStatusTranslation = (status: string) => {
    const statusMap: { [key: string]: string } = {
      'draft': 'draft',
      'submitted': 'submitted',
      'assigned': 'assigned',
      'in_progress': 'in_progress_status',
      'quality_check': 'quality_check',
      'completed': 'completed_status',
      'delivered': 'delivered'
    };
    return t(statusMap[status] || status);
  };

  const getPriorityTranslation = (priority: string) => {
    const priorityMap: { [key: string]: string } = {
      'low': 'low',
      'medium': 'medium',
      'high': 'high',
      'urgent': 'urgent'
    };
    return t(priorityMap[priority] || priority);
  };

  const borderClass = isRTL ? 'border-r-4' : 'border-l-4';

  return (
    <Card className={`p-4 ${borderClass} ${getPriorityColor(caseItem.priority)}`}>
      <div className={`flex justify-between items-start mb-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={isRTL ? 'text-right' : 'text-left'}>
          <h3 className="font-semibold">{caseItem.title}</h3>
          <p className="text-sm text-gray-600">{t('patient')}: {caseItem.patient.name}</p>
        </div>
        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Badge className={`${getStatusColor(caseItem.status)} text-white`}>
            {getStatusTranslation(caseItem.status)}
          </Badge>
          <Badge variant="outline" className="capitalize">
            {getPriorityTranslation(caseItem.priority)}
          </Badge>
        </div>
      </div>

      <div className={`flex items-center gap-4 mb-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Avatar className="w-6 h-6">
            <AvatarImage src={caseItem.dentist.avatar} />
            <AvatarFallback>{caseItem.dentist.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <span className="text-sm text-gray-600">{caseItem.dentist.name}</span>
        </div>
        {caseItem.lab && (
          <>
            <span className="text-gray-400">{isRTL ? '←' : '→'}</span>
            <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Avatar className="w-6 h-6">
                <AvatarImage src={caseItem.lab.avatar} />
                <AvatarFallback>{caseItem.lab.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-gray-600">{caseItem.lab.name}</span>
            </div>
          </>
        )}
      </div>

      {caseItem.progress.length > 0 && (
        <div className="mb-3">
          <div className={`flex justify-between text-sm text-gray-600 mb-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <span>{t('progress')}</span>
            <span>{Math.round(getProgressPercentage(caseItem))}%</span>
          </div>
          <Progress value={getProgressPercentage(caseItem)} className="h-2" />
        </div>
      )}

      <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className="text-sm text-gray-600">
          {t('due')}: {new Intl.DateTimeFormat(isRTL ? 'ar-SA' : 'en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          }).format(caseItem.dueDate)}
        </div>
        <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Button variant="outline" size="sm" className={`gap-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <MessageSquare className="w-3 h-3" />
            {caseItem.notes.length}
          </Button>
          <Button size="sm" onClick={() => onViewCase(caseItem.id)} className={`gap-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Eye className="w-3 h-3" />
            {t('view')}
          </Button>
        </div>
      </div>
    </Card>
  );
}