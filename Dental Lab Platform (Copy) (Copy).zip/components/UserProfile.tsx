import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { SearchableSelect } from './ui/searchable-select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Switch } from './ui/switch';
import { DatePicker } from './ui/date-picker';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { toast } from 'sonner@2.0.3';
import { 
  ArrowLeft,
  User,
  Camera,
  Mail,
  Phone,
  MapPin,
  Building,
  Award,
  Calendar,
  Shield,
  Bell,
  Lock,
  Edit,
  Save,
  FileText,
  Globe,
  Settings,
  CheckCircle,
  AlertCircle,
  Upload,
  Eye,
  EyeOff,
  Plus
} from 'lucide-react';
import { User as UserType } from '../types';
import { GENDER_OPTIONS, ROLE_OPTIONS } from '../utils/serviceOptions';
import { formatDate, formatRelativeDate } from '../utils/dateUtils';

interface UserProfileProps {
  currentUser: UserType;
  onBack: () => void;
}

export function UserProfile({ currentUser, onBack }: UserProfileProps) {
  const { t } = useLanguage();
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  
  // Profile state
  const [profileData, setProfileData] = useState({
    name: currentUser.name,
    practice: currentUser.practice,
    specialization: currentUser.specialization,
    location: currentUser.location,
    email: 'user@example.com', // This would come from auth context
    phone: '+971 50 123 4567',
    website: 'https://example.com',
    bio: 'Experienced dental professional committed to providing exceptional care and innovative solutions.',
    yearsOfExperience: '10+',
    languages: ['English', 'Arabic'],
    certifications: ['DDS', 'Endodontics Certificate', 'Digital Dentistry Certification']
  });

  // Settings state
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    marketingEmails: false,
    caseUpdates: true,
    weeklyReports: true,
    language: 'en',
    timezone: 'Asia/Dubai',
    theme: 'light'
  });

  // Password state
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });

  const languageOptions = [
    { value: 'en', label: 'English', category: 'Languages' },
    { value: 'ar', label: 'العربية', category: 'Languages' },
    { value: 'fr', label: 'Français', category: 'Languages' },
    { value: 'es', label: 'Español', category: 'Languages' }
  ];

  const timezoneOptions = [
    { value: 'Asia/Dubai', label: 'Dubai (UAE)', category: 'Middle East' },
    { value: 'Asia/Riyadh', label: 'Riyadh (Saudi Arabia)', category: 'Middle East' },
    { value: 'Europe/London', label: 'London (UK)', category: 'Europe' },
    { value: 'America/New_York', label: 'New York (USA)', category: 'Americas' }
  ];

  const themeOptions = [
    { value: 'light', label: 'Light Mode', category: 'Appearance' },
    { value: 'dark', label: 'Dark Mode', category: 'Appearance' },
    { value: 'system', label: 'System Default', category: 'Appearance' }
  ];

  const handleSaveProfile = () => {
    // Here you would typically call an API to update the user profile
    setIsEditing(false);
    toast.success('Profile updated successfully');
  };

  const handleSaveSettings = () => {
    // Here you would typically call an API to update user settings
    toast.success('Settings updated successfully');
  };

  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordData.newPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }
    
    // Here you would typically call an API to change the password
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    setShowPasswordDialog(false);
    toast.success('Password changed successfully');
  };

  const handleAvatarUpload = () => {
    // Here you would handle avatar upload
    toast.success('Profile picture updated successfully');
  };

  const getRoleDescription = (role: string) => {
    const descriptions = {
      dentist: 'Dental practitioner providing comprehensive oral healthcare services',
      lab: 'Dental laboratory specializing in prosthetic manufacturing and restoration',
      designer: 'CAD/CAM specialist creating digital dental prosthetics and restorations',
      supervisor: 'Quality assurance manager overseeing dental laboratory operations',
      owner: 'Platform administrator managing system operations and user accounts'
    };
    return descriptions[role as keyof typeof descriptions] || 'Professional user';
  };

  const getRoleColor = (role: string) => {
    const colors = {
      dentist: 'bg-cyan-100 text-cyan-800',
      lab: 'bg-blue-100 text-blue-800',
      designer: 'bg-orange-100 text-orange-800',
      supervisor: 'bg-green-100 text-green-800',
      owner: 'bg-purple-100 text-purple-800'
    };
    return colors[role as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">My Profile</h1>
            <p className="text-gray-600 mt-1">Manage your account information and preferences</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isEditing ? (
            <>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveProfile}>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          )}
        </div>
      </div>

      {/* Profile Overview Card */}
      <Card className="p-6">
        <div className="flex items-start gap-6">
          <div className="relative">
            <Avatar className="w-24 h-24">
              <AvatarImage src={currentUser.avatar} />
              <AvatarFallback className="text-2xl">
                {currentUser.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            {isEditing && (
              <Button
                size="sm"
                className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                onClick={handleAvatarUpload}
              >
                <Camera className="w-4 h-4" />
              </Button>
            )}
          </div>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-2xl font-bold">{currentUser.name}</h2>
              <Badge className={getRoleColor(currentUser.role)}>
                {currentUser.role}
              </Badge>
              {currentUser.status === 'approved' && (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>
            
            <p className="text-gray-600 mb-3">{getRoleDescription(currentUser.role)}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2 text-gray-600">
                <Building className="w-4 h-4" />
                <span>{currentUser.practice}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{currentUser.location}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Award className="w-4 h-4" />
                <span>{currentUser.specialization}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Member since {formatDate(currentUser.registrationDate)}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Profile Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Profile Information</TabsTrigger>
          <TabsTrigger value="professional">Professional Details</TabsTrigger>
          <TabsTrigger value="settings">Account Settings</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        {/* Profile Information Tab */}
        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-300px)]">
                <div className="space-y-6 pr-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={profileData.phone}
                    onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    value={profileData.website}
                    onChange={(e) => setProfileData(prev => ({ ...prev, website: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={profileData.location}
                  onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-gray-50' : ''}
                />
              </div>

              <div>
                <Label htmlFor="bio">Professional Bio</Label>
                <Textarea
                  id="bio"
                  value={profileData.bio}
                  onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-gray-50' : ''}
                  rows={4}
                  placeholder="Tell others about your professional background and expertise..."
                />
              </div>

              <div>
                <Label>Languages Spoken</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {profileData.languages.map((language, index) => (
                    <Badge key={index} variant="outline">
                      {language}
                    </Badge>
                  ))}
                </div>
              </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Professional Details Tab */}
        <TabsContent value="professional" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                Professional Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-300px)]">
                <div className="space-y-6 pr-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="practice">Practice/Organization Name</Label>
                  <Input
                    id="practice"
                    value={profileData.practice}
                    onChange={(e) => setProfileData(prev => ({ ...prev, practice: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
                <div>
                  <Label htmlFor="specialization">Specialization</Label>
                  <Input
                    id="specialization"
                    value={profileData.specialization}
                    onChange={(e) => setProfileData(prev => ({ ...prev, specialization: e.target.value }))}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-gray-50' : ''}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="experience">Years of Experience</Label>
                <Input
                  id="experience"
                  value={profileData.yearsOfExperience}
                  onChange={(e) => setProfileData(prev => ({ ...prev, yearsOfExperience: e.target.value }))}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-gray-50' : ''}
                />
              </div>

              <div>
                <Label>Certifications & Licenses</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {profileData.certifications.map((cert, index) => (
                    <Badge key={index} className="bg-blue-100 text-blue-800">
                      <Award className="w-3 h-3 mr-1" />
                      {cert}
                    </Badge>
                  ))}
                </div>
                {isEditing && (
                  <Button variant="outline" size="sm" className="mt-2">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Certification
                  </Button>
                )}
              </div>

              {/* Role-specific information */}
              {currentUser.role === 'dentist' && (
                <div className="space-y-4">
                  <Separator />
                  <h3 className="font-semibold">Dental Practice Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Practice Type</Label>
                      <SearchableSelect
                        options={[
                          { value: 'general', label: 'General Practice', category: 'Practice Type' },
                          { value: 'specialist', label: 'Specialist Practice', category: 'Practice Type' },
                          { value: 'multi', label: 'Multi-Specialty', category: 'Practice Type' }
                        ]}
                        value="general"
                        onValueChange={(value) => console.log('Practice type:', value)}
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label>Patient Capacity</Label>
                      <Input placeholder="e.g., 50 patients/day" disabled={!isEditing} />
                    </div>
                  </div>
                </div>
              )}

              {currentUser.role === 'lab' && (
                <div className="space-y-4">
                  <Separator />
                  <h3 className="font-semibold">Laboratory Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Lab Equipment</Label>
                      <Textarea placeholder="List main equipment and capabilities..." disabled={!isEditing} />
                    </div>
                    <div>
                      <Label>Production Capacity</Label>
                      <Input placeholder="e.g., 100 units/week" disabled={!isEditing} />
                    </div>
                  </div>
                </div>
              )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Account Settings Tab */}
        <TabsContent value="settings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Account Preferences
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-300px)]">
                <div className="space-y-6 pr-4">
              {/* Notification Settings */}
              <div>
                <h3 className="font-semibold mb-4">Notification Preferences</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-600">Receive updates via email</p>
                    </div>
                    <Switch
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, emailNotifications: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Push Notifications</Label>
                      <p className="text-sm text-gray-600">Receive browser notifications</p>
                    </div>
                    <Switch
                      checked={settings.pushNotifications}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, pushNotifications: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Case Updates</Label>
                      <p className="text-sm text-gray-600">Get notified about case progress</p>
                    </div>
                    <Switch
                      checked={settings.caseUpdates}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, caseUpdates: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Weekly Reports</Label>
                      <p className="text-sm text-gray-600">Receive weekly activity summaries</p>
                    </div>
                    <Switch
                      checked={settings.weeklyReports}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, weeklyReports: checked }))
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Marketing Emails</Label>
                      <p className="text-sm text-gray-600">Receive promotional content</p>
                    </div>
                    <Switch
                      checked={settings.marketingEmails}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, marketingEmails: checked }))
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Regional Settings */}
              <div>
                <h3 className="font-semibold mb-4">Regional Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Language</Label>
                    <SearchableSelect
                      options={languageOptions}
                      value={settings.language}
                      onValueChange={(value) => setSettings(prev => ({ ...prev, language: value }))}
                      placeholder="Select language"
                    />
                  </div>
                  <div>
                    <Label>Timezone</Label>
                    <SearchableSelect
                      options={timezoneOptions}
                      value={settings.timezone}
                      onValueChange={(value) => setSettings(prev => ({ ...prev, timezone: value }))}
                      placeholder="Select timezone"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Appearance Settings */}
              <div>
                <h3 className="font-semibold mb-4">Appearance</h3>
                <div>
                  <Label>Theme</Label>
                  <SearchableSelect
                    options={themeOptions}
                    value={settings.theme}
                    onValueChange={(value) => setSettings(prev => ({ ...prev, theme: value }))}
                    placeholder="Select theme"
                  />
                </div>
              </div>

              <div className="pt-4">
                <Button onClick={handleSaveSettings}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Settings
                </Button>
              </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="mt-6">
          <ScrollArea className="h-[calc(100vh-300px)]">
            <div className="space-y-6 pr-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Account Security
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-semibold">Password</h4>
                    <p className="text-sm text-gray-600">Last changed 3 months ago</p>
                  </div>
                  <Button variant="outline" onClick={() => setShowPasswordDialog(true)}>
                    <Lock className="w-4 h-4 mr-2" />
                    Change Password
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-semibold">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-600">Add an extra layer of security</p>
                  </div>
                  <Button variant="outline">
                    <Shield className="w-4 h-4 mr-2" />
                    Enable 2FA
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-semibold">Login Sessions</h4>
                    <p className="text-sm text-gray-600">Manage your active sessions</p>
                  </div>
                  <Button variant="outline">
                    <Eye className="w-4 h-4 mr-2" />
                    View Sessions
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Account Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Account Status</span>
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Active & Verified
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Member Since</span>
                    <span className="text-sm font-medium">
                      {formatDate(currentUser.registrationDate)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Account ID</span>
                    <span className="text-sm font-mono">{currentUser.id}</span>
                  </div>
                  {currentUser.approvalDate && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Approved On</span>
                      <span className="text-sm font-medium">
                        {formatDate(currentUser.approvalDate)}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>

      {/* Change Password Dialog */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription>
              Enter your current password and choose a new secure password.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Current Password</Label>
              <div className="relative">
                <Input
                  type={showPasswords.current ? "text" : "password"}
                  value={passwordData.currentPassword}
                  onChange={(e) => setPasswordData(prev => ({ 
                    ...prev, 
                    currentPassword: e.target.value 
                  }))}
                  placeholder="Enter current password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPasswords(prev => ({ 
                    ...prev, 
                    current: !prev.current 
                  }))}
                >
                  {showPasswords.current ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
            
            <div>
              <Label>New Password</Label>
              <div className="relative">
                <Input
                  type={showPasswords.new ? "text" : "password"}
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData(prev => ({ 
                    ...prev, 
                    newPassword: e.target.value 
                  }))}
                  placeholder="Enter new password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPasswords(prev => ({ 
                    ...prev, 
                    new: !prev.new 
                  }))}
                >
                  {showPasswords.new ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Password must be at least 8 characters long
              </p>
            </div>
            
            <div>
              <Label>Confirm New Password</Label>
              <div className="relative">
                <Input
                  type={showPasswords.confirm ? "text" : "password"}
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData(prev => ({ 
                    ...prev, 
                    confirmPassword: e.target.value 
                  }))}
                  placeholder="Confirm new password"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPasswords(prev => ({ 
                    ...prev, 
                    confirm: !prev.confirm 
                  }))}
                >
                  {showPasswords.confirm ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPasswordDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleChangePassword}
              disabled={!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword}
            >
              <Lock className="w-4 h-4 mr-2" />
              Change Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}