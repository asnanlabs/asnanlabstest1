import React from 'react';

interface AsnanLabsLogoProps {
  className?: string;
  width?: number;
  height?: number;
  color?: string;
}

export function AsnanLabsLogo({ 
  className = "", 
  width = 200, 
  height = 60, 
  color = "currentColor" 
}: AsnanLabsLogoProps) {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 400 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <g fill={color}>
        {/* "Asnan" */}
        <path d="M45 85 C35 75, 25 65, 30 50 C35 35, 50 30, 65 35 C80 40, 90 55, 85 70 L80 75 C75 80, 70 82, 65 80 C60 78, 58 73, 60 68 C62 63, 67 61, 72 63 L75 65 M15 85 L25 50 L35 85 M25 70 L35 70" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M95 85 C105 75, 115 65, 120 50 C125 35, 120 25, 105 30 C90 35, 85 50, 90 65 L95 85 M110 45 C125 40, 140 45, 145 60 C150 75, 145 85, 130 85 C115 85, 110 70, 115 55" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M165 85 L175 50 L185 70 L195 50 L205 85 M175 85 L175 45 M195 85 L195 45" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M225 85 C235 75, 245 65, 250 50 C255 35, 250 25, 235 30 C220 35, 215 50, 220 65 L225 85 M240 45 C255 40, 270 45, 275 60 C280 75, 275 85, 260 85 C245 85, 240 70, 245 55" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M295 85 L305 50 L315 70 L325 50 L335 85 M305 85 L305 45 M325 85 L325 45" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        {/* "Labs" */}
        <path d="M45 115 L45 95 L75 115 M45 105 L65 105" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M95 115 C105 105, 115 95, 120 80 C125 65, 120 55, 105 60 C90 65, 85 80, 90 95 L95 115 M110 75 C125 70, 140 75, 145 90 C150 105, 145 115, 130 115 C115 115, 110 100, 115 85" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M165 115 C175 105, 185 95, 190 80 C195 65, 190 55, 175 60 C160 65, 155 80, 160 95 L175 115 M175 95 C185 90, 195 95, 200 105 C205 115, 200 120, 190 120 C180 120, 175 110, 180 100" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M225 115 C235 105, 245 95, 250 80 C255 65, 250 55, 235 60 C220 65, 215 80, 220 95 L225 115 M240 75 C255 70, 270 75, 275 90 C280 105, 275 115, 260 115 C245 115, 240 100, 245 85" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
        
        <path d="M295 115 C305 105, 315 95, 320 80 C325 65, 320 55, 305 60 C290 65, 285 80, 290 95 L295 115 M310 75 C325 70, 340 75, 345 90 C350 105, 345 115, 330 115 C315 115, 310 100, 315 85 M345 95 L355 115" strokeWidth="3" stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      </g>
      
      {/* More refined script-style paths */}
      <g fill={color} stroke="none">
        {/* Asnan in script style */}
        <path d="M20 60 Q15 45 25 35 Q40 25 55 35 Q70 45 65 60 Q60 75 45 75 Q35 75 30 65 Q25 60 30 55 Q35 50 45 55 Q50 60 45 65 L40 70 M10 75 Q15 40 25 40 Q35 40 40 75 M25 60 L35 60"/>
        
        <path d="M70 75 Q80 40 90 40 Q100 40 105 55 Q110 70 100 75 Q90 80 85 70 Q80 60 90 55 Q100 50 110 60 Q120 70 115 80 Q110 85 100 80"/>
        
        <path d="M140 75 Q150 40 160 40 Q170 40 175 50 Q180 60 175 70 Q170 75 165 70 L175 50 Q185 40 195 50 Q200 60 195 70 Q190 75 185 70"/>
        
        <path d="M220 75 Q230 40 240 40 Q250 40 255 55 Q260 70 250 75 Q240 80 235 70 Q230 60 240 55 Q250 50 260 60 Q270 70 265 80 Q260 85 250 80"/>
        
        <path d="M290 75 Q300 40 310 40 Q320 40 325 50 Q330 60 325 70 Q320 75 315 70 L325 50 Q335 40 345 50 Q350 60 345 70 Q340 75 335 70"/>
      </g>
      
      {/* Labs in script style */}
      <g fill={color} stroke="none" transform="translate(0, 25)">
        <path d="M20 75 Q25 40 35 40 Q40 40 45 50 L65 75 M30 60 L55 60"/>
        
        <path d="M80 75 Q90 40 100 40 Q110 40 115 55 Q120 70 110 75 Q100 80 95 70 Q90 60 100 55 Q110 50 120 60 Q130 70 125 80 Q120 85 110 80"/>
        
        <path d="M150 75 Q160 40 170 40 Q180 40 185 55 Q190 65 185 70 Q180 75 175 70 Q170 65 175 60 Q180 55 190 60 Q195 65 190 70 Q185 75 180 70 M185 65 Q195 70 200 75"/>
        
        <path d="M220 75 Q230 40 240 40 Q250 40 255 50 Q260 60 255 70 Q250 75 245 70 Q240 65 245 60 Q250 55 260 60 Q270 65 265 70 Q260 75 255 70 M255 65 L270 75"/>
      </g>
      
      {/* Decorative dot */}
      <circle cx="370" cy="85" r="3" fill={color}/>
    </svg>
  );
}

export default AsnanLabsLogo;