import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { SearchableSelect } from './ui/searchable-select';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { Alert, AlertDescription } from './ui/alert';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { toast } from 'sonner@2.0.3';
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  User, 
  Settings, 
  Upload,
  X,
  FileText,
  Image,
  File,
  Eye,
  Trash2,
  CheckCircle,
  AlertTriangle,
  Save,
  Send
} from 'lucide-react';
import { Case, User as UserType, Patient } from '../types';
import { 
  TREATMENT_CATEGORIES,
  MATERIALS,
  generateServiceOptions,
  generateMaterialOptions,
  getServicesByCategory,
  PRIORITY_OPTIONS,
  GENDER_OPTIONS,
  FABRICATION_OPTIONS
} from '../utils/serviceOptions';
import { mockUsers, mockPatients } from '../data/mockData';

interface CaseFormProps {
  currentUser: UserType;
  onClose: () => void;
  onSubmit: (caseData: Partial<Case>) => void;
}

interface ToothData {
  id: string;
  position: number;
  selected: boolean;
  treatmentGroupId: string;
  shade: string;
  notes: string;
}

interface TreatmentGroup {
  id: string;
  name: string;
  teeth: number[];
  treatmentCategory: string;
  treatmentType: string;
  material: string;
  retentionType: string;
  abutmentType: string;
  fabricationMethod: string;
  color: string;
}

interface FileAttachment {
  id: string;
  name: string;
  type: 'image' | 'xray' | 'stl' | 'ply' | 'other';
  size: number;
  url: string;
  uploadDate: Date;
}

interface ChecklistItem {
  id: string;
  text: string;
  checked: boolean;
  comment: string;
}

const TREATMENT_CHECKLISTS = {
  crown: [
    { id: 'crown-1', text: 'Check occlusion', checked: false, comment: '' },
    { id: 'crown-2', text: 'Proper tooth preparation', checked: false, comment: '' },
    { id: 'crown-3', text: 'Appropriate shade selection', checked: false, comment: '' },
    { id: 'crown-4', text: 'Check margins', checked: false, comment: '' },
    { id: 'crown-5', text: 'Verify measurements accuracy', checked: false, comment: '' }
  ],
  bridge: [
    { id: 'bridge-1', text: 'Prepare abutment teeth', checked: false, comment: '' },
    { id: 'bridge-2', text: 'Check inter-tooth spacing', checked: false, comment: '' },
    { id: 'bridge-3', text: 'Assess tissue health', checked: false, comment: '' },
    { id: 'bridge-4', text: 'Select appropriate connector type', checked: false, comment: '' },
    { id: 'bridge-5', text: 'Ensure stability and retention', checked: false, comment: '' }
  ],
  custom_abutment: [
    { id: 'implant-1', text: 'Check bone density', checked: false, comment: '' },
    { id: 'implant-2', text: 'Determine precise implant position', checked: false, comment: '' },
    { id: 'implant-3', text: 'Measure required depth and diameter', checked: false, comment: '' },
    { id: 'implant-4', text: 'Examine surrounding tissue', checked: false, comment: '' },
    { id: 'implant-5', text: 'Verify tissue healing', checked: false, comment: '' }
  ],
  full_denture: [
    { id: 'denture-1', text: 'Assess jaw alignment', checked: false, comment: '' },
    { id: 'denture-2', text: 'Check tissue health', checked: false, comment: '' },
    { id: 'denture-3', text: 'Verify bite registration', checked: false, comment: '' },
    { id: 'denture-4', text: 'Select appropriate teeth', checked: false, comment: '' },
    { id: 'denture-5', text: 'Check retention and stability', checked: false, comment: '' }
  ]
};

export function CaseForm({ currentUser, onClose, onSubmit }: CaseFormProps) {
  const { t } = useLanguage();
  
  // Form state
  const [title, setTitle] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientGender, setPatientGender] = useState('');
  
  // Treatment groups state
  const [treatmentGroups, setTreatmentGroups] = useState<TreatmentGroup[]>([]);
  const [selectedTreatmentGroup, setSelectedTreatmentGroup] = useState<string>('');
  const [currentGroupConfig, setCurrentGroupConfig] = useState({
    treatmentCategory: '',
    treatmentType: '',
    material: '',
    retentionType: '',
    abutmentType: '',
    fabricationMethod: ''
  });
  
  const [priority, setPriority] = useState('medium');
  const [dueDate, setDueDate] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  
  // Dental chart state
  const [selectedTeeth, setSelectedTeeth] = useState<ToothData[]>([]);
  const [activeStep, setActiveStep] = useState(1);
  
  // File attachments state
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  
  // Checklist state
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  
  // Validation state
  const [showValidationDialog, setShowValidationDialog] = useState(false);
  const [validationIssues, setValidationIssues] = useState<string[]>([]);

  // Generate options using shared utilities
  const treatmentCategoryOptions = Object.entries(TREATMENT_CATEGORIES).map(([key, category]) => ({
    value: key,
    label: category.label,
    category: 'Treatment Category'
  }));

  const materialOptions = generateMaterialOptions();

  // Get patients for current dentist
  const availablePatients = mockPatients.filter(patient => patient.dentistId === currentUser.id);
  
  // Generate patient options for dropdown
  const patientOptions = availablePatients.map(patient => ({
    value: patient.id,
    label: `${patient.name} (Age: ${patient.age}, ${patient.gender})`,
    category: 'Patients',
    patient: patient
  }));

  // Handle patient selection
  const handlePatientSelect = (patientId: string) => {
    const patient = availablePatients.find(p => p.id === patientId);
    if (patient) {
      setSelectedPatient(patient);
      setPatientName(patient.name);
      setPatientAge(patient.age.toString());
      setPatientGender(patient.gender);
    }
  };

  // Handle manual patient entry (for new patients)
  const handleNewPatientEntry = (name: string) => {
    setSelectedPatient(null);
    setPatientName(name);
    // Reset other fields when entering new patient manually
    setPatientAge('');
    setPatientGender('');
  };

  // Reset dependent fields when category changes
  useEffect(() => {
    setCurrentGroupConfig(prev => ({
      ...prev,
      treatmentType: '',
      material: '',
      retentionType: '',
      abutmentType: ''
    }));
  }, [currentGroupConfig.treatmentCategory]);

  // Reset material and other dependent fields when treatment type changes
  useEffect(() => {
    setCurrentGroupConfig(prev => ({
      ...prev,
      material: '',
      retentionType: '',
      abutmentType: ''
    }));
    
    // Update checklist based on treatment type
    if (currentGroupConfig.treatmentType && TREATMENT_CHECKLISTS[currentGroupConfig.treatmentType as keyof typeof TREATMENT_CHECKLISTS]) {
      setChecklist([...TREATMENT_CHECKLISTS[currentGroupConfig.treatmentType as keyof typeof TREATMENT_CHECKLISTS]]);
    } else {
      setChecklist([]);
    }
  }, [currentGroupConfig.treatmentType]);

  // Set minimum due date (3 days from now)
  useEffect(() => {
    const minDate = new Date();
    minDate.setDate(minDate.getDate() + 3);
    setDueDate(minDate.toISOString().split('T')[0]);
  }, []);

  // Generate dental chart with FDI numbering system
  // Display from face-to-face perspective: Left side of screen = Patient's right, Right side of screen = Patient's left
  const generateDentalChart = () => {
    // Patient's right quadrants (appear on LEFT side of screen)
    const upperRightQuadrant = [18, 17, 16, 15, 14, 13, 12, 11]; // Quadrant 1
    const lowerRightQuadrant = [48, 47, 46, 45, 44, 43, 42, 41]; // Quadrant 4
    
    // Patient's left quadrants (appear on RIGHT side of screen)  
    const upperLeftQuadrant = [21, 22, 23, 24, 25, 26, 27, 28]; // Quadrant 2
    const lowerLeftQuadrant = [31, 32, 33, 34, 35, 36, 37, 38]; // Quadrant 3
    
    // Arrange for face-to-face view: Patient's right first, then Patient's left
    const upperTeeth = [...upperRightQuadrant, ...upperLeftQuadrant];
    const lowerTeeth = [...lowerRightQuadrant, ...lowerLeftQuadrant];
    
    return { upperTeeth, lowerTeeth };
  };

  const handleToothClick = (toothNumber: number) => {
    const existingTooth = selectedTeeth.find(t => t.position === toothNumber);
    
    if (existingTooth) {
      // Remove tooth from all treatment groups
      setTreatmentGroups(prev => prev.map(group => ({
        ...group,
        teeth: group.teeth.filter(t => t !== toothNumber)
      })).filter(group => group.teeth.length > 0));
      
      setSelectedTeeth(prev => prev.filter(t => t.position !== toothNumber));
    } else {
      const newTooth: ToothData = {
        id: `tooth-${toothNumber}`,
        position: toothNumber,
        selected: true,
        treatmentGroupId: '',
        shade: '',
        notes: ''
      };
      setSelectedTeeth(prev => [...prev, newTooth]);
    }
  };

  const updateToothData = (toothPosition: number, field: keyof ToothData, value: any) => {
    setSelectedTeeth(prev => prev.map(tooth => 
      tooth.position === toothPosition 
        ? { ...tooth, [field]: value }
        : tooth
    ));
  };

  // Create new treatment group from selected teeth
  const createTreatmentGroup = () => {
    const unassignedTeeth = selectedTeeth
      .filter(tooth => !tooth.treatmentGroupId)
      .map(tooth => tooth.position);

    if (unassignedTeeth.length === 0) {
      toast.error('Please select teeth that are not already assigned to a treatment group');
      return;
    }

    if (!currentGroupConfig.treatmentCategory || !currentGroupConfig.treatmentType) {
      toast.error('Please select treatment category and type');
      return;
    }

    const groupColors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 'bg-red-500', 'bg-pink-500'];
    const newGroupId = `group-${Date.now()}`;
    
    const newGroup: TreatmentGroup = {
      id: newGroupId,
      name: `Group ${treatmentGroups.length + 1}`,
      teeth: unassignedTeeth,
      ...currentGroupConfig,
      color: groupColors[treatmentGroups.length % groupColors.length]
    };

    setTreatmentGroups(prev => [...prev, newGroup]);
    
    // Update teeth to assign them to this group
    setSelectedTeeth(prev => prev.map(tooth => 
      unassignedTeeth.includes(tooth.position)
        ? { ...tooth, treatmentGroupId: newGroupId }
        : tooth
    ));

    // Reset current group configuration
    setCurrentGroupConfig({
      treatmentCategory: '',
      treatmentType: '',
      material: '',
      retentionType: '',
      abutmentType: '',
      fabricationMethod: ''
    });

    toast.success(`Created treatment group with ${unassignedTeeth.length} teeth`);
  };

  const removeTreatmentGroup = (groupId: string) => {
    // Remove group
    setTreatmentGroups(prev => prev.filter(group => group.id !== groupId));
    
    // Unassign teeth from this group
    setSelectedTeeth(prev => prev.map(tooth => 
      tooth.treatmentGroupId === groupId
        ? { ...tooth, treatmentGroupId: '' }
        : tooth
    ));
    
    toast.success('Treatment group removed');
  };

  // Get available treatments based on selected category
  const getAvailableTreatments = () => {
    if (!currentGroupConfig.treatmentCategory) return [];
    return getServicesByCategory(currentGroupConfig.treatmentCategory);
  };

  // Check if material selection is required
  const requiresMaterial = () => {
    if (!currentGroupConfig.treatmentCategory) return false;
    return TREATMENT_CATEGORIES[currentGroupConfig.treatmentCategory as keyof typeof TREATMENT_CATEGORIES]?.requiresMaterial || false;
  };

  // Check if retention type is required
  const requiresRetention = () => {
    if (!currentGroupConfig.treatmentCategory) return false;
    return TREATMENT_CATEGORIES[currentGroupConfig.treatmentCategory as keyof typeof TREATMENT_CATEGORIES]?.requiresRetention || false;
  };

  // Check if abutment type is required
  const requiresAbutment = () => {
    if (!currentGroupConfig.treatmentCategory) return false;
    return TREATMENT_CATEGORIES[currentGroupConfig.treatmentCategory as keyof typeof TREATMENT_CATEGORIES]?.requiresAbutment || false;
  };

  const getToothGroupColor = (toothPosition: number) => {
    const tooth = selectedTeeth.find(t => t.position === toothPosition);
    if (!tooth || !tooth.treatmentGroupId) return '';
    
    const group = treatmentGroups.find(g => g.id === tooth.treatmentGroupId);
    return group?.color || '';
  };

  const getUnassignedTeeth = () => {
    return selectedTeeth.filter(tooth => !tooth.treatmentGroupId);
  };

  // File upload handlers
  const handleFileUpload = (files: FileList) => {
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        const newAttachment: FileAttachment = {
          id: `file-${Date.now()}-${Math.random()}`,
          name: file.name,
          type: getFileType(file.type, file.name),
          size: file.size,
          url: reader.result as string,
          uploadDate: new Date()
        };
        setAttachments(prev => [...prev, newAttachment]);
      };
      reader.readAsDataURL(file);
    });
  };

  const getFileType = (mimeType: string, fileName: string): FileAttachment['type'] => {
    if (mimeType.startsWith('image/')) return 'image';
    if (fileName.toLowerCase().includes('xray') || fileName.toLowerCase().includes('radiograph')) return 'xray';
    if (fileName.toLowerCase().endsWith('.stl')) return 'stl';
    if (fileName.toLowerCase().endsWith('.ply')) return 'ply';
    return 'other';
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(att => att.id !== id));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Checklist handlers
  const updateChecklistItem = (id: string, field: 'checked' | 'comment', value: boolean | string) => {
    setChecklist(prev => prev.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  // Validation
  const validateForm = () => {
    const issues: string[] = [];
    
    if (!title.trim()) issues.push('Case title is required');
    if (!patientName.trim()) issues.push('Patient selection or name is required');
    if (!selectedPatient && !patientAge) issues.push('Patient age is required for new patients');
    if (!selectedPatient && !patientGender) issues.push('Patient gender is required for new patients');
    if (selectedTeeth.length === 0) issues.push('At least one tooth must be selected');
    if (treatmentGroups.length === 0) issues.push('At least one treatment group must be created');
    if (getUnassignedTeeth().length > 0) issues.push('All selected teeth must be assigned to a treatment group');
    if (attachments.length === 0) issues.push('At least one file attachment is required');
    
    return issues;
  };

  const handleSaveDraft = () => {
    const caseData = {
      title,
      patient: selectedPatient || {
        id: `patient-${Date.now()}`,
        name: patientName,
        age: parseInt(patientAge) || 0,
        gender: patientGender,
        phone: '',
        medicalHistory: '',
        allergies: [],
        dentistId: currentUser.id,
        createdAt: new Date()
      },
      type: treatmentGroups[0]?.treatmentType || '',
      material: treatmentGroups[0]?.material || '',
      priority: priority as Case['priority'],
      dueDate: new Date(dueDate),
      description,
      instructions,
      dentist: currentUser,
      status: 'draft' as Case['status'],
      createdAt: new Date(),
      updatedAt: new Date(),
      selectedTeeth,
      attachments,
      checklist,
      treatmentCategory,
      retentionType,
      abutmentType,
      fabricationMethod
    };
    
    toast.success('Draft saved successfully');
    onSubmit(caseData);
  };

  const handleSubmitToConsultant = () => {
    const issues = validateForm();
    
    if (issues.length > 0) {
      setValidationIssues(issues);
      setShowValidationDialog(true);
      return;
    }
    
    const caseData = {
      title,
      patient: selectedPatient || {
        id: `patient-${Date.now()}`,
        name: patientName,
        age: parseInt(patientAge) || 0,
        gender: patientGender,
        phone: '',
        medicalHistory: '',
        allergies: [],
        dentistId: currentUser.id,
        createdAt: new Date()
      },
      type: treatmentGroups[0]?.treatmentType || '',
      material: treatmentGroups[0]?.material || '',
      priority: priority as Case['priority'],
      dueDate: new Date(dueDate),
      description,
      instructions,
      dentist: currentUser,
      status: 'submitted' as Case['status'],
      createdAt: new Date(),
      updatedAt: new Date(),
      selectedTeeth,
      attachments,
      checklist,
      treatmentGroups,
      treatmentCategory: treatmentGroups[0]?.treatmentCategory || '',
      retentionType: treatmentGroups[0]?.retentionType || '',
      abutmentType: treatmentGroups[0]?.abutmentType || '',
      fabricationMethod: treatmentGroups[0]?.fabricationMethod || ''
    };
    
    toast.success('Case submitted to consultant successfully');
    onSubmit(caseData);
  };

  const { upperTeeth, lowerTeeth } = generateDentalChart();

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <ScrollArea className="flex-1">
        <div className="p-6">
          <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onClose}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl text-gray-900">Create New Case</h1>
              <p className="text-gray-600">Fill in the required details to create a new case</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-blue-50 text-blue-700">
              Step {activeStep} of 5
            </Badge>
            <Button variant="outline" onClick={handleSaveDraft}>
              <Save className="w-4 h-4 mr-2" />
              Save Draft
            </Button>
            <Button onClick={handleSubmitToConsultant} className="bg-blue-600 hover:bg-blue-700">
              <Send className="w-4 h-4 mr-2" />
              Submit to Consultant
            </Button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <Progress value={(activeStep / 5) * 100} className="h-2" />
          <div className="flex justify-between mt-2 text-sm text-gray-600">
            <span>Patient Info</span>
            <span>Dental Chart</span>
            <span>Attachments</span>
            <span>Checklist</span>
            <span>Review & Submit</span>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Main Content */}
          <div className="col-span-8">
            <Tabs value={activeStep.toString()} onValueChange={(value) => setActiveStep(parseInt(value))}>
              <TabsList className="grid w-full grid-cols-5 mb-6">
                <TabsTrigger value="1" className="text-xs">Patient Info</TabsTrigger>
                <TabsTrigger value="2" className="text-xs">Dental Chart</TabsTrigger>
                <TabsTrigger value="3" className="text-xs">Attachments</TabsTrigger>
                <TabsTrigger value="4" className="text-xs">Checklist</TabsTrigger>
                <TabsTrigger value="5" className="text-xs">Review</TabsTrigger>
              </TabsList>

              {/* Step 1: Patient Information with Enhanced Treatment Selection */}
              <TabsContent value="1" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5 text-blue-600" />
                      Patient and Case Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Basic Case Info */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="title">Case Title *</Label>
                        <Input
                          id="title"
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          placeholder="e.g., Anterior Crown for Tooth #11"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="priority">Priority</Label>
                        <SearchableSelect
                          options={PRIORITY_OPTIONS}
                          value={priority}
                          onValueChange={setPriority}
                          placeholder="Select priority"
                          searchPlaceholder="Search priority levels..."
                          className="mt-1"
                        />
                      </div>
                    </div>

                    {/* Patient Information */}
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="patientSelect">Select Patient *</Label>
                        <SearchableSelect
                          options={patientOptions}
                          value={selectedPatient?.id || ''}
                          onValueChange={handlePatientSelect}
                          placeholder="Search existing patients or type new name"
                          searchPlaceholder="Search patients..."
                          allowCustom={true}
                          onCustomValue={handleNewPatientEntry}
                          className="mt-1"
                        />
                        {availablePatients.length === 0 && (
                          <p className="text-xs text-gray-500 mt-1">
                            No existing patients found. Enter patient name to create new patient record.
                          </p>
                        )}
                      </div>
                      
                      {/* Show patient details if selected from list */}
                      {selectedPatient && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
                          <div className="flex items-center gap-2 mb-2">
                            <User className="w-4 h-4 text-blue-600" />
                            <h4 className="font-medium text-blue-900">Patient Information</h4>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Name:</span>
                              <p className="font-medium">{selectedPatient.name}</p>
                            </div>
                            <div>
                              <span className="text-gray-600">Age:</span>
                              <p className="font-medium">{selectedPatient.age} years</p>
                            </div>
                            <div>
                              <span className="text-gray-600">Gender:</span>
                              <p className="font-medium capitalize">{selectedPatient.gender}</p>
                            </div>
                            <div>
                              <span className="text-gray-600">Phone:</span>
                              <p className="font-medium">{selectedPatient.phone}</p>
                            </div>
                            {selectedPatient.medicalHistory && (
                              <div className="col-span-2">
                                <span className="text-gray-600">Medical History:</span>
                                <p className="font-medium">{selectedPatient.medicalHistory}</p>
                              </div>
                            )}
                            {selectedPatient.allergies && selectedPatient.allergies.length > 0 && (
                              <div className="col-span-2">
                                <span className="text-gray-600">Allergies:</span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {selectedPatient.allergies.map((allergy, index) => (
                                    <Badge key={index} variant="outline" className="text-xs bg-red-100 text-red-700">
                                      {allergy}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {/* Manual patient entry fields (shown when no patient selected) */}
                      {!selectedPatient && patientName && (
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="patientAge">Age</Label>
                            <Input
                              id="patientAge"
                              type="number"
                              value={patientAge}
                              onChange={(e) => setPatientAge(e.target.value)}
                              placeholder="Age in years"
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="patientGender">Gender</Label>
                            <SearchableSelect
                              options={GENDER_OPTIONS}
                              value={patientGender}
                              onValueChange={setPatientGender}
                              placeholder="Select gender"
                              searchPlaceholder="Search gender..."
                              className="mt-1"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    <Separator />

                    {/* Due Date */}
                    <div>
                      <Label htmlFor="dueDate">Due Date *</Label>
                      <Input
                        id="dueDate"
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                        min={new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
                        className="mt-1"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Minimum 3 days from today required
                      </p>
                    </div>

                    {/* Case Description */}
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="description">Case Description</Label>
                        <Textarea
                          id="description"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          placeholder="Provide detailed description of the case..."
                          className="mt-1"
                          rows={3}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="instructions">Special Instructions for Lab</Label>
                        <Textarea
                          id="instructions"
                          value={instructions}
                          onChange={(e) => setInstructions(e.target.value)}
                          placeholder="Any specific instructions for the laboratory..."
                          className="mt-1"
                          rows={3}
                        />
                      </div>
                    </div>

                    <div className="flex justify-end pt-4">
                      <Button onClick={() => setActiveStep(2)}>
                        Next: Dental Chart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Step 2: Enhanced Interactive Dental Chart with Treatment Groups */}
              <TabsContent value="2" className="space-y-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5 text-blue-600" />
                      Select Teeth & Configure Treatment Groups
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        {selectedTeeth.length} teeth selected
                      </Badge>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700">
                        {treatmentGroups.length} treatment groups
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    {/* Dental Chart */}
                    <div className="space-y-6">
                      {/* Upper Teeth */}
                      <div>
                        <h4 className="font-medium mb-3 text-gray-700">Upper Teeth</h4>
                        <div className="flex justify-center gap-1">
                          {upperTeeth.map((toothNumber) => {
                            const isSelected = selectedTeeth.some(t => t.position === toothNumber);
                            const groupColor = getToothGroupColor(toothNumber);
                            return (
                              <button
                                key={toothNumber}
                                onClick={() => handleToothClick(toothNumber)}
                                className={`
                                  w-10 h-12 border-2 rounded-lg text-xs font-medium
                                  transition-all duration-200 hover:scale-105
                                  ${isSelected 
                                    ? groupColor ? `${groupColor} text-white border-opacity-80 shadow-md` : 'bg-blue-500 text-white border-blue-600 shadow-md'
                                    : 'bg-white text-gray-600 border-gray-300 hover:border-blue-400'
                                  }
                                `}
                              >
                                {toothNumber}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Lower Teeth */}
                      <div>
                        <h4 className="font-medium mb-3 text-gray-700">Lower Teeth</h4>
                        <div className="flex justify-center gap-1">
                          {lowerTeeth.map((toothNumber) => {
                            const isSelected = selectedTeeth.some(t => t.position === toothNumber);
                            const groupColor = getToothGroupColor(toothNumber);
                            return (
                              <button
                                key={toothNumber}
                                onClick={() => handleToothClick(toothNumber)}
                                className={`
                                  w-10 h-12 border-2 rounded-lg text-xs font-medium
                                  transition-all duration-200 hover:scale-105
                                  ${isSelected 
                                    ? groupColor ? `${groupColor} text-white border-opacity-80 shadow-md` : 'bg-blue-500 text-white border-blue-600 shadow-md'
                                    : 'bg-white text-gray-600 border-gray-300 hover:border-blue-400'
                                  }
                                `}
                              >
                                {toothNumber}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Treatment Group Configuration */}
                    {getUnassignedTeeth().length > 0 && (
                      <div className="space-y-6 bg-blue-50 p-6 rounded-lg border border-blue-200">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-blue-900">Configure Treatment for Selected Teeth</h4>
                          <Badge variant="outline" className="bg-white">
                            {getUnassignedTeeth().length} teeth to configure
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          {/* Treatment Category */}
                          <div>
                            <Label htmlFor="currentGroupCategory">Treatment Category *</Label>
                            <SearchableSelect
                              options={treatmentCategoryOptions}
                              value={currentGroupConfig.treatmentCategory}
                              onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, treatmentCategory: value }))}
                              placeholder="Select treatment category"
                              searchPlaceholder="Search treatment categories..."
                              className="mt-1"
                            />
                          </div>

                          {/* Treatment Type */}
                          {currentGroupConfig.treatmentCategory && (
                            <div>
                              <Label htmlFor="currentGroupType">Treatment Type *</Label>
                              <SearchableSelect
                                options={getAvailableTreatments()}
                                value={currentGroupConfig.treatmentType}
                                onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, treatmentType: value }))}
                                placeholder="Select specific treatment"
                                searchPlaceholder="Search treatments..."
                                className="mt-1"
                              />
                            </div>
                          )}

                          {/* Material Selection */}
                          {requiresMaterial() && (
                            <div>
                              <Label htmlFor="currentGroupMaterial">Material Type *</Label>
                              <SearchableSelect
                                options={materialOptions}
                                value={currentGroupConfig.material}
                                onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, material: value }))}
                                placeholder="Select material"
                                searchPlaceholder="Search materials..."
                                allowCustom={true}
                                onCustomValue={(customMaterial) => {
                                  setCurrentGroupConfig(prev => ({ ...prev, material: customMaterial }));
                                  toast.success(`Added custom material: ${customMaterial}`);
                                }}
                                className="mt-1"
                              />
                            </div>
                          )}

                          {/* Fabrication Method */}
                          <div>
                            <Label>Fabrication Method</Label>
                            <SearchableSelect
                              options={FABRICATION_OPTIONS}
                              value={currentGroupConfig.fabricationMethod}
                              onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, fabricationMethod: value }))}
                              placeholder="Select fabrication method"
                              searchPlaceholder="Search fabrication methods..."
                              allowCustom={true}
                              onCustomValue={(customMethod) => {
                                setCurrentGroupConfig(prev => ({ ...prev, fabricationMethod: customMethod }));
                                toast.success(`Added custom fabrication method: ${customMethod}`);
                              }}
                              className="mt-1"
                            />
                          </div>
                        </div>

                        {/* Retention Type */}
                        {requiresRetention() && (
                          <div>
                            <Label>Retention Type</Label>
                            <RadioGroup 
                              value={currentGroupConfig.retentionType} 
                              onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, retentionType: value }))} 
                              className="mt-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="screw_retained" id="screw" />
                                <Label htmlFor="screw">Screw-Retained</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="cement_retained" id="cement" />
                                <Label htmlFor="cement">Cement-Retained</Label>
                              </div>
                            </RadioGroup>
                          </div>
                        )}

                        {/* Abutment Type */}
                        {requiresAbutment() && (
                          <div>
                            <Label>Abutment Type</Label>
                            <RadioGroup 
                              value={currentGroupConfig.abutmentType} 
                              onValueChange={(value) => setCurrentGroupConfig(prev => ({ ...prev, abutmentType: value }))} 
                              className="mt-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="custom" id="custom" />
                                <Label htmlFor="custom">Custom</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="stock" id="stock" />
                                <Label htmlFor="stock">Stock</Label>
                              </div>
                            </RadioGroup>
                          </div>
                        )}

                        <div className="flex justify-end">
                          <Button 
                            onClick={createTreatmentGroup}
                            disabled={!currentGroupConfig.treatmentCategory || !currentGroupConfig.treatmentType}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Create Treatment Group
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* Existing Treatment Groups */}
                    {treatmentGroups.length > 0 && (
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-700">Treatment Groups</h4>
                        <div className="space-y-3">
                          {treatmentGroups.map((group) => (
                            <div key={group.id} className="bg-white border rounded-lg p-4">
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-3">
                                  <div className={`w-4 h-4 ${group.color} rounded`}></div>
                                  <span className="font-medium">{group.name}</span>
                                  <Badge variant="outline" className="text-xs">
                                    {group.teeth.length} teeth
                                  </Badge>
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => removeTreatmentGroup(group.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="text-gray-600">Treatment:</span>
                                  <p className="font-medium">{group.treatmentType.replace('_', ' ')}</p>
                                </div>
                                <div>
                                  <span className="text-gray-600">Material:</span>
                                  <p className="font-medium">{MATERIALS[group.material as keyof typeof MATERIALS] || group.material}</p>
                                </div>
                                <div>
                                  <span className="text-gray-600">Teeth:</span>
                                  <p className="font-medium">
                                    {group.teeth.map(tooth => `#${tooth}`).join(', ')}
                                  </p>
                                </div>
                                <div>
                                  <span className="text-gray-600">Fabrication:</span>
                                  <p className="font-medium">{group.fabricationMethod.replace('_', ' ')}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Individual Tooth Configuration */}
                    {selectedTeeth.length > 0 && (
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-700">Individual Tooth Configuration</h4>
                        <div className="space-y-3">
                          {selectedTeeth.map((tooth) => (
                            <div key={tooth.id} className="bg-gray-50 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <Badge className="bg-blue-100 text-blue-800">
                                    Tooth #{tooth.position}
                                  </Badge>
                                  {tooth.treatmentGroupId && (
                                    <Badge variant="outline" className="text-xs">
                                      {treatmentGroups.find(g => g.id === tooth.treatmentGroupId)?.name}
                                    </Badge>
                                  )}
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleToothClick(tooth.position)}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <Label className="text-xs">Shade</Label>
                                  <Input
                                    value={tooth.shade}
                                    onChange={(e) => updateToothData(tooth.position, 'shade', e.target.value)}
                                    placeholder="e.g., A2"
                                    className="text-xs"
                                  />
                                </div>
                                <div>
                                  <Label className="text-xs">Notes</Label>
                                  <Input
                                    value={tooth.notes}
                                    onChange={(e) => updateToothData(tooth.position, 'notes', e.target.value)}
                                    placeholder="Special notes..."
                                    className="text-xs"
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between pt-4">
                      <Button variant="outline" onClick={() => setActiveStep(1)}>
                        Previous: Patient Info
                      </Button>
                      <Button onClick={() => setActiveStep(3)}>
                        Next: Attachments
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Step 3: File Attachments */}
              <TabsContent value="3" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="w-5 h-5 text-blue-600" />
                      File Attachments
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* File Upload Area */}
                    <div
                      className={`
                        border-2 border-dashed rounded-lg p-8 text-center transition-colors
                        ${isDragOver 
                          ? 'border-blue-400 bg-blue-50' 
                          : 'border-gray-300 bg-gray-50 hover:border-gray-400'
                        }
                      `}
                      onDragOver={(e) => {
                        e.preventDefault();
                        setIsDragOver(true);
                      }}
                      onDragLeave={(e) => {
                        e.preventDefault();
                        setIsDragOver(false);
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        setIsDragOver(false);
                        if (e.dataTransfer.files) {
                          handleFileUpload(e.dataTransfer.files);
                        }
                      }}
                    >
                      <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="font-medium text-gray-700 mb-2">
                        Upload Files
                      </h3>
                      <p className="text-gray-500 mb-4">
                        Drag and drop files here, or click to select
                      </p>
                      <input
                        type="file"
                        multiple
                        accept="image/*,.stl,.ply,.pdf,.doc,.docx"
                        onChange={(e) => {
                          if (e.target.files) {
                            handleFileUpload(e.target.files);
                          }
                        }}
                        className="hidden"
                        id="file-upload"
                      />
                      <label
                        htmlFor="file-upload"
                        className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Select Files
                      </label>
                    </div>

                    {/* Uploaded Files */}
                    {attachments.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="font-medium text-gray-700">Uploaded Files ({attachments.length})</h4>
                        <div className="grid grid-cols-1 gap-3">
                          {attachments.map((file) => (
                            <div key={file.id} className="flex items-center justify-between p-3 bg-white border rounded-lg">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                                  {file.type === 'image' && <Image className="w-5 h-5 text-gray-600" />}
                                  {file.type === 'xray' && <FileText className="w-5 h-5 text-gray-600" />}
                                  {(file.type === 'stl' || file.type === 'ply') && <File className="w-5 h-5 text-gray-600" />}
                                  {file.type === 'other' && <File className="w-5 h-5 text-gray-600" />}
                                </div>
                                <div>
                                  <p className="font-medium text-sm">{file.name}</p>
                                  <p className="text-xs text-gray-500">
                                    {formatFileSize(file.size)} • {file.type.toUpperCase()}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button size="sm" variant="ghost">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  onClick={() => removeAttachment(file.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between pt-4">
                      <Button variant="outline" onClick={() => setActiveStep(2)}>
                        Previous: Dental Chart
                      </Button>
                      <Button onClick={() => setActiveStep(4)}>
                        Next: Checklist
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Step 4: Treatment Checklist */}
              <TabsContent value="4" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      Pre-Treatment Checklist
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {checklist.length > 0 ? (
                      <div className="space-y-4">
                        {checklist.map((item) => (
                          <div key={item.id} className="space-y-3 p-4 border rounded-lg">
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={item.checked}
                                onCheckedChange={(checked) => 
                                  updateChecklistItem(item.id, 'checked', !!checked)
                                }
                                className="mt-1"
                              />
                              <div className="flex-1">
                                <label className="text-sm font-medium cursor-pointer">
                                  {item.text}
                                </label>
                                <div className="mt-2">
                                  <Textarea
                                    value={item.comment}
                                    onChange={(e) => 
                                      updateChecklistItem(item.id, 'comment', e.target.value)
                                    }
                                    placeholder="Add comments or notes..."
                                    className="text-xs"
                                    rows={2}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="font-medium text-gray-700 mb-2">No Checklist Available</h3>
                        <p className="text-gray-500">
                          Select a treatment type to see the relevant checklist items.
                        </p>
                      </div>
                    )}

                    <div className="flex justify-between pt-4">
                      <Button variant="outline" onClick={() => setActiveStep(3)}>
                        Previous: Attachments
                      </Button>
                      <Button onClick={() => setActiveStep(5)}>
                        Next: Review & Submit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Step 5: Review & Submit */}
              <TabsContent value="5" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="w-5 h-5 text-blue-600" />
                      Review & Submit Case
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Case Summary */}
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Case Information</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Title:</span>
                              <span className="font-medium">{title || 'Not specified'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Patient:</span>
                              <span className="font-medium">{selectedPatient?.name || patientName || 'Not specified'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Priority:</span>
                              <Badge variant="outline" className="capitalize">
                                {priority}
                              </Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Due Date:</span>
                              <span className="font-medium">
                                {dueDate ? new Date(dueDate).toLocaleDateString() : 'Not specified'}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Treatment Groups</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Total Groups:</span>
                              <span className="font-medium">{treatmentGroups.length}</span>
                            </div>
                            {treatmentGroups.map((group, index) => (
                              <div key={group.id} className="bg-gray-50 rounded p-2 space-y-1">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Group {index + 1}:</span>
                                  <span className="font-medium">{group.treatmentType.replace('_', ' ')}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Teeth:</span>
                                  <span className="font-medium">{group.teeth.length} teeth</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Material:</span>
                                  <span className="font-medium">{MATERIALS[group.material as keyof typeof MATERIALS] || group.material}</span>
                                </div>
                              </div>
                            ))}
                            {treatmentGroups.length === 0 && (
                              <div className="text-gray-500 text-center py-2">
                                No treatment groups created
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Selected Teeth</h4>
                          <div className="flex flex-wrap gap-1">
                            {selectedTeeth.length > 0 ? (
                              selectedTeeth.map((tooth) => (
                                <Badge key={tooth.id} variant="outline" className="text-xs">
                                  #{tooth.position}
                                </Badge>
                              ))
                            ) : (
                              <span className="text-sm text-gray-500">No teeth selected</span>
                            )}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Attachments</h4>
                          <p className="text-sm text-gray-600">
                            {attachments.length} file(s) attached
                          </p>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Checklist Progress</h4>
                          <p className="text-sm text-gray-600">
                            {checklist.filter(item => item.checked).length} of {checklist.length} items completed
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Validation Issues */}
                    {validationIssues.length > 0 && (
                      <Alert className="border-red-200 bg-red-50">
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                        <AlertDescription className="text-red-800">
                          Please address the following issues before submitting:
                          <ul className="list-disc list-inside mt-2 space-y-1">
                            {validationIssues.map((issue, index) => (
                              <li key={index} className="text-sm">{issue}</li>
                            ))}
                          </ul>
                        </AlertDescription>
                      </Alert>
                    )}

                    <div className="flex justify-between pt-4">
                      <Button variant="outline" onClick={() => setActiveStep(4)}>
                        Previous: Checklist
                      </Button>
                      <div className="flex gap-2">
                        <Button variant="outline" onClick={handleSaveDraft}>
                          <Save className="w-4 h-4 mr-2" />
                          Save Draft
                        </Button>
                        <Button onClick={handleSubmitToConsultant} className="bg-blue-600 hover:bg-blue-700">
                          <Send className="w-4 h-4 mr-2" />
                          Submit to Consultant
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar with Case Summary */}
          <div className="col-span-4">
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle className="text-lg">Case Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Progress</span>
                    <span className="font-medium">{activeStep}/5 steps</span>
                  </div>
                  <Progress value={(activeStep / 5) * 100} className="h-2" />
                </div>

                <Separator />

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Patient:</span>
                    <span className="font-medium">{selectedPatient?.name || patientName || 'Not set'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Treatment Groups:</span>
                    <span className="font-medium">{treatmentGroups.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Unassigned Teeth:</span>
                    <span className="font-medium">{getUnassignedTeeth().length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Selected Teeth:</span>
                    <span className="font-medium">{selectedTeeth.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Attachments:</span>
                    <span className="font-medium">{attachments.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Due Date:</span>
                    <span className="font-medium">
                      {dueDate ? new Date(dueDate).toLocaleDateString() : 'Not set'}
                    </span>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full" onClick={handleSaveDraft}>
                    <Save className="w-4 h-4 mr-2" />
                    Save Draft
                  </Button>
                  <Button size="sm" className="w-full" onClick={handleSubmitToConsultant}>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Case
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Validation Dialog */}
        <AlertDialog open={showValidationDialog} onOpenChange={setShowValidationDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Validation Issues
              </AlertDialogTitle>
              <AlertDialogDescription>
                Please address the following issues before submitting your case:
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-2">
              {validationIssues.map((issue, index) => (
                <div key={index} className="flex items-center gap-2 text-sm text-red-700">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  {issue}
                </div>
              ))}
            </div>
            <AlertDialogFooter>
              <AlertDialogAction onClick={() => setShowValidationDialog(false)}>
                I'll fix these issues
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}