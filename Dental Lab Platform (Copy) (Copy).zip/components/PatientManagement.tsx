import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { SearchableSelect } from './ui/searchable-select';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { ArrowLeft, Plus, Search, UserPlus, Phone, Mail, Calendar, FileText } from 'lucide-react';
import { User, Patient } from '../types';
import { mockPatients } from '../data/mockData';
import { GENDER_OPTIONS, COMMON_ALLERGIES } from '../utils/serviceOptions';

interface PatientManagementProps {
  currentUser: User;
  onBack: () => void;
}

export function PatientManagement({ currentUser, onBack }: PatientManagementProps) {
  const { t } = useLanguage();
  const [patients, setPatients] = useState<Patient[]>(
    mockPatients.filter(p => p.dentistId === currentUser.id)
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingPatient, setIsAddingPatient] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [newPatient, setNewPatient] = useState<Partial<Patient>>({
    name: '',
    age: 0,
    gender: 'male',
    phone: '',
    medicalHistory: '',
    allergies: [],
    dentistId: currentUser.id
  });

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone?.includes(searchTerm)
  );

  const handleAddPatient = () => {
    if (newPatient.name && newPatient.age) {
      const patient: Patient = {
        ...newPatient,
        id: Date.now().toString(),
        createdAt: new Date(),
        allergies: newPatient.allergies || []
      } as Patient;
      
      setPatients(prev => [patient, ...prev]);
      setNewPatient({
        name: '',
        age: 0,
        gender: 'male',
        phone: '',
        medicalHistory: '',
        allergies: [],
        dentistId: currentUser.id
      });
      setIsAddingPatient(false);
    }
  };

  const addAllergy = (allergy: string) => {
    if (allergy && !newPatient.allergies?.includes(allergy)) {
      setNewPatient(prev => ({
        ...prev,
        allergies: [...(prev.allergies || []), allergy]
      }));
    }
  };

  const removeAllergy = (allergy: string) => {
    setNewPatient(prev => ({
      ...prev,
      allergies: prev.allergies?.filter(a => a !== allergy) || []
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onBack} size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back')}
        </Button>
        <div>
          <h1 className="text-3xl font-bold">{t('patient_management')}</h1>
          <p className="text-gray-600 mt-1">{t('manage_patient_records')}</p>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder={t('search_patients')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Dialog open={isAddingPatient} onOpenChange={setIsAddingPatient}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              {t('add_patient')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('add_new_patient')}</DialogTitle>
              <DialogDescription>
                {t('enter_patient_information_to_add_to_system')}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">{t('full_name')}</Label>
                  <Input
                    id="name"
                    value={newPatient.name}
                    onChange={(e) => setNewPatient(prev => ({ ...prev, name: e.target.value }))}
                    placeholder={t('enter_full_name')}
                  />
                </div>
                <div>
                  <Label htmlFor="age">{t('age')}</Label>
                  <Input
                    id="age"
                    type="number"
                    value={newPatient.age}
                    onChange={(e) => setNewPatient(prev => ({ ...prev, age: parseInt(e.target.value) }))}
                    placeholder={t('enter_age')}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gender">{t('gender')}</Label>
                  <SearchableSelect
                    options={GENDER_OPTIONS}
                    value={newPatient.gender || ''}
                    onValueChange={(value) => setNewPatient(prev => ({ ...prev, gender: value as any }))}
                    placeholder="Select gender"
                    searchPlaceholder="Search gender options..."
                  />
                </div>
                <div>
                  <Label htmlFor="phone">{t('phone_number')}</Label>
                  <Input
                    id="phone"
                    value={newPatient.phone}
                    onChange={(e) => setNewPatient(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder={t('enter_phone_number')}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="medical-history">{t('medical_history')}</Label>
                <Textarea
                  id="medical-history"
                  value={newPatient.medicalHistory}
                  onChange={(e) => setNewPatient(prev => ({ ...prev, medicalHistory: e.target.value }))}
                  placeholder={t('enter_medical_history')}
                  rows={3}
                />
              </div>
              
              <div>
                <Label>{t('allergies')}</Label>
                <div className="space-y-3">
                  {/* Searchable Allergy Selection */}
                  <SearchableSelect
                    options={COMMON_ALLERGIES}
                    value=""
                    onValueChange={(value) => {
                      const allergyOption = COMMON_ALLERGIES.find(option => option.value === value);
                      if (allergyOption) {
                        addAllergy(allergyOption.label);
                      }
                    }}
                    placeholder="Select or add allergies"
                    searchPlaceholder="Search allergies..."
                    allowCustom={true}
                    onCustomValue={(customAllergy) => {
                      addAllergy(customAllergy);
                    }}
                  />
                  
                  {/* Manual Entry Option */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Or type custom allergy..."
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          addAllergy(e.currentTarget.value);
                          e.currentTarget.value = '';
                        }
                      }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={(e) => {
                        const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                        addAllergy(input.value);
                        input.value = '';
                      }}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  {/* Selected Allergies */}
                  <div className="flex flex-wrap gap-2">
                    {newPatient.allergies?.map((allergy, index) => (
                      <Badge
                        key={index}
                        variant="destructive"
                        className="cursor-pointer hover:bg-red-700"
                        onClick={() => removeAllergy(allergy)}
                      >
                        {allergy} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAddingPatient(false)}>
                {t('cancel')}
              </Button>
              <Button onClick={handleAddPatient}>
                {t('add_patient')}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <ScrollArea className="h-[calc(100vh-250px)]">
        <div className="grid gap-4 pr-4">
          {filteredPatients.length > 0 ? (
            filteredPatients.map((patient) => (
              <Card key={patient.id} className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback>
                        {patient.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <div>
                        <h3 className="font-semibold text-lg">{patient.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>{patient.age} {t('years_old')}</span>
                          <span className="capitalize">{patient.gender}</span>
                          {patient.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {patient.phone}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {patient.medicalHistory && (
                        <div className="bg-blue-50 p-3 rounded border">
                          <p className="text-sm font-medium text-blue-900 mb-1">
                            <FileText className="w-4 h-4 inline mr-1" />
                            {t('medical_history')}
                          </p>
                          <p className="text-sm text-blue-800">{patient.medicalHistory}</p>
                        </div>
                      )}
                      
                      {patient.allergies && patient.allergies.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          <span className="text-sm font-medium text-red-700">{t('allergies')}:</span>
                          {patient.allergies.map((allergy, index) => (
                            <Badge key={index} variant="destructive" className="text-xs">
                              {allergy}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {t('added')} {patient.createdAt.toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="p-8 text-center">
              <UserPlus className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">{t('no_patients_found')}</h3>
              <p className="text-gray-600 mb-4">{t('add_patients_to_get_started')}</p>
              <Button onClick={() => setIsAddingPatient(true)}>
                <UserPlus className="w-4 h-4 mr-2" />
                {t('add_first_patient')}
              </Button>
            </Card>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}