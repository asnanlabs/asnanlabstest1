import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "./ui/avatar";
import { ScrollArea } from "./ui/scroll-area";
import { Separator } from "./ui/separator";
import { SearchableSelect } from "./ui/searchable-select";
import { toast } from "sonner@2.0.3";
import { formatDate } from "../utils/dateUtils";
import {
  ArrowLeft,
  UserPlus,
  CheckCircle,
  XCircle,
  Clock,
  FileText,
  Eye,
  Download,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  Shield,
  Award,
  AlertTriangle,
  DollarSign,
  Calculator,
  Plus,
  Target,
} from "lucide-react";
import {
  User,
  AccountRequest,
  ServicePrice,
  PricingOverride,
} from "../types";
import {
  generateServiceOptions,
  generateMaterialOptions,
  getServiceByKey,
  getMaterialByKey,
  ROLE_OPTIONS,
} from "../utils/serviceOptions";

interface AccountManagementProps {
  currentUser: User;
  onBack: () => void;
}

export function AccountManagement({
  currentUser,
  onBack,
}: AccountManagementProps) {
  const { t } = useLanguage();
  const {
    accountRequests,
    approveAccount,
    rejectAccount,
    getPendingRequests,
  } = useAuth();
  const [activeTab, setActiveTab] = useState("pending");
  const [selectedRequest, setSelectedRequest] =
    useState<AccountRequest | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(
    null,
  );
  const [showApprovalDialog, setShowApprovalDialog] =
    useState(false);
  const [showRejectionDialog, setShowRejectionDialog] =
    useState(false);
  const [showPricingDialog, setShowPricingDialog] =
    useState(false);
  const [assignedRole, setAssignedRole] = useState("");
  const [rejectionNotes, setRejectionNotes] = useState("");
  const [approvalNotes, setApprovalNotes] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [selectedMaterial, setSelectedMaterial] = useState("");

  // Mock approved users for demonstration
  const mockApprovedUsers: User[] = [
    {
      id: "1",
      name: "Dr. Ahmed Salem",
      role: "dentist",
      avatar:
        "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=100&h=100&fit=crop&crop=face",
      practice: "Salem Dental Clinic",
      specialization: "General Dentistry",
      location: "Dubai, UAE",
      status: "approved",
      approvedBy: "ALO@gmail.com",
      approvalDate: new Date("2024-01-15"),
      registrationDate: new Date("2024-01-10"),
    },
    {
      id: "2",
      name: "Advanced Dental Lab",
      role: "lab",
      avatar:
        "https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?w=100&h=100&fit=crop&crop=center",
      practice: "Advanced Dental Laboratory",
      specialization: "Crown & Bridge Manufacturing",
      location: "Sharjah, UAE",
      status: "approved",
      approvedBy: "ALO@gmail.com",
      approvalDate: new Date("2024-01-20"),
      registrationDate: new Date("2024-01-18"),
    },
    {
      id: "3",
      name: "Sarah Al-Mansouri",
      role: "designer",
      avatar:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
      practice: "Al-Mansouri Digital Design Studio",
      specialization: "CAD Design & Digital Modeling",
      location: "Dubai, UAE",
      status: "approved",
      approvedBy: "ALO@gmail.com",
      approvalDate: new Date("2024-01-25"),
      registrationDate: new Date("2024-01-22"),
    },
    {
      id: "4",
      name: "Dr. Khalid Al-Zahra",
      role: "supervisor",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      practice: "Regional Quality Control Center",
      specialization: "Quality Assurance & Team Management",
      location: "Dubai Healthcare City, UAE",
      status: "approved",
      approvedBy: "ALO@gmail.com",
      approvalDate: new Date("2024-02-01"),
      registrationDate: new Date("2024-01-28"),
    },
  ];

  // Use comprehensive service options from shared utility
  const serviceOptions = generateServiceOptions();
  const materialOptions = generateMaterialOptions();

  const pendingRequests = getPendingRequests();
  const approvedRequests = accountRequests.filter(
    (req) => req.status === "approved",
  );
  const rejectedRequests = accountRequests.filter(
    (req) => req.status === "rejected",
  );

  const handleApproval = async () => {
    if (!selectedRequest || !assignedRole) return;

    const success = await approveAccount(
      selectedRequest.id,
      assignedRole,
      approvalNotes,
    );
    if (success) {
      toast.success("Account approved successfully");
      setShowApprovalDialog(false);
      setSelectedRequest(null);
      setAssignedRole("");
      setApprovalNotes("");
    } else {
      toast.error("Failed to approve account");
    }
  };

  const handleRejection = async () => {
    if (!selectedRequest || !rejectionNotes.trim()) return;

    const success = await rejectAccount(
      selectedRequest.id,
      rejectionNotes,
    );
    if (success) {
      toast.success("Account rejected");
      setShowRejectionDialog(false);
      setSelectedRequest(null);
      setRejectionNotes("");
    } else {
      toast.error("Failed to reject account");
    }
  };

  const handleCustomPricing = (user: User) => {
    setSelectedUser(user);
    setSelectedService("");
    setSelectedMaterial("");
    setShowPricingDialog(true);
  };

  const handleCreatePricingOverride = () => {
    // This would integrate with the FinancialManagement system
    toast.success("Custom pricing created successfully");
    setShowPricingDialog(false);
    setSelectedUser(null);
    setSelectedService("");
    setSelectedMaterial("");
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: {
        className: "bg-yellow-100 text-yellow-800",
        icon: Clock,
      },
      approved: {
        className: "bg-green-100 text-green-800",
        icon: CheckCircle,
      },
      rejected: {
        className: "bg-red-100 text-red-800",
        icon: XCircle,
      },
    };

    const variant = variants[status as keyof typeof variants];
    const Icon = variant.icon;

    return (
      <Badge className={variant.className}>
        <Icon className="w-3 h-3 mr-1" />
        {status}
      </Badge>
    );
  };

  const getRoleColor = (role: string) => {
    const colors = {
      dentist: "bg-cyan-100 text-cyan-800",
      lab: "bg-blue-100 text-blue-800",
      designer: "bg-orange-100 text-orange-800",
      supervisor: "bg-green-100 text-green-800",
      owner: "bg-purple-100 text-purple-800",
    };
    return (
      colors[role as keyof typeof colors] ||
      "bg-gray-100 text-gray-800"
    );
  };

  // Filter users based on search and role filter
  const filteredApprovedUsers = mockApprovedUsers.filter(
    (user) => {
      const matchesSearch =
        searchQuery === "" ||
        user.name
          .toLowerCase()
          .includes(searchQuery.toLowerCase()) ||
        user.practice
          .toLowerCase()
          .includes(searchQuery.toLowerCase()) ||
        user.location
          .toLowerCase()
          .includes(searchQuery.toLowerCase());

      const matchesRole =
        filterRole === "" || user.role === filterRole;

      return matchesSearch && matchesRole;
    },
  );

  const handleClosePricingDialog = (open: boolean) => {
    setShowPricingDialog(open);
    if (!open) {
      setSelectedUser(null);
      setSelectedService("");
      setSelectedMaterial("");
    }
  };

  // Custom Pricing Dialog Component
  const CustomPricingDialog = () => (
    <Dialog
      open={showPricingDialog}
      onOpenChange={handleClosePricingDialog}
    >
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Custom Pricing for {selectedUser?.name}
          </DialogTitle>
          <DialogDescription>
            Set custom pricing overrides for this user's
            account. Choose from the complete catalog of dental
            services.
          </DialogDescription>
        </DialogHeader>

        {selectedUser && (
          <div className="space-y-6">
            {/* User Info Summary */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={selectedUser.avatar} />
                  <AvatarFallback>
                    {selectedUser.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">
                    {selectedUser.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedUser.practice}
                  </p>
                  <Badge
                    className={getRoleColor(selectedUser.role)}
                  >
                    {selectedUser.role}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Pricing Override Form */}
            <div className="max-h-[500px] overflow-y-auto space-y-4 border rounded-md p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Service Type</Label>
                  <SearchableSelect
                    options={serviceOptions}
                    value={selectedService}
                    placeholder="Select service type"
                    searchPlaceholder="Search all dental services..."
                    onValueChange={(value) => {
                      setSelectedService(value);
                      const service = getServiceByKey(value);
                      console.log("Service selected:", service);
                    }}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Choose from {serviceOptions.length}{" "}
                    available services across all categories
                  </p>
                </div>
                <div>
                  <Label>Current Base Price</Label>
                  <Input
                    value="$350.00"
                    disabled
                    className="bg-gray-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Custom Price</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="number"
                      className="pl-10"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                <div>
                  <Label>Discount Percentage</Label>
                  <Input type="number" placeholder="0" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Effective From</Label>
                  <Input type="date" />
                </div>
                <div>
                  <Label>Effective To (Optional)</Label>
                  <Input type="date" />
                </div>
              </div>

              <div>
                <Label>Material Override (Optional)</Label>
                <SearchableSelect
                  options={materialOptions}
                  value={selectedMaterial}
                  placeholder="Override material pricing"
                  searchPlaceholder="Search materials..."
                  allowCustom={true}
                  onValueChange={(value) => {
                    setSelectedMaterial(value);
                    const material = getMaterialByKey(value);
                    console.log("Material selected:", material);
                  }}
                  onCustomValue={(customMaterial) => {
                    console.log(
                      "Custom material added:",
                      customMaterial,
                    );
                  }}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Set specific pricing for material variations
                </p>
              </div>

              <div>
                <Label>Reason for Custom Pricing</Label>
                <Textarea placeholder="Explain the reason for this custom pricing override..." />
              </div>

              {/* Pricing Preview */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">
                  Pricing Preview
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Original Price:</span>
                    <span className="line-through text-gray-500">
                      $350.00
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Custom Price:</span>
                    <span className="font-medium text-green-600">
                      $320.00
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span className="font-medium text-blue-600">
                      8.6% ($30.00)
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium">
                    <span>Total Savings:</span>
                    <span className="text-green-600">
                      $30.00 per case
                    </span>
                  </div>
                </div>
              </div>

              {/* Service Information */}
              <div className="bg-gray-50 border rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">
                  Service Information
                </h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">
                      Category:
                    </span>
                    <p className="font-medium">
                      Fixed Prosthodontics
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600">
                      Requires Material:
                    </span>
                    <p className="font-medium">Yes</p>
                  </div>
                  <div>
                    <span className="text-gray-600">
                      Available Materials:
                    </span>
                    <p className="font-medium">
                      {materialOptions.length} options
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600">
                      Standard Lead Time:
                    </span>
                    <p className="font-medium">
                      3-5 business days
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => handleClosePricingDialog(false)}
          >
            Cancel
          </Button>
          <Button onClick={handleCreatePricingOverride}>
            <Plus className="w-4 h-4 mr-2" />
            Create Custom Pricing
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">
              Account Management
            </h1>
            <p className="text-gray-600 mt-1">
              Review and manage user accounts with comprehensive
              service pricing
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {pendingRequests.length > 0 && (
            <Badge className="bg-yellow-100 text-yellow-800">
              {pendingRequests.length} Pending
            </Badge>
          )}
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="p-6 border-l-4 border-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">
                Pending Approval
              </p>
              <p className="text-3xl font-bold">
                {pendingRequests.length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-yellow-500" />
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">
                Approved Users
              </p>
              <p className="text-3xl font-bold">
                {mockApprovedUsers.length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-red-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Rejected</p>
              <p className="text-3xl font-bold">
                {rejectedRequests.length}
              </p>
            </div>
            <XCircle className="w-8 h-8 text-red-500" />
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">
                Available Services
              </p>
              <p className="text-3xl font-bold">
                {serviceOptions.length}
              </p>
            </div>
            <Calculator className="w-8 h-8 text-blue-500" />
          </div>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pending">
            Pending ({pendingRequests.length})
          </TabsTrigger>
          <TabsTrigger value="approved">
            Approved ({mockApprovedUsers.length})
          </TabsTrigger>
          <TabsTrigger value="rejected">
            Rejected ({rejectedRequests.length})
          </TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Pending Requests Tab */}
        <TabsContent value="pending" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Pending Account Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingRequests.length > 0 ? (
                <ScrollArea className="h-[calc(100vh-400px)]">
                  <div className="space-y-4 pr-4">
                    {pendingRequests.map((request) => (
                      <Card key={request.id} className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <Avatar className="w-12 h-12">
                              <AvatarImage
                                src={request.user.avatar}
                              />
                              <AvatarFallback>
                                {request.user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="font-semibold text-lg">
                                {request.user.name}
                              </h3>
                              <p className="text-gray-600">
                                {request.user.practice}
                              </p>
                              <p className="text-sm text-gray-500">
                                {request.user.location}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge
                                  className={getRoleColor(
                                    request.requestedRole,
                                  )}
                                >
                                  {request.requestedRole}
                                </Badge>
                                <Badge variant="outline">
                                  {request.user.specialization}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-500">
                              Submitted{" "}
                              {formatDate(request.submittedAt)}
                            </p>
                            <div className="flex gap-2 mt-4">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedRequest(request);
                                  setShowRejectionDialog(true);
                                }}
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Reject
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => {
                                  setSelectedRequest(request);
                                  setAssignedRole(
                                    request.requestedRole,
                                  );
                                  setShowApprovalDialog(true);
                                }}
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Approve
                              </Button>
                            </div>
                          </div>
                        </div>

                        {request.user.licenseInfo && (
                          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                            <h4 className="font-medium mb-2">
                              License Information
                            </h4>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-gray-600">
                                  License Number:
                                </span>
                                <p className="font-medium">
                                  {
                                    request.user.licenseInfo
                                      .licenseNumber
                                  }
                                </p>
                              </div>
                              <div>
                                <span className="text-gray-600">
                                  Issuing Authority:
                                </span>
                                <p className="font-medium">
                                  {
                                    request.user.licenseInfo
                                      .issuingAuthority
                                  }
                                </p>
                              </div>
                              <div>
                                <span className="text-gray-600">
                                  Expiry Date:
                                </span>
                                <p className="font-medium">
                                  {formatDate(
                                    request.user.licenseInfo
                                      .expiryDate,
                                  )}
                                </p>
                              </div>
                              <div>
                                <span className="text-gray-600">
                                  Documents:
                                </span>
                                <div className="flex gap-2 mt-1">
                                  {request.user.licenseInfo.documents.map(
                                    (doc, index) => (
                                      <Button
                                        key={index}
                                        variant="ghost"
                                        size="sm"
                                      >
                                        <FileText className="w-3 h-3 mr-1" />
                                        {doc}
                                      </Button>
                                    ),
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">
                    No Pending Requests
                  </h3>
                  <p className="text-gray-600">
                    All account requests have been reviewed.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Approved Users Tab */}
        <TabsContent value="approved" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Approved Users
              </CardTitle>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search users..."
                    className="pl-10 w-64"
                    value={searchQuery}
                    onChange={(e) =>
                      setSearchQuery(e.target.value)
                    }
                  />
                </div>
                <SearchableSelect
                  options={ROLE_OPTIONS}
                  value={filterRole}
                  onValueChange={setFilterRole}
                  placeholder="Filter by role"
                  className="w-48"
                />
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[calc(100vh-400px)]">
                <div className="space-y-4 pr-4">
                  {filteredApprovedUsers.map((user) => (
                    <Card key={user.id} className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>
                              {user.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold text-lg">
                              {user.name}
                            </h3>
                            <p className="text-gray-600">
                              {user.practice}
                            </p>
                            <p className="text-sm text-gray-500">
                              {user.location}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge
                                className={getRoleColor(
                                  user.role,
                                )}
                              >
                                {user.role}
                              </Badge>
                              <Badge variant="outline">
                                {user.specialization}
                              </Badge>
                              {getStatusBadge(
                                user.status || "approved",
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-500">
                            Approved{" "}
                            {formatDate(user.approvalDate)}
                          </p>
                          <div className="flex gap-2 mt-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                handleCustomPricing(user)
                              }
                              className="bg-green-50 hover:bg-green-100 border-green-200"
                            >
                              <DollarSign className="w-4 h-4 mr-1" />
                              Custom Pricing
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="w-4 h-4 mr-1" />
                              Edit
                            </Button>
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-1" />
                              View Profile
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">
                              Registration Date:
                            </span>
                            <p className="font-medium">
                              {formatDate(
                                user.registrationDate,
                              )}
                            </p>
                          </div>
                          <div>
                            <span className="text-gray-600">
                              Approved By:
                            </span>
                            <p className="font-medium">
                              {user.approvedBy}
                            </p>
                          </div>
                          <div>
                            <span className="text-gray-600">
                              Account Status:
                            </span>
                            <p className="font-medium text-green-600">
                              Active
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Rejected Requests Tab */}
        <TabsContent value="rejected" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <XCircle className="w-5 h-5" />
                Rejected Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              {rejectedRequests.length > 0 ? (
                <ScrollArea className="h-[calc(100vh-400px)]">
                  <div className="space-y-4 pr-4">
                    {rejectedRequests.map((request) => (
                      <Card
                        key={request.id}
                        className="p-6 border-l-4 border-red-500"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <Avatar className="w-12 h-12">
                              <AvatarImage
                                src={request.user.avatar}
                              />
                              <AvatarFallback>
                                {request.user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="font-semibold text-lg">
                                {request.user.name}
                              </h3>
                              <p className="text-gray-600">
                                {request.user.practice}
                              </p>
                              <p className="text-sm text-gray-500">
                                {request.user.location}
                              </p>
                              <Badge
                                className={getRoleColor(
                                  request.requestedRole,
                                )}
                              >
                                {request.requestedRole}
                              </Badge>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-500">
                              Rejected{" "}
                              {formatDate(request.reviewedAt)}
                            </p>
                            {getStatusBadge("rejected")}
                          </div>
                        </div>

                        {request.notes && (
                          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                            <h4 className="font-medium text-red-900 mb-2">
                              Rejection Reason:
                            </h4>
                            <p className="text-red-800 text-sm">
                              {request.notes}
                            </p>
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">
                    No Rejected Requests
                  </h3>
                  <p className="text-gray-600">
                    No account requests have been rejected.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Account Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      Approval Rate
                    </span>
                    <span className="font-semibold">94.2%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      Average Review Time
                    </span>
                    <span className="font-semibold">
                      1.3 days
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      Most Common Role
                    </span>
                    <span className="font-semibold">
                      Dentist (45%)
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      Available Services
                    </span>
                    <span className="font-semibold">
                      {serviceOptions.length} services
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Service Catalog</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-green-500" />
                    <span className="text-sm">
                      Fixed Prosthodontics: 6 services
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">
                      Removable Prosthodontics: 6 services
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">
                      Implant Components: 5 services
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-orange-500" />
                    <span className="text-sm">
                      Digital Services: 4 services
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-pink-500" />
                    <span className="text-sm">
                      Other Categories:{" "}
                      {serviceOptions.length - 21} services
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Approval Dialog */}
      <Dialog
        open={showApprovalDialog}
        onOpenChange={setShowApprovalDialog}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Account</DialogTitle>
            <DialogDescription>
              Review and approve this account request
            </DialogDescription>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage
                    src={selectedRequest.user.avatar}
                  />
                  <AvatarFallback>
                    {selectedRequest.user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">
                    {selectedRequest.user.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedRequest.user.practice}
                  </p>
                </div>
              </div>

              <div>
                <Label>Assign Role</Label>
                <SearchableSelect
                  options={ROLE_OPTIONS.filter(
                    (role) => role.value !== "",
                  )}
                  value={assignedRole}
                  onValueChange={setAssignedRole}
                  placeholder="Select role"
                />
              </div>

              <div>
                <Label>Approval Notes (Optional)</Label>
                <Textarea
                  placeholder="Add any notes for this approval..."
                  value={approvalNotes}
                  onChange={(e) =>
                    setApprovalNotes(e.target.value)
                  }
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowApprovalDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleApproval}
              disabled={!assignedRole}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog
        open={showRejectionDialog}
        onOpenChange={setShowRejectionDialog}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Account</DialogTitle>
            <DialogDescription>
              Provide a reason for rejecting this account
              request
            </DialogDescription>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage
                    src={selectedRequest.user.avatar}
                  />
                  <AvatarFallback>
                    {selectedRequest.user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">
                    {selectedRequest.user.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedRequest.user.practice}
                  </p>
                </div>
              </div>

              <div>
                <Label>Rejection Reason</Label>
                <Textarea
                  placeholder="Please provide a detailed reason for rejection..."
                  value={rejectionNotes}
                  onChange={(e) =>
                    setRejectionNotes(e.target.value)
                  }
                  required
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowRejectionDialog(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleRejection}
              disabled={!rejectionNotes.trim()}
            >
              <XCircle className="w-4 h-4 mr-2" />
              Reject Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom Pricing Dialog */}
      <CustomPricingDialog />
    </div>
  );
}