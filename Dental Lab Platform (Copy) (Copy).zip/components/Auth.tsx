import React, { useState } from 'react';
import { LoginPage } from './LoginPage';
import { SignupPage } from './SignupPage';

type AuthView = 'login' | 'signup';

export function Auth() {
  const [currentView, setCurrentView] = useState<AuthView>('login');

  const switchToLogin = () => setCurrentView('login');
  const switchToSignup = () => setCurrentView('signup');

  return (
    <>
      {currentView === 'login' && (
        <LoginPage onSwitchToSignup={switchToSignup} />
      )}
      {currentView === 'signup' && (
        <SignupPage onSwitchToLogin={switchToLogin} />
      )}
    </>
  );
}