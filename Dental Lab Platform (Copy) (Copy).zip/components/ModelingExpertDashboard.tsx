import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';
import { 
  Palette, 
  Clock, 
  CheckCircle, 
  Eye, 
  Play,
  Pause,
  RotateCcw,
  Layers,
  Zap,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { User, Case } from '../types';
import { mockCases } from '../data/mockData';

interface ModelingExpertDashboardProps {
  currentUser: User;
  onViewCase: (caseId: string) => void;
}

export function ModelingExpertDashboard({ currentUser, onViewCase }: ModelingExpertDashboardProps) {
  const { t } = useLanguage();
  const [selectedTab, setSelectedTab] = useState('active');

  // Filter cases assigned to this designer
  const designerCases = mockCases.filter(c => c.designer?.id === currentUser.id) || [];
  const activeCases = designerCases.filter(c => ['assigned', 'in_progress'].includes(c.status));
  const completedCases = designerCases.filter(c => ['completed', 'delivered'].includes(c.status));
  const inProgressCases = designerCases.filter(c => c.status === 'in_progress');
  const pendingCases = designerCases.filter(c => c.status === 'assigned');

  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'text-green-600',
      medium: 'text-yellow-600',
      high: 'text-orange-600',
      urgent: 'text-red-600'
    };
    return colors[priority];
  };

  const getProgressPercentage = (caseItem: Case) => {
    if (!caseItem.progress || caseItem.progress.length === 0) return 0;
    const completed = caseItem.progress.filter(step => step.status === 'completed').length;
    return (completed / caseItem.progress.length) * 100;
  };

  const getCaseTypeIcon = (type: Case['type']) => {
    switch (type) {
      case 'crown':
        return <Layers className="w-4 h-4" />;
      case 'bridge':
        return <RotateCcw className="w-4 h-4" />;
      case 'implant':
        return <Zap className="w-4 h-4" />;
      default:
        return <Palette className="w-4 h-4" />;
    }
  };

  const getDaysUntilDue = (dueDate: Date) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const renderCaseCard = (caseItem: Case, showProgress = true) => (
    <Card key={caseItem.id} className="p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            {getCaseTypeIcon(caseItem.type)}
          </div>
          <div>
            <h3 className="font-semibold text-lg">{caseItem.title}</h3>
            <p className="text-gray-600">{t('patient')}: {caseItem.patient.name}</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className="text-xs capitalize">
                {t(caseItem.type)}
              </Badge>
              {caseItem.material && (
                <Badge variant="outline" className="text-xs capitalize">
                  {caseItem.material}
                </Badge>
              )}
              {caseItem.subType && (
                <Badge variant="outline" className="text-xs capitalize">
                  {t(caseItem.subType)}
                </Badge>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={`${getStatusColor(caseItem.status)} text-white`}>
            {t(caseItem.status.replace('_', ' '))}
          </Badge>
          <span className={`text-sm font-medium capitalize ${getPriorityColor(caseItem.priority)}`}>
            {t(caseItem.priority)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-8 h-8">
            <AvatarImage src={caseItem.dentist.avatar} />
            <AvatarFallback>
              {caseItem.dentist.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium text-sm">{caseItem.dentist.name}</p>
            <p className="text-xs text-gray-600">{caseItem.dentist.practice}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">
            {getDaysUntilDue(caseItem.dueDate) > 0 
              ? `${getDaysUntilDue(caseItem.dueDate)} ${t('days_left')}`
              : `${Math.abs(getDaysUntilDue(caseItem.dueDate))} ${t('days_overdue')}`
            }
          </span>
          {getDaysUntilDue(caseItem.dueDate) <= 1 && (
            <AlertTriangle className="w-4 h-4 text-red-500" />
          )}
        </div>
      </div>

      {caseItem.description && (
        <p className="text-gray-700 text-sm mb-4 line-clamp-2">{caseItem.description}</p>
      )}

      {showProgress && caseItem.progress && caseItem.progress.length > 0 && (
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>{t('design_progress')}</span>
            <span>{Math.round(getProgressPercentage(caseItem))}%</span>
          </div>
          <Progress value={getProgressPercentage(caseItem)} className="h-2" />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>{caseItem.progress.filter(s => s.status === 'completed').length} / {caseItem.progress.length} {t('steps')}</span>
            <span>{t('estimated')}: {caseItem.progress.reduce((acc, step) => acc + step.estimatedHours, 0)}h</span>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          {caseItem.status === 'assigned' && (
            <Button size="sm" className="gap-1">
              <Play className="w-3 h-3" />
              {t('start_design')}
            </Button>
          )}
          {caseItem.status === 'in_progress' && (
            <Button size="sm" variant="outline" className="gap-1">
              <Pause className="w-3 h-3" />
              {t('pause')}
            </Button>
          )}
        </div>
        <Button variant="ghost" size="sm" onClick={() => onViewCase(caseItem.id)} className="gap-1">
          <Eye className="w-3 h-3" />
          {t('view_details')}
        </Button>
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('cad_design_workspace')}</h1>
        <p className="text-gray-600 mt-1">{t('manage_design_assignments')}</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('total_assignments')}</p>
              <p className="text-2xl font-bold">{designerCases.length}</p>
            </div>
            <Palette className="w-8 h-8 text-purple-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('in_progress')}</p>
              <p className="text-2xl font-bold">{inProgressCases.length}</p>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('pending_start')}</p>
              <p className="text-2xl font-bold">{pendingCases.length}</p>
            </div>
            <Play className="w-8 h-8 text-blue-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('completed')}</p>
              <p className="text-2xl font-bold">{completedCases.length}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">
            {t('active_designs')} ({activeCases.length})
          </TabsTrigger>
          <TabsTrigger value="pending">
            {t('pending_start')} ({pendingCases.length})
          </TabsTrigger>
          <TabsTrigger value="completed">
            {t('completed')} ({completedCases.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-6">
          <div className="space-y-4">
            {activeCases.length > 0 ? (
              activeCases.map(caseItem => renderCaseCard(caseItem))
            ) : (
              <Card className="p-8 text-center">
                <Palette className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{t('no_active_designs')}</h3>
                <p className="text-gray-600">{t('start_new_design_assignments')}</p>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="mt-6">
          <div className="space-y-4">
            {pendingCases.length > 0 ? (
              pendingCases.map(caseItem => renderCaseCard(caseItem, false))
            ) : (
              <Card className="p-8 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{t('no_pending_assignments')}</h3>
                <p className="text-gray-600">{t('all_assignments_started')}</p>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <div className="space-y-4">
            {completedCases.length > 0 ? (
              completedCases.map(caseItem => renderCaseCard(caseItem, false))
            ) : (
              <Card className="p-8 text-center">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{t('no_completed_designs')}</h3>
                <p className="text-gray-600">{t('completed_designs_will_appear_here')}</p>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}