import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { 
  ArrowLeft, 
  CheckCircle, 
  Clock, 
  MessageSquare, 
  Paperclip, 
  Calendar,
  User,
  Building,
  AlertCircle,
  Download,
  Send
} from 'lucide-react';
import { Case, User as UserType, CaseNote } from '../types';
import { mockCases } from '../data/mockData';
import { NotificationService } from '../utils/notificationService';

interface CaseDetailProps {
  caseId: string;
  currentUser: UserType;
  onBack: () => void;
}

export function CaseDetail({ caseId, currentUser, onBack }: CaseDetailProps) {
  const [caseData, setCaseData] = useState<Case | null>(
    mockCases.find(c => c.id === caseId) || null
  );
  const [newNote, setNewNote] = useState('');

  if (!caseData) {
    return (
      <div className="flex items-center justify-center h-64">
        <p>Case not found</p>
      </div>
    );
  }

  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'text-green-600 bg-green-100',
      medium: 'text-yellow-600 bg-yellow-100',
      high: 'text-orange-600 bg-orange-100',
      urgent: 'text-red-600 bg-red-100'
    };
    return colors[priority];
  };

  const getProgressPercentage = () => {
    if (caseData.progress.length === 0) return 0;
    const completed = caseData.progress.filter(step => step.status === 'completed').length;
    return (completed / caseData.progress.length) * 100;
  };

  const addNote = () => {
    if (!newNote.trim() || !caseData) return;

    const note: CaseNote = {
      id: Math.random().toString(36).substr(2, 9),
      content: newNote,
      author: currentUser,
      createdAt: new Date(),
      isInternal: false
    };

    setCaseData(prev => prev ? {
      ...prev,
      notes: [...prev.notes, note]
    } : null);
    
    // Create notification for the other party
    const recipient = currentUser.role === 'dentist' ? caseData.lab : caseData.dentist;
    if (recipient) {
      NotificationService.createCommentNotification(caseData, currentUser, recipient);
    }
    
    setNewNote('');
  };

  const updateStepStatus = (stepId: string, status: 'pending' | 'in_progress' | 'completed') => {
    if (!caseData) return;
    
    const step = caseData.progress.find(s => s.id === stepId);
    if (!step) return;

    setCaseData(prev => prev ? {
      ...prev,
      progress: prev.progress.map(step => 
        step.id === stepId 
          ? { 
              ...step, 
              status, 
              completedAt: status === 'completed' ? new Date() : undefined 
            }
          : step
      )
    } : null);

    // Create notification for progress update
    if (status === 'completed' && caseData.dentist) {
      NotificationService.createProgressUpdateNotification(
        caseData, 
        step.title, 
        currentUser, 
        caseData.dentist
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">{caseData.title}</h1>
          <p className="text-gray-600">Case ID: {caseData.id}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={`${getStatusColor(caseData.status)} text-white`}>
            {caseData.status.replace('_', ' ')}
          </Badge>
          <Badge className={getPriorityColor(caseData.priority)}>
            {caseData.priority}
          </Badge>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Case Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Case Overview */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Case Overview</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Patient</p>
                  <p className="font-medium">{caseData.patient.name}</p>
                  <p className="text-sm text-gray-500">
                    {caseData.patient.age}y, {caseData.patient.gender}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Building className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Dentist</p>
                  <p className="font-medium">{caseData.dentist.name}</p>
                  <p className="text-sm text-gray-500">{caseData.dentist.practice}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Due Date</p>
                  <p className="font-medium">{caseData.dueDate.toLocaleDateString()}</p>
                </div>
              </div>
              {caseData.lab && (
                <div className="flex items-center gap-3">
                  <Building className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Assigned Lab</p>
                    <p className="font-medium">{caseData.lab.labName}</p>
                  </div>
                </div>
              )}
            </div>
            <Separator className="my-4" />
            <div>
              <h4 className="font-medium mb-2">Description</h4>
              <p className="text-gray-700 mb-4">{caseData.description}</p>
              {caseData.instructions && (
                <>
                  <h4 className="font-medium mb-2">Lab Instructions</h4>
                  <p className="text-gray-700">{caseData.instructions}</p>
                </>
              )}
            </div>
          </Card>

          {/* Progress Tracking */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Progress Tracking</h3>
              <div className="text-sm text-gray-600">
                {Math.round(getProgressPercentage())}% Complete
              </div>
            </div>
            <Progress value={getProgressPercentage()} className="mb-6" />
            
            <div className="space-y-4">
              {caseData.progress.map((step, index) => (
                <div key={step.id} className="flex items-start gap-4">
                  <div className="flex-shrink-0 mt-1">
                    {step.status === 'completed' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : step.status === 'in_progress' ? (
                      <Clock className="w-5 h-5 text-yellow-500" />
                    ) : (
                      <div className="w-5 h-5 border-2 border-gray-300 rounded-full" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{step.title}</h4>
                      {currentUser.role === 'lab' && step.status !== 'completed' && (
                        <div className="flex gap-1">
                          {step.status === 'pending' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => updateStepStatus(step.id, 'in_progress')}
                            >
                              Start
                            </Button>
                          )}
                          {step.status === 'in_progress' && (
                            <Button 
                              size="sm"
                              onClick={() => updateStepStatus(step.id, 'completed')}
                            >
                              Complete
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{step.description}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>Est: {step.estimatedHours}h</span>
                      {step.actualHours && <span>Actual: {step.actualHours}h</span>}
                      {step.completedAt && (
                        <span>Completed: {step.completedAt.toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Files and Attachments */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Files & Attachments</h3>
            {caseData.files.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {caseData.files.map((file) => (
                  <div key={file.id} className="flex items-center gap-3 p-3 border rounded-lg">
                    <Paperclip className="w-4 h-4 text-gray-400" />
                    <div className="flex-1">
                      <p className="font-medium text-sm">{file.name}</p>
                      <p className="text-xs text-gray-500">
                        {file.type} • {file.uploadedAt.toLocaleDateString()}
                      </p>
                    </div>
                    <Button size="sm" variant="ghost">
                      <Download className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No files uploaded yet</p>
            )}
          </Card>
        </div>

        {/* Right Column - Communication */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <Card className="p-4">
            <h3 className="font-semibold mb-3">Quick Actions</h3>
            <div className="space-y-2">
              {currentUser.role === 'dentist' && caseData.status === 'completed' && (
                <Button className="w-full">Mark as Received</Button>
              )}
              {currentUser.role === 'lab' && caseData.status === 'quality_check' && (
                <Button className="w-full">Ship to Dentist</Button>
              )}
              <Button variant="outline" className="w-full">
                <Paperclip className="w-4 h-4 mr-2" />
                Add Files
              </Button>
            </div>
          </Card>

          {/* Case Notes */}
          <Card className="p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Case Notes ({caseData.notes.length})
            </h3>
            
            {/* Add Note */}
            <div className="space-y-3 mb-4">
              <Textarea
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add a note or update..."
                rows={3}
              />
              <Button onClick={addNote} disabled={!newNote.trim()} className="w-full gap-2">
                <Send className="w-3 h-3" />
                Send Note
              </Button>
            </div>

            <Separator className="my-4" />

            {/* Notes List */}
            <ScrollArea className="h-80">
              <div className="space-y-4 pr-4">
              {caseData.notes.map((note) => (
                <div key={note.id} className="flex gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={note.author.avatar} />
                    <AvatarFallback>
                      {note.author.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{note.author.name}</span>
                      <span className="text-xs text-gray-500">
                        {note.createdAt.toLocaleDateString()} {note.createdAt.toLocaleTimeString()}
                      </span>
                      {note.isInternal && (
                        <Badge variant="secondary" className="text-xs">Internal</Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-700">{note.content}</p>
                  </div>
                </div>
              ))}
              </div>
            </ScrollArea>
          </Card>
        </div>
      </div>
    </div>
  );
}