import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { ArrowLeft, Search, Filter, Calendar as CalendarIcon, DollarSign, Clock, CheckCircle, Eye } from 'lucide-react';
import { User, Case, CaseFilter } from '../types';
import { mockCases } from '../data/mockData';

interface CaseHistoryProps {
  currentUser: User;
  onBack: () => void;
  onViewCase: (caseId: string) => void;
}

export function CaseHistory({ currentUser, onBack, onViewCase }: CaseHistoryProps) {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<CaseFilter>({});
  const [dateRange, setDateRange] = useState<{ from: Date | null; to: Date | null }>({
    from: null,
    to: null
  });

  // Get cases based on user role and history
  const getUserCases = () => {
    const userCaseIds = currentUser.caseHistory || [];
    let relevantCases = mockCases.filter(c => userCaseIds.includes(c.id));
    
    // Filter based on role-specific logic
    if (currentUser.role === 'dentist') {
      relevantCases = mockCases.filter(c => c.dentist.id === currentUser.id);
    } else if (currentUser.role === 'lab') {
      relevantCases = mockCases.filter(c => c.lab?.id === currentUser.id);
    } else if (currentUser.role === 'supervisor') {
      relevantCases = mockCases.filter(c => c.supervisor?.id === currentUser.id);
    } else if (currentUser.role === 'designer') {
      relevantCases = mockCases.filter(c => c.designer?.id === currentUser.id);
    } else if (currentUser.role === 'owner') {
      relevantCases = mockCases; // Owner sees all cases
    }
    
    return relevantCases;
  };

  const cases = getUserCases();
  
  // Separate active and completed cases
  const activeCases = cases.filter(c => !['completed', 'delivered'].includes(c.status));
  const completedCases = cases.filter(c => ['completed', 'delivered'].includes(c.status));

  const applyFilters = (casesToFilter: Case[]) => {
    return casesToFilter.filter(caseItem => {
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        if (!caseItem.title.toLowerCase().includes(searchLower) &&
            !caseItem.patient.name.toLowerCase().includes(searchLower) &&
            !caseItem.id.includes(searchTerm)) {
          return false;
        }
      }

      // Status filter
      if (activeFilter.status && activeFilter.status.length > 0) {
        if (!activeFilter.status.includes(caseItem.status)) return false;
      }

      // Type filter
      if (activeFilter.type && activeFilter.type.length > 0) {
        if (!activeFilter.type.includes(caseItem.type)) return false;
      }

      // Material filter
      if (activeFilter.material && activeFilter.material.length > 0) {
        if (!caseItem.material || !activeFilter.material.includes(caseItem.material)) return false;
      }

      // Date range filter
      if (dateRange.from && dateRange.to) {
        const caseDate = new Date(caseItem.createdAt);
        if (caseDate < dateRange.from || caseDate > dateRange.to) return false;
      }

      return true;
    });
  };

  const filteredActiveCases = applyFilters(activeCases);
  const filteredCompletedCases = applyFilters(completedCases);

  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'border-green-200 bg-green-50',
      medium: 'border-yellow-200 bg-yellow-50',
      high: 'border-orange-200 bg-orange-50',
      urgent: 'border-red-200 bg-red-50'
    };
    return colors[priority];
  };

  const getTotalFinancials = (casesToCalculate: Case[]) => {
    return casesToCalculate.reduce((total, caseItem) => {
      return total + (caseItem.financialInfo?.totalCost || 0);
    }, 0);
  };

  const renderCaseCard = (caseItem: Case) => (
    <Card key={caseItem.id} className={`p-6 border-l-4 ${getPriorityColor(caseItem.priority)}`}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-semibold text-lg">{caseItem.title}</h3>
          <p className="text-gray-600">{t('case_id')}: {caseItem.id}</p>
          <p className="text-gray-600">{t('patient')}: {caseItem.patient.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={`${getStatusColor(caseItem.status)} text-white`}>
            {t(caseItem.status.replace('_', ' '))}
          </Badge>
          <Badge variant="outline" className="capitalize">
            {t(caseItem.priority)}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <p className="text-sm text-gray-500">{t('type')}</p>
          <p className="font-medium capitalize">{t(caseItem.type)}</p>
          {caseItem.subType && (
            <p className="text-sm text-gray-600 capitalize">{t(caseItem.subType)}</p>
          )}
        </div>
        <div>
          <p className="text-sm text-gray-500">{t('material')}</p>
          <p className="font-medium capitalize">{caseItem.material || 'N/A'}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">{t('created_date')}</p>
          <p className="font-medium">{caseItem.createdAt.toLocaleDateString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-8 h-8">
            <AvatarImage src={caseItem.dentist.avatar} />
            <AvatarFallback>
              {caseItem.dentist.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{caseItem.dentist.name}</p>
            <p className="text-sm text-gray-600">{caseItem.dentist.practice}</p>
          </div>
        </div>
        
        {caseItem.financialInfo && (
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-green-600" />
            <div>
              <p className="font-medium text-green-600">
                ${caseItem.financialInfo.totalCost} {caseItem.financialInfo.currency}
              </p>
              <p className="text-sm text-gray-600 capitalize">
                {t(caseItem.financialInfo.paymentStatus)}
              </p>
            </div>
          </div>
        )}
      </div>

      {caseItem.workHistory && caseItem.workHistory.length > 0 && (
        <div className="mb-4 p-3 bg-gray-50 rounded">
          <h4 className="font-medium text-gray-900 mb-2 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            {t('work_history')}
          </h4>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {caseItem.workHistory.slice(-3).map((entry) => (
              <div key={entry.id} className="text-sm">
                <span className="font-medium">{entry.userName}</span>
                <span className="text-gray-600"> • {entry.action}</span>
                <span className="text-gray-500 ml-2">
                  {entry.timestamp.toLocaleDateString()}
                </span>
                {entry.hoursSpent && (
                  <span className="text-gray-500 ml-2">
                    ({entry.hoursSpent}h)
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4 text-sm text-gray-600">
          <span className="flex items-center gap-1">
            <CalendarIcon className="w-4 h-4" />
            {t('due')}: {caseItem.dueDate.toLocaleDateString()}
          </span>
          {caseItem.actualCompletion && (
            <span className="flex items-center gap-1 text-green-600">
              <CheckCircle className="w-4 h-4" />
              {t('completed')}: {caseItem.actualCompletion.toLocaleDateString()}
            </span>
          )}
        </div>
        <Button variant="outline" onClick={() => onViewCase(caseItem.id)}>
          <Eye className="w-4 h-4 mr-2" />
          {t('view_details')}
        </Button>
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onBack} size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back')}
        </Button>
        <div>
          <h1 className="text-3xl font-bold">{t('case_history')}</h1>
          <p className="text-gray-600 mt-1">{t('track_all_your_cases')}</p>
        </div>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder={t('search_cases')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select 
            value={activeFilter.status?.[0] || 'all'} 
            onValueChange={(value) => setActiveFilter(prev => ({ ...prev, status: value === 'all' ? [] : [value as Case['status']] }))}
          >
            <SelectTrigger>
              <SelectValue placeholder={t('filter_by_status')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('all_statuses')}</SelectItem>
              <SelectItem value="submitted">{t('submitted')}</SelectItem>
              <SelectItem value="assigned">{t('assigned')}</SelectItem>
              <SelectItem value="in_progress">{t('in_progress')}</SelectItem>
              <SelectItem value="quality_check">{t('quality_check')}</SelectItem>
              <SelectItem value="completed">{t('completed')}</SelectItem>
              <SelectItem value="delivered">{t('delivered')}</SelectItem>
            </SelectContent>
          </Select>
          
          <Select 
            value={activeFilter.type?.[0] || 'all'} 
            onValueChange={(value) => setActiveFilter(prev => ({ ...prev, type: value === 'all' ? [] : [value as Case['type']] }))}
          >
            <SelectTrigger>
              <SelectValue placeholder={t('filter_by_type')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('all_types')}</SelectItem>
              <SelectItem value="crown">{t('crown')}</SelectItem>
              <SelectItem value="bridge">{t('bridge')}</SelectItem>
              <SelectItem value="implant">{t('implant')}</SelectItem>
              <SelectItem value="veneer">{t('veneer')}</SelectItem>
              <SelectItem value="denture">{t('denture')}</SelectItem>
            </SelectContent>
          </Select>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline">
                <CalendarIcon className="w-4 h-4 mr-2" />
                {t('date_range')}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="range"
                selected={{ from: dateRange.from || undefined, to: dateRange.to || undefined }}
                onSelect={(range) => setDateRange({ from: range?.from || null, to: range?.to || null })}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
        </div>
      </Card>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">
            {t('active_cases')} ({filteredActiveCases.length})
          </TabsTrigger>
          <TabsTrigger value="completed">
            {t('completed_cases')} ({filteredCompletedCases.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-6">
          <div className="space-y-4">
            {currentUser.role === 'owner' && (
              <Card className="p-4 bg-blue-50 border-blue-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-blue-900">{t('active_cases_summary')}</h3>
                    <p className="text-blue-700">{filteredActiveCases.length} {t('cases_in_progress')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-blue-900">
                      ${getTotalFinancials(filteredActiveCases).toFixed(2)}
                    </p>
                    <p className="text-blue-700">{t('total_value')}</p>
                  </div>
                </div>
              </Card>
            )}
            
            {filteredActiveCases.length > 0 ? (
              <div className="grid gap-4">
                {filteredActiveCases.map(renderCaseCard)}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{t('no_active_cases')}</h3>
                <p className="text-gray-600">{t('no_cases_match_filters')}</p>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <div className="space-y-4">
            {currentUser.role === 'owner' && (
              <Card className="p-4 bg-green-50 border-green-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-green-900">{t('completed_cases_summary')}</h3>
                    <p className="text-green-700">{filteredCompletedCases.length} {t('cases_completed')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-900">
                      ${getTotalFinancials(filteredCompletedCases).toFixed(2)}
                    </p>
                    <p className="text-green-700">{t('total_revenue')}</p>
                  </div>
                </div>
              </Card>
            )}
            
            {filteredCompletedCases.length > 0 ? (
              <div className="grid gap-4">
                {filteredCompletedCases.map(renderCaseCard)}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">{t('no_completed_cases')}</h3>
                <p className="text-gray-600">{t('completed_cases_will_appear_here')}</p>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}