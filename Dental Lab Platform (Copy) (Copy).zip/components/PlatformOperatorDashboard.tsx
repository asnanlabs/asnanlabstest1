import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  Users, 
  Building2, 
  TrendingUp, 
  DollarSign, 
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Settings,
  UserPlus,
  Shield,
  BarChart3,
  PieChart,
  Calendar,
  Bell,
  Calculator,
  CreditCard
} from 'lucide-react';
import { User } from '../types';

interface PlatformOperatorDashboardProps {
  currentUser: User;
  onViewCase: (caseId: string) => void;
  onCaseHistory: () => void;
  onAccountManagement?: () => void;
  onFinancialManagement?: () => void;
}

export function PlatformOperatorDashboard({ 
  currentUser, 
  onViewCase, 
  onCaseHistory,
  onAccountManagement,
  onFinancialManagement 
}: PlatformOperatorDashboardProps) {
  const { t } = useLanguage();
  const { getPendingRequests } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  
  const pendingAccountsCount = getPendingRequests().length;

  // Mock platform statistics
  const platformStats = {
    totalUsers: 1247,
    activeCases: 89,
    monthlyRevenue: 45670,
    systemUptime: 99.8,
    newRegistrations: 23,
    completedCases: 445,
    averageProcessingTime: 2.8,
    customerSatisfaction: 4.7,
    totalCommissions: 6850,
    averageCaseValue: 228.5
  };

  // Mock recent activity
  const recentActivity = [
    {
      id: '1',
      type: 'user_registration',
      message: 'New dentist registration from Dr. Sarah Al-Mansouri',
      timestamp: '2 hours ago',
      status: 'pending'
    },
    {
      id: '2',
      type: 'case_completed',
      message: 'Crown case #CR-2024-156 completed by Advanced Dental Lab',
      timestamp: '4 hours ago',
      status: 'completed'
    },
    {
      id: '3',
      type: 'payment_received',
      message: 'Payment received for case #BR-2024-089 - $340',
      timestamp: '6 hours ago',
      status: 'success'
    },
    {
      id: '4',
      type: 'quality_issue',
      message: 'Quality concern reported for case #IM-2024-023',
      timestamp: '8 hours ago',
      status: 'warning'
    }
  ];

  // Mock user distribution by role
  const usersByRole = [
    { role: 'dentist', count: 567, percentage: 45.5 },
    { role: 'lab', count: 234, percentage: 18.8 },
    { role: 'designer', count: 189, percentage: 15.2 },
    { role: 'supervisor', count: 145, percentage: 11.6 },
    { role: 'owner', count: 112, percentage: 9.0 }
  ];

  // Mock financial data
  const financialData = [
    { month: 'Jan', revenue: 32400, cases: 145 },
    { month: 'Feb', revenue: 38200, cases: 167 },
    { month: 'Mar', revenue: 41800, cases: 189 },
    { month: 'Apr', revenue: 45670, cases: 203 }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user_registration': return UserPlus;
      case 'case_completed': return CheckCircle;
      case 'payment_received': return DollarSign;
      case 'quality_issue': return AlertTriangle;
      default: return Activity;
    }
  };

  const getActivityColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'completed': return 'text-green-600 bg-green-100';
      case 'success': return 'text-blue-600 bg-blue-100';
      case 'warning': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getRoleColor = (role: string) => {
    const colors = {
      dentist: 'bg-cyan-100 text-cyan-800',
      lab: 'bg-blue-100 text-blue-800',
      designer: 'bg-orange-100 text-orange-800',
      supervisor: 'bg-green-100 text-green-800',
      owner: 'bg-purple-100 text-purple-800'
    };
    return colors[role as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Platform Administration</h1>
          <p className="text-gray-600 mt-1">
            Comprehensive platform management and analytics
          </p>
        </div>
        <div className="flex items-center gap-3">
          {pendingAccountsCount > 0 && (
            <Button 
              onClick={onAccountManagement}
              className="bg-yellow-600 hover:bg-yellow-700"
            >
              <Bell className="w-4 h-4 mr-2" />
              {pendingAccountsCount} Pending Approvals
            </Button>
          )}
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            Platform Settings
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-3xl font-bold">{platformStats.totalUsers.toLocaleString()}</p>
              <p className="text-sm text-green-600 mt-1">
                +{platformStats.newRegistrations} this month
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Monthly Revenue</p>
              <p className="text-3xl font-bold">${platformStats.monthlyRevenue.toLocaleString()}</p>
              <p className="text-sm text-green-600 mt-1">+12.5% from last month</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-orange-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Cases</p>
              <p className="text-3xl font-bold">{platformStats.activeCases}</p>
              <p className="text-sm text-orange-600 mt-1">
                {platformStats.averageProcessingTime} days avg
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Activity className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Platform Commission</p>
              <p className="text-3xl font-bold">${platformStats.totalCommissions.toLocaleString()}</p>
              <p className="text-sm text-purple-600 mt-1">This month</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">
            User Management
            {pendingAccountsCount > 0 && (
              <Badge className="ml-2 bg-yellow-500 text-white">
                {pendingAccountsCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Recent Platform Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity) => {
                    const Icon = getActivityIcon(activity.type);
                    return (
                      <div key={activity.id} className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getActivityColor(activity.status)}`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm">{activity.message}</p>
                          <p className="text-xs text-gray-500">{activity.timestamp}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  onClick={onFinancialManagement}
                  className="w-full justify-start bg-green-600 hover:bg-green-700"
                >
                  <Calculator className="w-4 h-4 mr-2" />
                  Financial Management
                </Button>

                <Button 
                  onClick={onAccountManagement}
                  className="w-full justify-start"
                  variant={pendingAccountsCount > 0 ? "default" : "outline"}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Account Management
                  {pendingAccountsCount > 0 && (
                    <Badge className="ml-auto bg-yellow-500 text-white">
                      {pendingAccountsCount}
                    </Badge>
                  )}
                </Button>
                
                <Button onClick={onCaseHistory} variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  View Case History
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Generate Reports
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="w-4 h-4 mr-2" />
                  Platform Settings
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* User Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                User Distribution by Role
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {usersByRole.map((roleData) => (
                  <div key={roleData.role} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge className={getRoleColor(roleData.role)}>
                        {roleData.role}
                      </Badge>
                      <span className="text-sm text-gray-600">{roleData.count} users</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={roleData.percentage} className="w-20 h-2" />
                      <span className="text-sm text-gray-500 w-12 text-right">
                        {roleData.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Management Tab */}
        <TabsContent value="users" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                User Management Center
              </CardTitle>
              <Button onClick={onAccountManagement} className="bg-blue-600 hover:bg-blue-700">
                <UserPlus className="w-4 h-4 mr-2" />
                Manage Accounts
                {pendingAccountsCount > 0 && (
                  <Badge className="ml-2 bg-yellow-500 text-white">
                    {pendingAccountsCount}
                  </Badge>
                )}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="p-4 bg-yellow-50 border-yellow-200">
                  <div className="flex items-center gap-3">
                    <Clock className="w-8 h-8 text-yellow-600" />
                    <div>
                      <p className="font-semibold text-yellow-900">Pending Approval</p>
                      <p className="text-2xl font-bold text-yellow-700">{pendingAccountsCount}</p>
                      <p className="text-sm text-yellow-600">Require review</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-green-50 border-green-200">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                    <div>
                      <p className="font-semibold text-green-900">Active Users</p>
                      <p className="text-2xl font-bold text-green-700">1,247</p>
                      <p className="text-sm text-green-600">Approved accounts</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-blue-50 border-blue-200">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="w-8 h-8 text-blue-600" />
                    <div>
                      <p className="font-semibold text-blue-900">Growth Rate</p>
                      <p className="text-2xl font-bold text-blue-700">+12%</p>
                      <p className="text-sm text-blue-600">This month</p>
                    </div>
                  </div>
                </Card>
              </div>

              <div className="mt-6">
                <p className="text-gray-600 mb-4">
                  Manage user registrations, approve new accounts, and oversee platform access.
                  Click "Manage Accounts" to review pending registrations and assign appropriate roles.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Financial Tab */}
        <TabsContent value="financial" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Financial Management Center
              </CardTitle>
              <Button onClick={onFinancialManagement} className="bg-green-600 hover:bg-green-700">
                <Calculator className="w-4 h-4 mr-2" />
                Advanced Financial Management
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                {financialData.map((data) => (
                  <Card key={data.month} className="p-4">
                    <div>
                      <p className="text-sm text-gray-600">{data.month} 2024</p>
                      <p className="text-xl font-bold">${data.revenue.toLocaleString()}</p>
                      <p className="text-sm text-gray-500">{data.cases} cases</p>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-4 bg-green-50 border-green-200 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={onFinancialManagement}>
                  <div className="flex items-center gap-3">
                    <Calculator className="w-8 h-8 text-green-600" />
                    <div>
                      <p className="font-semibold text-green-900">Service Pricing</p>
                      <p className="text-sm text-green-600">Manage pricing for all services</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-blue-50 border-blue-200 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={onFinancialManagement}>
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-8 h-8 text-blue-600" />
                    <div>
                      <p className="font-semibold text-blue-900">Custom Pricing</p>
                      <p className="text-sm text-blue-600">Account-specific pricing overrides</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-purple-50 border-purple-200 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={onFinancialManagement}>
                  <div className="flex items-center gap-3">
                    <BarChart3 className="w-8 h-8 text-purple-600" />
                    <div>
                      <p className="font-semibold text-purple-900">Revenue Analytics</p>
                      <p className="text-sm text-purple-600">Detailed financial reports</p>
                    </div>
                  </div>
                </Card>
              </div>

              <div className="mt-6">
                <p className="text-gray-600 mb-4">
                  Comprehensive financial management tools for pricing, commissions, and revenue optimization.
                  Click "Advanced Financial Management" to access detailed pricing controls and analytics.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Case Processing Time</span>
                    <span className="font-semibold">{platformStats.averageProcessingTime} days</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Customer Satisfaction</span>
                    <span className="font-semibold">{platformStats.customerSatisfaction}/5.0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Cases Completed This Month</span>
                    <span className="font-semibold">{platformStats.completedCases}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Case Value</span>
                    <span className="font-semibold">${platformStats.averageCaseValue}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Uptime</span>
                    <Badge className="bg-green-100 text-green-800">
                      {platformStats.systemUptime}%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Response Time</span>
                    <span className="font-semibold">&lt; 200ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Error Rate</span>
                    <Badge className="bg-green-100 text-green-800">0.02%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Platform Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <DollarSign className="w-8 h-8 text-green-600" />
                    <div>
                      <h3 className="font-medium">Financial Reports</h3>
                      <p className="text-sm text-gray-600">Revenue and payment analytics</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Users className="w-8 h-8 text-blue-600" />
                    <div>
                      <h3 className="font-medium">User Activity</h3>
                      <p className="text-sm text-gray-600">Platform usage statistics</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Activity className="w-8 h-8 text-purple-600" />
                    <div>
                      <h3 className="font-medium">Case Analytics</h3>
                      <p className="text-sm text-gray-600">Case flow and completion rates</p>
                    </div>
                  </div>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Tab */}
        <TabsContent value="system" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                System Administration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h3 className="font-semibold">Platform Configuration</h3>
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="w-4 h-4 mr-2" />
                    General Settings
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Shield className="w-4 h-4 mr-2" />
                    Security Settings
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Bell className="w-4 h-4 mr-2" />
                    Notification Settings
                  </Button>
                </div>
                <div className="space-y-3">
                  <h3 className="font-semibold">Data Management</h3>
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="w-4 h-4 mr-2" />
                    Export Data
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Activity className="w-4 h-4 mr-2" />
                    System Logs
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Analytics Reports
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}