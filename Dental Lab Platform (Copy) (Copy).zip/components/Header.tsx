import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { NotificationDropdown } from './NotificationDropdown';
import { LanguageSwitcher } from './LanguageSwitcher';
import { AsnanLabsLogo } from './AsnanLabsLogo';
import { Crown, User, Settings, LogOut, Repeat, Building2, Stethoscope, Palette, Shield, Cog } from 'lucide-react';
import { User as UserType } from '../types';

interface HeaderProps {
  currentUser: UserType;
  onSwitchRole: (role?: string) => void;
  onViewCase: (caseId: string) => void;
  onViewProfile?: () => void;
  onLogout?: () => void;
}

export function Header({ currentUser, onSwitchRole, onViewCase, onViewProfile, onLogout }: HeaderProps) {
  const { t, language } = useLanguage();

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'dentist': return Stethoscope;
      case 'lab': return Building2;
      case 'designer': return Palette;
      case 'supervisor': return Cog;
      case 'owner': return Shield;
      default: return User;
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'dentist': return 'Dental Practice';
      case 'lab': return 'Laboratory';
      case 'designer': return 'CAD Designer';
      case 'supervisor': return 'Quality Supervisor';
      case 'owner': return 'Platform Owner';
      default: return 'User';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'dentist': return 'bg-cyan-100 text-cyan-800';
      case 'lab': return 'bg-blue-100 text-blue-800';
      case 'designer': return 'bg-orange-100 text-orange-800';
      case 'supervisor': return 'bg-green-100 text-green-800';
      case 'owner': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const RoleIcon = getRoleIcon(currentUser.role);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <AsnanLabsLogo 
              width={160} 
              height={48} 
              color="#030213"
              className="text-gray-900"
            />
            <div className="flex items-center gap-2">
              <Badge className={`text-xs ${getRoleColor(currentUser.role)}`}>
                <RoleIcon className="w-3 h-3 mr-1" />
                {getRoleLabel(currentUser.role)}
              </Badge>
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            
            <NotificationDropdown 
              currentUser={currentUser} 
              onViewCase={onViewCase}
            />

            {/* Demo Role Switch */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Repeat className="w-4 h-4" />
                  Demo Mode
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5 text-sm font-semibold text-gray-900">
                  Switch Demo Role
                </div>
                <DropdownMenuSeparator />
                
                <DropdownMenuItem onClick={() => onSwitchRole('dentist')}>
                  <Stethoscope className="w-4 h-4 mr-2" />
                  <div>
                    <div className="font-medium">Dental Practice</div>
                    <div className="text-xs text-gray-500">Patient care & case management</div>
                  </div>
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => onSwitchRole('lab')}>
                  <Building2 className="w-4 h-4 mr-2" />
                  <div>
                    <div className="font-medium">Laboratory</div>
                    <div className="text-xs text-gray-500">Case processing & manufacturing</div>
                  </div>
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => onSwitchRole('designer')}>
                  <Palette className="w-4 h-4 mr-2" />
                  <div>
                    <div className="font-medium">CAD Designer</div>
                    <div className="text-xs text-gray-500">Digital modeling & design</div>
                  </div>
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => onSwitchRole('supervisor')}>
                  <Cog className="w-4 h-4 mr-2" />
                  <div>
                    <div className="font-medium">Quality Supervisor</div>
                    <div className="text-xs text-gray-500">Quality control & team management</div>
                  </div>
                </DropdownMenuItem>

                <DropdownMenuItem onClick={() => onSwitchRole('owner')}>
                  <Shield className="w-4 h-4 mr-2" />
                  <div>
                    <div className="font-medium">Platform Owner</div>
                    <div className="text-xs text-gray-500">Full platform management</div>
                  </div>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-3 px-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                    <AvatarFallback>
                      {currentUser.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden md:block">
                    <p className="font-medium text-gray-900">{currentUser.name}</p>
                    <p className="text-sm text-gray-600">{currentUser.practice}</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="font-medium text-gray-900">{currentUser.name}</p>
                  <p className="text-sm text-gray-500">{currentUser.practice}</p>
                  <p className="text-xs text-gray-400">{currentUser.location}</p>
                </div>
                <DropdownMenuSeparator />
                
                {onViewProfile && (
                  <DropdownMenuItem onClick={onViewProfile}>
                    <User className="w-4 h-4 mr-2" />
                    View Profile
                  </DropdownMenuItem>
                )}
                
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  {t('settings')}
                </DropdownMenuItem>
                
                <DropdownMenuSeparator />
                
                {onLogout && (
                  <DropdownMenuItem onClick={onLogout} className="text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}