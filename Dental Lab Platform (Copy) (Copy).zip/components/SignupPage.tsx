import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth, SignupData } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { LanguageSwitcher } from './LanguageSwitcher';
import { AsnanLabsLogo } from './AsnanLabsLogo';
import { 
  ArrowRight, 
  ArrowLeft, 
  Eye, 
  EyeOff, 
  User, 
  Building2, 
  MapPin, 
  Briefcase,
  CheckCircle,
  Crown,
  Loader2,
  Stethoscope,
  Cog,
  Palette,
  Shield,
  Users
} from 'lucide-react';

interface SignupPageProps {
  onSwitchToLogin: () => void;
}

export function SignupPage({ onSwitchToLogin }: SignupPageProps) {
  const { t, isRTL } = useLanguage();
  const { signup, isLoading } = useAuth();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [predictedRole, setPredictedRole] = useState<string>('');

  const totalSteps = 4;

  const [formData, setFormData] = useState<SignupData>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phone: '',
    profession: '',
    organization: '',
    experience: '',
    specializations: [],
    country: '',
    city: '',
    primaryActivity: '',
    businessType: '',
    teamSize: '',
    serviceOffering: ''
  });

  const updateFormData = (field: keyof SignupData, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Real-time role prediction
    const updatedData = { ...formData, [field]: value };
    const role = predictUserRole(updatedData);
    setPredictedRole(role);
  };

  const predictUserRole = (data: SignupData): string => {
    // Platform Owner
    if (data.primaryActivity === 'platform_management' || 
        data.businessType === 'platform_operator' ||
        data.serviceOffering === 'platform_services') {
      return 'Platform Owner';
    }
    
    // Lab
    if (data.profession === 'dental_technician' ||
        data.businessType === 'dental_laboratory' ||
        data.serviceOffering === 'prosthetic_manufacturing' ||
        data.primaryActivity === 'laboratory_work') {
      return 'Dental Laboratory';
    }
    
    // Designer
    if (data.profession === 'cad_designer' ||
        data.specializations.includes('digital_design') ||
        data.primaryActivity === 'digital_modeling' ||
        data.serviceOffering === 'design_services') {
      return 'CAD Designer';
    }
    
    // Supervisor
    if (data.profession === 'quality_manager' ||
        data.primaryActivity === 'quality_control' ||
        data.serviceOffering === 'supervision_services') {
      return 'Quality Supervisor';
    }
    
    // Dentist
    if (data.profession === 'dentist' ||
        data.profession === 'oral_surgeon' ||
        data.profession === 'orthodontist' ||
        data.profession === 'prosthodontist') {
      return 'Dental Practitioner';
    }
    
    return '';
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'Platform Owner': return Shield;
      case 'Dental Laboratory': return Building2;
      case 'CAD Designer': return Palette;
      case 'Quality Supervisor': return Cog;
      case 'Dental Practitioner': return Stethoscope;
      default: return User;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Platform Owner': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Dental Laboratory': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'CAD Designer': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Quality Supervisor': return 'bg-green-100 text-green-700 border-green-200';
      case 'Dental Practitioner': return 'bg-cyan-100 text-cyan-700 border-cyan-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setError('');

    // Validation
    const requiredFields = ['firstName', 'lastName', 'email', 'password', 'profession'];
    const missingFields = requiredFields.filter(field => !formData[field as keyof SignupData]);
    
    if (missingFields.length > 0) {
      setError('Please fill in all required fields');
      return;
    }

    const success = await signup(formData);
    if (!success) {
      setError('Email already exists or signup failed. Please try again.');
    }
  };

  const toggleSpecialization = (spec: string) => {
    const current = formData.specializations;
    const updated = current.includes(spec)
      ? current.filter(s => s !== spec)
      : [...current, spec];
    updateFormData('specializations', updated);
  };

  const progressPercentage = (currentStep / totalSteps) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="w-full p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <AsnanLabsLogo 
              width={180} 
              height={54} 
              color="#030213"
              className="text-gray-900"
            />
            <div className="hidden sm:block">
              <p className="text-sm text-gray-600">Join Our Professional Network</p>
            </div>
          </div>
          <LanguageSwitcher />
        </div>
      </header>

      <div className="flex items-center justify-center px-6 py-12">
        <Card className="w-full max-w-2xl shadow-xl border-0">
          <CardHeader className="text-center space-y-4">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={onSwitchToLogin}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Login
              </Button>
              {predictedRole && (
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm border ${getRoleColor(predictedRole)}`}>
                  {React.createElement(getRoleIcon(predictedRole), { className: 'w-4 h-4' })}
                  {predictedRole}
                </div>
              )}
            </div>
            
            <div>
              <CardTitle className="text-2xl font-bold text-gray-900">Create Your Account</CardTitle>
              <p className="text-gray-600 mt-2">Step {currentStep} of {totalSteps}</p>
            </div>
            
            <Progress value={progressPercentage} className="h-2" />
          </CardHeader>
          
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Step 1: Basic Information */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Basic Information</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => updateFormData('firstName', e.target.value)}
                      placeholder="Enter your first name"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => updateFormData('lastName', e.target.value)}
                      placeholder="Enter your last name"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateFormData('email', e.target.value)}
                    placeholder="Enter your email address"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="password">Password *</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) => updateFormData('password', e.target.value)}
                      placeholder="Create a secure password"
                      className="mt-1 pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => updateFormData('phone', e.target.value)}
                    placeholder="Enter your phone number"
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            {/* Step 2: Professional Information */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Briefcase className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Professional Details</h3>
                </div>
                
                <div>
                  <Label htmlFor="profession">What is your primary profession? *</Label>
                  <Select value={formData.profession} onValueChange={(value) => updateFormData('profession', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select your profession" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dentist">Dentist / General Practitioner</SelectItem>
                      <SelectItem value="oral_surgeon">Oral & Maxillofacial Surgeon</SelectItem>
                      <SelectItem value="orthodontist">Orthodontist</SelectItem>
                      <SelectItem value="prosthodontist">Prosthodontist</SelectItem>
                      <SelectItem value="dental_technician">Dental Technician</SelectItem>
                      <SelectItem value="cad_designer">CAD Designer / Digital Specialist</SelectItem>
                      <SelectItem value="quality_manager">Quality Control Manager</SelectItem>
                      <SelectItem value="lab_owner">Laboratory Owner</SelectItem>
                      <SelectItem value="platform_admin">Platform Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="organization">Organization / Practice Name</Label>
                  <Input
                    id="organization"
                    value={formData.organization}
                    onChange={(e) => updateFormData('organization', e.target.value)}
                    placeholder="e.g., Smith Dental Clinic, Advanced Lab"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="experience">Years of Experience</Label>
                  <Select value={formData.experience} onValueChange={(value) => updateFormData('experience', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select your experience level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student / Recent Graduate</SelectItem>
                      <SelectItem value="junior">1-3 years</SelectItem>
                      <SelectItem value="mid">4-7 years</SelectItem>
                      <SelectItem value="senior">8-15 years</SelectItem>
                      <SelectItem value="expert">15+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Specializations (Select all that apply)</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {[
                      'general_dentistry',
                      'cosmetic_dentistry',
                      'implant_dentistry',
                      'orthodontics',
                      'prosthodontics',
                      'digital_design',
                      'crown_bridge',
                      'removable_prosthetics',
                      'quality_control',
                      'lab_management'
                    ].map((spec) => (
                      <div key={spec} className="flex items-center space-x-2">
                        <Checkbox
                          id={spec}
                          checked={formData.specializations.includes(spec)}
                          onCheckedChange={() => toggleSpecialization(spec)}
                        />
                        <Label htmlFor={spec} className="text-sm capitalize">
                          {spec.replace('_', ' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Work Focus & Business Type */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Work Focus & Environment</h3>
                </div>
                
                <div>
                  <Label htmlFor="primaryActivity">What is your primary daily activity?</Label>
                  <Select value={formData.primaryActivity} onValueChange={(value) => updateFormData('primaryActivity', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select your primary activity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="patient_care">Direct Patient Care</SelectItem>
                      <SelectItem value="laboratory_work">Laboratory Work & Manufacturing</SelectItem>
                      <SelectItem value="digital_modeling">Digital Modeling & CAD Design</SelectItem>
                      <SelectItem value="quality_control">Quality Control & Supervision</SelectItem>
                      <SelectItem value="business_management">Business Management</SelectItem>
                      <SelectItem value="platform_management">Platform Management & Operations</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="businessType">What type of business do you work with?</Label>
                  <Select value={formData.businessType} onValueChange={(value) => updateFormData('businessType', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="private_practice">Private Dental Practice</SelectItem>
                      <SelectItem value="dental_laboratory">Dental Laboratory</SelectItem>
                      <SelectItem value="hospital_clinic">Hospital / Large Clinic</SelectItem>
                      <SelectItem value="design_studio">Digital Design Studio</SelectItem>
                      <SelectItem value="consulting_firm">Consulting Firm</SelectItem>
                      <SelectItem value="platform_operator">Platform Operator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="teamSize">How large is your team?</Label>
                  <Select value={formData.teamSize} onValueChange={(value) => updateFormData('teamSize', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select team size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="solo">Just me</SelectItem>
                      <SelectItem value="small_team">2-5 people</SelectItem>
                      <SelectItem value="medium_team">6-15 people</SelectItem>
                      <SelectItem value="large_team">16+ people</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="serviceOffering">What services do you primarily offer/need?</Label>
                  <Select value={formData.serviceOffering} onValueChange={(value) => updateFormData('serviceOffering', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select service type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dental_treatments">Dental Treatments & Care</SelectItem>
                      <SelectItem value="prosthetic_manufacturing">Prosthetic Manufacturing</SelectItem>
                      <SelectItem value="design_services">Digital Design Services</SelectItem>
                      <SelectItem value="supervision_services">Quality Control & Supervision</SelectItem>
                      <SelectItem value="platform_services">Platform Management Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Step 4: Location & Final Review */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Location & Review</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Select value={formData.country} onValueChange={(value) => updateFormData('country', value)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UAE">United Arab Emirates</SelectItem>
                        <SelectItem value="Saudi Arabia">Saudi Arabia</SelectItem>
                        <SelectItem value="Kuwait">Kuwait</SelectItem>
                        <SelectItem value="Qatar">Qatar</SelectItem>
                        <SelectItem value="Bahrain">Bahrain</SelectItem>
                        <SelectItem value="Oman">Oman</SelectItem>
                        <SelectItem value="Egypt">Egypt</SelectItem>
                        <SelectItem value="Jordan">Jordan</SelectItem>
                        <SelectItem value="Lebanon">Lebanon</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => updateFormData('city', e.target.value)}
                      placeholder="Enter your city"
                      className="mt-1"
                    />
                  </div>
                </div>

                {/* Role Prediction Summary */}
                {predictedRole && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      <h4 className="font-semibold text-blue-900">Account Type Detected</h4>
                    </div>
                    <p className="text-blue-800 text-sm mb-3">
                      Based on your answers, we've identified you as a <strong>{predictedRole}</strong>. 
                      Your account will be configured with the appropriate features and permissions.
                    </p>
                    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm border ${getRoleColor(predictedRole)}`}>
                      {React.createElement(getRoleIcon(predictedRole), { className: 'w-4 h-4' })}
                      {predictedRole}
                    </div>
                  </div>
                )}

                {/* Summary */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold mb-3">Account Summary</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Name:</span> {formData.firstName} {formData.lastName}</p>
                    <p><span className="font-medium">Email:</span> {formData.email}</p>
                    <p><span className="font-medium">Profession:</span> {formData.profession.replace('_', ' ')}</p>
                    <p><span className="font-medium">Organization:</span> {formData.organization || 'Not specified'}</p>
                    <p><span className="font-medium">Location:</span> {formData.city}, {formData.country}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
              
              {currentStep < totalSteps ? (
                <Button onClick={handleNext}>
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  onClick={handleSubmit} 
                  disabled={isLoading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating Account...
                    </>
                  ) : (
                    <>
                      Create Account
                      <CheckCircle className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}