import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Progress } from './ui/progress';
import { 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Eye, 
  Users, 
  TrendingUp,
  QrCode,
  FileText,
  Star,
  History
} from 'lucide-react';
import { User, Case } from '../types';
import { mockCases, mockUsers } from '../data/mockData';

interface SupervisorDashboardProps {
  currentUser: User;
  onViewCase: (caseId: string) => void;
  onCaseHistory?: () => void;
}

export function SupervisorDashboard({ currentUser, onViewCase, onCaseHistory }: SupervisorDashboardProps) {
  const { t } = useLanguage();
  const [selectedTab, setSelectedTab] = useState('overview');

  // Filter cases that this supervisor is responsible for
  const supervisorCases = mockCases.filter(c => c.supervisor?.id === currentUser.id) || [];
  const activeCases = supervisorCases.filter(c => !['completed', 'delivered'].includes(c.status));
  const completedCases = supervisorCases.filter(c => ['completed', 'delivered'].includes(c.status));
  const qualityCheckCases = supervisorCases.filter(c => c.status === 'quality_check');
  const urgentCases = supervisorCases.filter(c => c.priority === 'urgent');

  // Team performance metrics
  const teamDesigners = mockUsers.filter(u => u.role === 'designer');
  const teamLabs = mockUsers.filter(u => u.role === 'lab');

  const getStatusColor = (status: Case['status']) => {
    const colors = {
      draft: 'bg-gray-500',
      submitted: 'bg-blue-500',
      assigned: 'bg-purple-500',
      in_progress: 'bg-yellow-500',
      quality_check: 'bg-orange-500',
      completed: 'bg-green-500',
      delivered: 'bg-emerald-500'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Case['priority']) => {
    const colors = {
      low: 'text-green-600',
      medium: 'text-yellow-600',
      high: 'text-orange-600',
      urgent: 'text-red-600'
    };
    return colors[priority];
  };

  const getProgressPercentage = (caseItem: Case) => {
    if (!caseItem.progress || caseItem.progress.length === 0) return 0;
    const completed = caseItem.progress.filter(step => step.status === 'completed').length;
    return (completed / caseItem.progress.length) * 100;
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('total_supervised')}</p>
              <p className="text-2xl font-bold">{supervisorCases.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('quality_check')}</p>
              <p className="text-2xl font-bold">{qualityCheckCases.length}</p>
            </div>
            <QrCode className="w-8 h-8 text-orange-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('completed_cases')}</p>
              <p className="text-2xl font-bold">{completedCases.length}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </Card>
        
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">{t('urgent_cases')}</p>
              <p className="text-2xl font-bold">{urgentCases.length}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
        </Card>
      </div>

      {/* Quality Check Queue */}
      <Card className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-semibold text-lg flex items-center gap-2">
            <QrCode className="w-5 h-5 text-orange-600" />
            {t('quality_control_queue')}
          </h3>
          {onCaseHistory && (
            <Button variant="outline" onClick={onCaseHistory}>
              <History className="w-4 h-4 mr-2" />
              {t('view_history')}
            </Button>
          )}
        </div>
        <div className="space-y-4">
          {qualityCheckCases.length > 0 ? (
            qualityCheckCases.map((caseItem) => (
              <div
                key={caseItem.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center gap-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={caseItem.dentist.avatar} />
                    <AvatarFallback>
                      {caseItem.dentist.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{caseItem.title}</h4>
                    <p className="text-sm text-gray-600">
                      {t('patient')}: {caseItem.patient.name} • {t('by')} {caseItem.dentist.name}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={`${getStatusColor(caseItem.status)} text-white`}>
                    {t(caseItem.status.replace('_', ' '))}
                  </Badge>
                  <span className={`text-sm font-medium capitalize ${getPriorityColor(caseItem.priority)}`}>
                    {t(caseItem.priority)}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onViewCase(caseItem.id)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    {t('review')}
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <h4 className="font-semibold mb-2">{t('no_cases_for_review')}</h4>
              <p className="text-gray-600">{t('all_cases_reviewed')}</p>
            </div>
          )}
        </div>
      </Card>

      {/* Team Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            {t('team_designers')}
          </h3>
          <div className="space-y-3">
            {teamDesigners.slice(0, 3).map(designer => {
              const designerCases = supervisorCases.filter(c => c.designer?.id === designer.id);
              return (
                <div key={designer.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={designer.avatar} />
                      <AvatarFallback>
                        {designer.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{designer.name}</p>
                      <p className="text-xs text-gray-600">{designer.labName}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{designerCases.length} {t('cases')}</p>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-yellow-500" />
                      <span className="text-xs text-gray-600">4.8</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            {t('performance_metrics')}
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>{t('completion_rate')}</span>
                <span>87%</span>
              </div>
              <Progress value={87} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>{t('quality_score')}</span>
                <span>94%</span>
              </div>
              <Progress value={94} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>{t('on_time_delivery')}</span>
                <span>91%</span>
              </div>
              <Progress value={91} className="h-2" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  const renderCases = () => (
    <div className="space-y-4">
      {activeCases.length > 0 ? (
        activeCases.map((caseItem) => (
          <Card key={caseItem.id} className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold text-lg">{caseItem.title}</h3>
                <p className="text-gray-600">{t('patient')}: {caseItem.patient.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`${getStatusColor(caseItem.status)} text-white`}>
                  {t(caseItem.status.replace('_', ' '))}
                </Badge>
                <Badge variant="outline" className="capitalize">
                  {t(caseItem.priority)}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="flex items-center gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={caseItem.dentist.avatar} />
                  <AvatarFallback>
                    {caseItem.dentist.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-sm">{caseItem.dentist.name}</p>
                  <p className="text-xs text-gray-600">{caseItem.dentist.practice}</p>
                </div>
              </div>
              
              {caseItem.designer && (
                <div className="flex items-center gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={caseItem.designer.avatar} />
                    <AvatarFallback>
                      {caseItem.designer.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">{caseItem.designer.name}</p>
                    <p className="text-xs text-gray-600">{t('designer')}</p>
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">
                  {t('due')}: {caseItem.dueDate.toLocaleDateString()}
                </span>
              </div>
            </div>

            {caseItem.progress && caseItem.progress.length > 0 && (
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{t('progress')}</span>
                  <span>{Math.round(getProgressPercentage(caseItem))}%</span>
                </div>
                <Progress value={getProgressPercentage(caseItem)} className="h-2" />
              </div>
            )}

            <div className="flex justify-end">
              <Button variant="outline" onClick={() => onViewCase(caseItem.id)}>
                <Eye className="w-4 h-4 mr-2" />
                {t('review_case')}
              </Button>
            </div>
          </Card>
        ))
      ) : (
        <Card className="p-8 text-center">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">{t('no_active_cases')}</h3>
          <p className="text-gray-600">{t('all_cases_completed')}</p>
        </Card>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{t('quality_supervisor_dashboard')}</h1>
        <p className="text-gray-600 mt-1">{t('monitor_quality_and_team_performance')}</p>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="overview">{t('overview')}</TabsTrigger>
          <TabsTrigger value="cases">{t('active_cases')} ({activeCases.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          {renderOverview()}
        </TabsContent>

        <TabsContent value="cases" className="mt-6">
          {renderCases()}
        </TabsContent>
      </Tabs>
    </div>
  );
}