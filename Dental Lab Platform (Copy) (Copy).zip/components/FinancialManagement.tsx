import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Textarea } from './ui/textarea';
import { DatePicker } from './ui/date-picker';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { toast } from 'sonner@2.0.3';
import { 
  ArrowLeft,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Users,
  CreditCard,
  PieChart,
  BarChart3,
  Download,
  Edit,
  Plus,
  Eye,
  Calendar,
  Calculator,
  Target,
  Zap,
  Award,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';
import { User, ServicePrice, PricingOverride, FinancialReport, PlatformFinancials } from '../types';

interface FinancialManagementProps {
  currentUser: User;
  onBack: () => void;
}

export function FinancialManagement({ currentUser, onBack }: FinancialManagementProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedService, setSelectedService] = useState<ServicePrice | null>(null);
  const [showPricingDialog, setShowPricingDialog] = useState(false);
  const [showOverrideDialog, setShowOverrideDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Mock financial data
  const platformFinancials: PlatformFinancials = {
    totalRevenue: 284750,
    monthlyRevenue: 45670,
    totalCommissions: 42712,
    monthlyCommissions: 6850,
    totalCases: 1247,
    activeCases: 89,
    completedCases: 1158,
    averageCaseValue: 228.5,
    topEarningUsers: [
      { userId: '1', userName: 'Advanced Dental Lab', role: 'lab', earnings: 12450 },
      { userId: '2', userName: 'Dr. Ahmed Salem', role: 'dentist', earnings: 8920 },
      { userId: '3', userName: 'Sarah Al-Mansouri', role: 'designer', earnings: 6780 },
      { userId: '4', userName: 'Elite Prosthetics Lab', role: 'lab', earnings: 5640 },
      { userId: '5', userName: 'Dr. Khalid Al-Zahra', role: 'supervisor', earnings: 4320 }
    ],
    revenueByService: [
      { serviceType: 'Crown & Bridge', revenue: 98450, count: 445 },
      { serviceType: 'Implants', revenue: 76320, count: 234 },
      { serviceType: 'Dentures', revenue: 54890, count: 298 },
      { serviceType: 'Orthodontics', revenue: 34560, count: 156 },
      { serviceType: 'Cosmetic', revenue: 20530, count: 114 }
    ],
    monthlyTrends: [
      { month: 'Jan', revenue: 32400, cases: 145, newUsers: 23 },
      { month: 'Feb', revenue: 38200, cases: 167, newUsers: 31 },
      { month: 'Mar', revenue: 41800, cases: 189, newUsers: 28 },
      { month: 'Apr', revenue: 45670, cases: 203, newUsers: 35 }
    ]
  };

  // Mock service pricing data
  const [servicePrices, setServicePrices] = useState<ServicePrice[]>([
    {
      id: '1',
      serviceType: 'Single Crown',
      category: 'crown',
      material: 'Porcelain',
      basePrice: 350,
      labPrice: 180,
      designerPrice: 85,
      supervisorPrice: 45,
      platformCommission: 15,
      isActive: true,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-02-10')
    },
    {
      id: '2',
      serviceType: '3-Unit Bridge',
      category: 'bridge',
      material: 'Zirconia',
      basePrice: 890,
      labPrice: 420,
      designerPrice: 150,
      supervisorPrice: 80,
      platformCommission: 12,
      isActive: true,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-02-10')
    },
    {
      id: '3',
      serviceType: 'Implant Crown',
      category: 'implant',
      material: 'Titanium/Porcelain',
      basePrice: 1200,
      labPrice: 550,
      designerPrice: 200,
      supervisorPrice: 120,
      platformCommission: 10,
      isActive: true,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-02-10')
    },
    {
      id: '4',
      serviceType: 'Full Denture',
      category: 'denture',
      material: 'Acrylic',
      basePrice: 780,
      labPrice: 380,
      designerPrice: 120,
      supervisorPrice: 60,
      platformCommission: 18,
      isActive: true,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-02-10')
    }
  ]);

  // Mock pricing overrides
  const [pricingOverrides, setPricingOverrides] = useState<PricingOverride[]>([
    {
      id: '1',
      userId: 'lab-1',
      serviceType: 'Single Crown',
      customPrice: 320,
      discountPercentage: 8.6,
      effectiveFrom: new Date('2024-02-01'),
      reason: 'High volume discount for preferred partner',
      createdBy: currentUser.id,
      createdAt: new Date('2024-01-28')
    }
  ]);

  // Mock users for pricing overrides
  const mockUsers = [
    { id: 'lab-1', name: 'Advanced Dental Lab', role: 'lab', practice: 'Advanced Dental Laboratory' },
    { id: 'lab-2', name: 'Elite Prosthetics Lab', role: 'lab', practice: 'Elite Prosthetics Laboratory' },
    { id: 'dentist-1', name: 'Dr. Ahmed Salem', role: 'dentist', practice: 'Salem Dental Clinic' },
    { id: 'designer-1', name: 'Sarah Al-Mansouri', role: 'designer', practice: 'Al-Mansouri Design Studio' }
  ];

  const handleUpdatePricing = (serviceId: string, updates: Partial<ServicePrice>) => {
    setServicePrices(prev => prev.map(service => 
      service.id === serviceId 
        ? { ...service, ...updates, updatedAt: new Date() }
        : service
    ));
    toast.success('Pricing updated successfully');
    setShowPricingDialog(false);
  };

  const handleCreateOverride = (override: Omit<PricingOverride, 'id' | 'createdAt'>) => {
    const newOverride: PricingOverride = {
      ...override,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    setPricingOverrides(prev => [newOverride, ...prev]);
    toast.success('Custom pricing override created');
    setShowOverrideDialog(false);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      crown: 'bg-blue-100 text-blue-800',
      bridge: 'bg-green-100 text-green-800',
      implant: 'bg-purple-100 text-purple-800',
      denture: 'bg-orange-100 text-orange-800',
      orthodontic: 'bg-pink-100 text-pink-800',
      cosmetic: 'bg-indigo-100 text-indigo-800',
      surgical: 'bg-red-100 text-red-800',
      other: 'bg-gray-100 text-gray-800'
    };
    return colors[category as keyof typeof colors] || colors.other;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const PricingDialog = () => (
    <Dialog open={showPricingDialog} onOpenChange={setShowPricingDialog}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit Service Pricing</DialogTitle>
          <DialogDescription>
            Update pricing for {selectedService?.serviceType}
          </DialogDescription>
        </DialogHeader>
        
        {selectedService && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Service Type</Label>
                <Input value={selectedService.serviceType} disabled />
              </div>
              <div>
                <Label>Material</Label>
                <Input value={selectedService.material} disabled />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Base Price</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="number"
                    className="pl-10"
                    defaultValue={selectedService.basePrice}
                  />
                </div>
              </div>
              <div>
                <Label>Platform Commission (%)</Label>
                <Input
                  type="number"
                  defaultValue={selectedService.platformCommission}
                />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Role-Based Pricing</h4>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Lab Fee</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="number"
                      className="pl-10"
                      defaultValue={selectedService.labPrice}
                    />
                  </div>
                </div>
                <div>
                  <Label>Designer Fee</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="number"
                      className="pl-10"
                      defaultValue={selectedService.designerPrice}
                    />
                  </div>
                </div>
                <div>
                  <Label>Supervisor Fee</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="number"
                      className="pl-10"
                      defaultValue={selectedService.supervisorPrice}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Pricing Breakdown</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Base Price:</span>
                  <span className="font-medium">{formatCurrency(selectedService.basePrice)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Role Fees:</span>
                  <span className="font-medium">
                    {formatCurrency(selectedService.labPrice + selectedService.designerPrice + selectedService.supervisorPrice)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Platform Commission ({selectedService.platformCommission}%):</span>
                  <span className="font-medium">
                    {formatCurrency(selectedService.basePrice * selectedService.platformCommission / 100)}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-medium">
                  <span>Net to Platform:</span>
                  <span className="text-green-600">
                    {formatCurrency(selectedService.basePrice * selectedService.platformCommission / 100)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => setShowPricingDialog(false)}>
            Cancel
          </Button>
          <Button onClick={() => selectedService && handleUpdatePricing(selectedService.id, selectedService)}>
            <Calculator className="w-4 h-4 mr-2" />
            Update Pricing
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  const PricingOverrideDialog = () => (
    <Dialog open={showOverrideDialog} onOpenChange={setShowOverrideDialog}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Create Custom Pricing</DialogTitle>
          <DialogDescription>
            Set custom pricing for a specific user or account
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Select User</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose user" />
                </SelectTrigger>
                <SelectContent>
                  {mockUsers.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name} ({user.role})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Service Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose service" />
                </SelectTrigger>
                <SelectContent>
                  {servicePrices.map((service) => (
                    <SelectItem key={service.id} value={service.serviceType}>
                      {service.serviceType}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Custom Price</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input type="number" className="pl-10" placeholder="0.00" />
              </div>
            </div>
            <div>
              <Label>Discount Percentage</Label>
              <Input type="number" placeholder="0" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Effective From</Label>
              <Input type="date" />
            </div>
            <div>
              <Label>Effective To (Optional)</Label>
              <Input type="date" />
            </div>
          </div>

          <div>
            <Label>Reason</Label>
            <Textarea placeholder="Explain the reason for custom pricing..." />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setShowOverrideDialog(false)}>
            Cancel
          </Button>
          <Button onClick={() => setShowOverrideDialog(false)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Override
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Financial Management</h1>
            <p className="text-gray-600 mt-1">Advanced pricing and revenue management</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button onClick={() => setShowOverrideDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Custom Pricing
          </Button>
        </div>
      </div>

      {/* Key Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-3xl font-bold">{formatCurrency(platformFinancials.totalRevenue)}</p>
              <p className="text-sm text-green-600 mt-1">+12.5% this month</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Monthly Revenue</p>
              <p className="text-3xl font-bold">{formatCurrency(platformFinancials.monthlyRevenue)}</p>
              <p className="text-sm text-blue-600 mt-1">{platformFinancials.activeCases} active cases</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Platform Commission</p>
              <p className="text-3xl font-bold">{formatCurrency(platformFinancials.monthlyCommissions)}</p>
              <p className="text-sm text-purple-600 mt-1">15% average rate</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6 border-l-4 border-orange-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Case Value</p>
              <p className="text-3xl font-bold">{formatCurrency(platformFinancials.averageCaseValue)}</p>
              <p className="text-sm text-orange-600 mt-1">+8.3% vs last month</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Calculator className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="pricing">Service Pricing</TabsTrigger>
          <TabsTrigger value="overrides">Custom Pricing</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue by Service */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Revenue by Service Type
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {platformFinancials.revenueByService.map((service, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded-full bg-chart-${index + 1}`}></div>
                        <div>
                          <p className="font-medium">{service.serviceType}</p>
                          <p className="text-sm text-gray-600">{service.count} cases</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(service.revenue)}</p>
                        <p className="text-sm text-gray-500">
                          {((service.revenue / platformFinancials.totalRevenue) * 100).toFixed(1)}%
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top Earning Users */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Top Earning Users
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {platformFinancials.topEarningUsers.map((user, index) => (
                    <div key={user.userId} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">#{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-medium">{user.userName}</p>
                          <Badge className={getCategoryColor(user.role)}>
                            {user.role}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(user.earnings)}</p>
                        <p className="text-sm text-gray-500">this month</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Monthly Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Monthly Performance Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                {platformFinancials.monthlyTrends.map((month) => (
                  <Card key={month.month} className="p-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">{month.month} 2024</p>
                      <p className="text-xl font-bold">{formatCurrency(month.revenue)}</p>
                      <p className="text-sm text-gray-500">{month.cases} cases</p>
                      <p className="text-xs text-green-600">+{month.newUsers} new users</p>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Service Pricing Tab */}
        <TabsContent value="pricing" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Service Pricing Management
              </CardTitle>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add New Service
              </Button>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Service Type</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Material</TableHead>
                      <TableHead>Base Price</TableHead>
                      <TableHead>Lab Fee</TableHead>
                      <TableHead>Designer Fee</TableHead>
                      <TableHead>Supervisor Fee</TableHead>
                      <TableHead>Commission %</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {servicePrices.map((service) => (
                      <TableRow key={service.id}>
                        <TableCell className="font-medium">{service.serviceType}</TableCell>
                        <TableCell>
                          <Badge className={getCategoryColor(service.category)}>
                            {service.category}
                          </Badge>
                        </TableCell>
                        <TableCell>{service.material}</TableCell>
                        <TableCell>{formatCurrency(service.basePrice)}</TableCell>
                        <TableCell>{formatCurrency(service.labPrice)}</TableCell>
                        <TableCell>{formatCurrency(service.designerPrice)}</TableCell>
                        <TableCell>{formatCurrency(service.supervisorPrice)}</TableCell>
                        <TableCell>{service.platformCommission}%</TableCell>
                        <TableCell>
                          <Badge variant={service.isActive ? "default" : "secondary"}>
                            {service.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                setSelectedService(service);
                                setShowPricingDialog(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Custom Pricing Tab */}
        <TabsContent value="overrides" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Custom Pricing Overrides
              </CardTitle>
              <Button onClick={() => setShowOverrideDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Override
              </Button>
            </CardHeader>
            <CardContent>
              {pricingOverrides.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Service Type</TableHead>
                        <TableHead>Custom Price</TableHead>
                        <TableHead>Discount %</TableHead>
                        <TableHead>Effective Period</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pricingOverrides.map((override) => (
                        <TableRow key={override.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">User #{override.userId}</p>
                              <p className="text-sm text-gray-500">Lab Account</p>
                            </div>
                          </TableCell>
                          <TableCell>{override.serviceType}</TableCell>
                          <TableCell className="font-medium">
                            {formatCurrency(override.customPrice)}
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">
                              -{override.discountPercentage?.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <p>From: {override.effectiveFrom.toLocaleDateString()}</p>
                              {override.effectiveTo && (
                                <p>To: {override.effectiveTo.toLocaleDateString()}</p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <p className="text-sm text-gray-600 max-w-xs truncate">
                              {override.reason}
                            </p>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Active
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">No Custom Pricing Overrides</h3>
                  <p className="text-gray-600 mb-4">
                    Create custom pricing for specific users or accounts to offer special rates.
                  </p>
                  <Button onClick={() => setShowOverrideDialog(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create First Override
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Conversion Rate</span>
                    <div className="flex items-center gap-2">
                      <Progress value={76.5} className="w-20 h-2" />
                      <span className="font-semibold">76.5%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Order Value</span>
                    <span className="font-semibold">{formatCurrency(342.80)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Profit Margin</span>
                    <div className="flex items-center gap-2">
                      <Progress value={28.5} className="w-20 h-2" />
                      <span className="font-semibold">28.5%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">On-time Payments</span>
                    <div className="flex items-center gap-2">
                      <Progress value={92.3} className="w-20 h-2" />
                      <span className="font-semibold">92.3%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Payment Time</span>
                    <span className="font-semibold">4.2 days</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Outstanding Amount</span>
                    <span className="font-semibold text-orange-600">{formatCurrency(12450)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Financial Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Revenue Report</h3>
                      <p className="text-sm text-gray-600">Detailed revenue breakdown</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">User Earnings</h3>
                      <p className="text-sm text-gray-600">Individual user performance</p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <PieChart className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Service Analysis</h3>
                      <p className="text-sm text-gray-600">Service type performance</p>
                    </div>
                  </div>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <PricingDialog />
      <PricingOverrideDialog />
    </div>
  );
}