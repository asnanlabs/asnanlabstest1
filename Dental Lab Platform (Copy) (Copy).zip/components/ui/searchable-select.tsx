import React, { useState, useMemo } from 'react';
import { Check, ChevronsUpDown, Search } from 'lucide-react';
import { cn } from './utils';
import { Button } from './button';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './command';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

export interface SearchableSelectOption {
  value: string;
  label: string;
  category?: string;
}

interface SearchableSelectProps {
  options: SearchableSelectOption[];
  value?: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  className?: string;
  allowCustom?: boolean;
  onCustomValue?: (value: string) => void;
}

export function SearchableSelect({
  options,
  value,
  onValueChange,
  placeholder = "Select option...",
  searchPlaceholder = "Search options...",
  emptyMessage = "No options found.",
  disabled = false,
  className,
  allowCustom = false,
  onCustomValue
}: SearchableSelectProps) {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  const selectedOption = options.find(option => option.value === value);

  // Group options by category if they have categories
  const groupedOptions = useMemo(() => {
    const grouped: Record<string, SearchableSelectOption[]> = {};
    
    options.forEach(option => {
      const category = option.category || 'main';
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push(option);
    });

    return grouped;
  }, [options]);

  const hasCategories = Object.keys(groupedOptions).length > 1 || (Object.keys(groupedOptions).length === 1 && !groupedOptions.main);

  const handleSelect = (selectedValue: string) => {
    if (selectedValue === value) {
      onValueChange("");
    } else {
      onValueChange(selectedValue);
    }
    setOpen(false);
    setSearchValue("");
  };

  const handleCustomAdd = () => {
    if (allowCustom && onCustomValue && searchValue.trim()) {
      onCustomValue(searchValue.trim());
      setOpen(false);
      setSearchValue("");
    }
  };

  const filteredOptions = useMemo(() => {
    if (!searchValue) return options;
    
    return options.filter(option =>
      option.label.toLowerCase().includes(searchValue.toLowerCase()) ||
      option.value.toLowerCase().includes(searchValue.toLowerCase())
    );
  }, [options, searchValue]);

  const showCustomOption = allowCustom && searchValue.trim() && 
    !options.some(option => option.label.toLowerCase() === searchValue.toLowerCase());

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn("w-full justify-between", className)}
          disabled={disabled}
        >
          {selectedOption ? selectedOption.label : placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] max-w-[400px] p-0" align="start">
        <Command>
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <CommandInput
              placeholder={searchPlaceholder}
              value={searchValue}
              onValueChange={setSearchValue}
              className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>
          <CommandList className="max-h-[300px] overflow-y-auto">
            <CommandEmpty>
              <div className="text-center py-4">
                <p className="text-sm text-muted-foreground">{emptyMessage}</p>
                {showCustomOption && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2"
                    onClick={handleCustomAdd}
                  >
                    Add "{searchValue}"
                  </Button>
                )}
              </div>
            </CommandEmpty>
            
            {hasCategories ? (
              Object.entries(groupedOptions).map(([category, categoryOptions]) => {
                const filteredCategoryOptions = categoryOptions.filter(option =>
                  filteredOptions.includes(option)
                );
                
                if (filteredCategoryOptions.length === 0) return null;
                
                return (
                  <CommandGroup key={category} heading={category !== 'main' ? category : undefined}>
                    {filteredCategoryOptions.map((option) => (
                      <CommandItem
                        key={option.value}
                        value={option.value}
                        onSelect={() => handleSelect(option.value)}
                        className="cursor-pointer"
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            value === option.value ? "opacity-100" : "opacity-0"
                          )}
                        />
                        {option.label}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                );
              })
            ) : (
              <CommandGroup>
                {filteredOptions.map((option) => (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    onSelect={() => handleSelect(option.value)}
                    className="cursor-pointer"
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        value === option.value ? "opacity-100" : "opacity-0"
                      )}
                    />
                    {option.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            
            {showCustomOption && filteredOptions.length > 0 && (
              <CommandGroup>
                <CommandItem onSelect={handleCustomAdd} className="cursor-pointer border-t">
                  <Search className="mr-2 h-4 w-4" />
                  Add "{searchValue}"
                </CommandItem>
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}