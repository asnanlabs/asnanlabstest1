import React from 'react';
import { ScrollArea } from './scroll-area';
import { cn } from '../../lib/utils';

interface ScrollableListProps {
  children: React.ReactNode;
  height?: string;
  className?: string;
  showScrollbar?: boolean;
}

export function ScrollableList({ 
  children, 
  height = "h-[calc(100vh-300px)]", 
  className,
  showScrollbar = true 
}: ScrollableListProps) {
  return (
    <ScrollArea className={cn(height, className)}>
      <div className={cn("pr-4", !showScrollbar && "pr-0")}>
        {children}
      </div>
    </ScrollArea>
  );
}

interface ScrollableCardListProps {
  children: React.ReactNode;
  height?: string;
  className?: string;
  emptyState?: React.ReactNode;
  items?: any[];
}

export function ScrollableCardList({ 
  children, 
  height = "h-[calc(100vh-300px)]", 
  className,
  emptyState,
  items = [] 
}: ScrollableCardListProps) {
  if (items.length === 0 && emptyState) {
    return <div className="flex items-center justify-center py-8">{emptyState}</div>;
  }

  return (
    <ScrollArea className={cn(height, className)}>
      <div className="space-y-4 pr-4">
        {children}
      </div>
    </ScrollArea>
  );
}

interface ScrollableTableProps {
  children: React.ReactNode;
  height?: string;
  className?: string;
}

export function ScrollableTable({ 
  children, 
  height = "h-[400px]", 
  className 
}: ScrollableTableProps) {
  return (
    <ScrollArea className={cn(height, className)}>
      <div className="pr-4">
        {children}
      </div>
    </ScrollArea>
  );
}

export default ScrollableList;