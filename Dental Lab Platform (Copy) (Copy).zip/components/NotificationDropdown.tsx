import React, { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { 
  Bell, 
  MessageSquare, 
  CheckCircle, 
  Clock, 
  FileText, 
  UserPlus, 
  AlertCircle,
  X,
  MarkAsRead
} from 'lucide-react';
import { Notification, User } from '../types';
import { useNotifications } from '../hooks/useNotifications';

interface NotificationDropdownProps {
  currentUser: User;
  onViewCase: (caseId: string) => void;
}

export function NotificationDropdown({ currentUser, onViewCase }: NotificationDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { notifications, unreadCount, markAsRead, markAllAsRead, deleteNotification } = useNotifications(currentUser.id);

  const getNotificationIcon = (type: Notification['type']) => {
    const icons = {
      message: MessageSquare,
      status_change: CheckCircle,
      progress_update: Clock,
      comment: MessageSquare,
      file_upload: FileText,
      case_assignment: UserPlus,
      case_completion: CheckCircle,
      case_rejection: AlertCircle
    };
    const Icon = icons[type];
    return <Icon className="w-4 h-4" />;
  };

  const getNotificationColor = (type: Notification['type']) => {
    const colors = {
      message: 'text-blue-600',
      status_change: 'text-green-600',
      progress_update: 'text-yellow-600',
      comment: 'text-purple-600',
      file_upload: 'text-orange-600',
      case_assignment: 'text-indigo-600',
      case_completion: 'text-emerald-600',
      case_rejection: 'text-red-600'
    };
    return colors[type];
  };

  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification.id);
    onViewCase(notification.caseId);
    setIsOpen(false);
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const categorizeNotifications = () => {
    const unread = notifications.filter(n => !n.isRead);
    const messages = notifications.filter(n => n.type === 'message');
    const updates = notifications.filter(n => 
      ['status_change', 'progress_update', 'case_assignment', 'case_completion'].includes(n.type)
    );
    const activity = notifications.filter(n => 
      ['comment', 'file_upload', 'case_rejection'].includes(n.type)
    );

    return { unread, messages, updates, activity };
  };

  const { unread, messages, updates, activity } = categorizeNotifications();

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center text-xs p-0 bg-red-500">
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-96 p-0">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Notifications</h3>
            {unreadCount > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={markAllAsRead}
                className="gap-1 h-8 px-2"
              >
                <CheckCircle className="w-3 h-3" />
                Mark all read
              </Button>
            )}
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mx-4 mt-2">
            <TabsTrigger value="all" className="text-xs">
              All ({notifications.length})
            </TabsTrigger>
            <TabsTrigger value="unread" className="text-xs">
              Unread ({unread.length})
            </TabsTrigger>
            <TabsTrigger value="messages" className="text-xs">
              Messages ({messages.length})
            </TabsTrigger>
            <TabsTrigger value="updates" className="text-xs">
              Updates ({updates.length})
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="h-96">
            <TabsContent value="all" className="m-0">
              <NotificationList 
                notifications={notifications}
                onNotificationClick={handleNotificationClick}
                onDelete={deleteNotification}
                getNotificationIcon={getNotificationIcon}
                getNotificationColor={getNotificationColor}
                getTimeAgo={getTimeAgo}
              />
            </TabsContent>

            <TabsContent value="unread" className="m-0">
              <NotificationList 
                notifications={unread}
                onNotificationClick={handleNotificationClick}
                onDelete={deleteNotification}
                getNotificationIcon={getNotificationIcon}
                getNotificationColor={getNotificationColor}
                getTimeAgo={getTimeAgo}
              />
            </TabsContent>

            <TabsContent value="messages" className="m-0">
              <NotificationList 
                notifications={messages}
                onNotificationClick={handleNotificationClick}
                onDelete={deleteNotification}
                getNotificationIcon={getNotificationIcon}
                getNotificationColor={getNotificationColor}
                getTimeAgo={getTimeAgo}
              />
            </TabsContent>

            <TabsContent value="updates" className="m-0">
              <NotificationList 
                notifications={[...updates, ...activity]}
                onNotificationClick={handleNotificationClick}
                onDelete={deleteNotification}
                getNotificationIcon={getNotificationIcon}
                getNotificationColor={getNotificationColor}
                getTimeAgo={getTimeAgo}
              />
            </TabsContent>
          </ScrollArea>
        </Tabs>

        {notifications.length === 0 && (
          <div className="p-8 text-center">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="font-medium text-gray-900 mb-1">No notifications</h3>
            <p className="text-sm text-gray-500">You're all caught up!</p>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface NotificationListProps {
  notifications: Notification[];
  onNotificationClick: (notification: Notification) => void;
  onDelete: (id: string) => void;
  getNotificationIcon: (type: Notification['type']) => React.ReactNode;
  getNotificationColor: (type: Notification['type']) => string;
  getTimeAgo: (date: Date) => string;
}

function NotificationList({ 
  notifications, 
  onNotificationClick, 
  onDelete,
  getNotificationIcon,
  getNotificationColor,
  getTimeAgo
}: NotificationListProps) {
  if (notifications.length === 0) {
    return (
      <div className="p-8 text-center">
        <div className="text-gray-400 mb-2">No notifications in this category</div>
      </div>
    );
  }

  return (
    <div className="divide-y">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`p-4 hover:bg-gray-50 cursor-pointer group relative ${
            !notification.isRead ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
          }`}
          onClick={() => onNotificationClick(notification)}
        >
          <div className="flex gap-3">
            <div className={`flex-shrink-0 mt-1 ${getNotificationColor(notification.type)}`}>
              {getNotificationIcon(notification.type)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">
                    {notification.title}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    {notification.message}
                  </p>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center gap-1">
                      <Avatar className="w-4 h-4">
                        <AvatarImage src={notification.from.avatar} />
                        <AvatarFallback className="text-xs">
                          {notification.from.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-gray-500">
                        {notification.from.name}
                      </span>
                    </div>
                    <span className="text-xs text-gray-400">•</span>
                    <span className="text-xs text-gray-500">
                      {notification.caseTitle}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xs text-gray-400">
                    {getTimeAgo(notification.createdAt)}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 w-6 h-6 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(notification.id);
                    }}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              {!notification.isRead && (
                <div className="absolute top-4 right-4">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}