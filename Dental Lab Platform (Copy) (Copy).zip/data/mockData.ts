import { User, Case, Patient, ProgressStep, CaseNote, CaseFile, Notification, ChecklistItem, FinancialInfo, WorkHistoryEntry } from '../types';

export const mockUsers: User[] = [
  // Dentists
  {
    id: '1',
    name: 'Dr. Sarah Aldulaimy',
    email: 'sarah.dulaimy@asnan.com',
    role: 'dentist',
    practice: 'Asnan Dental Care',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face',
    caseHistory: ['1', '2', '4', '7', '8']
  },
  {
    id: '2',
    name: 'Dr. Mohammed Taqqi',
    email: 'mo.taqqi88@smiledental.com',
    role: 'dentist',
    practice: 'Smile Dental Group',
    avatar: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
    caseHistory: ['3', '5', '6']
  },
  {
    id: '9',
    name: 'Dr. Ahmed Hassan',
    email: 'ahmed.hassan@dentalclinic.com',
    role: 'dentist',
    practice: 'Modern Dental Clinic',
    avatar: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face',
    caseHistory: ['9', '10']
  },
  // Labs
  {
    id: '3',
    name: 'TechLab Solutions',
    email: 'contact@asnansolution.com',
    role: 'lab',
    labName: 'Asnan Solutions',
    avatar: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=150&h=150&fit=crop',
    caseHistory: ['1', '4', '7', '9']
  },
  {
    id: '4',
    name: 'Precision Dental Lab',
    email: 'orders@precisiondentallab.com',
    role: 'lab',
    labName: 'Precision Dental Lab',
    avatar: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop',
    caseHistory: ['2', '5', '8', '10']
  },
  // Supervisors
  {
    id: '5',
    name: 'Abdullah Ibrahim',
    email: 'abdullah.ibrahim@techlabsolutions.com',
    role: 'supervisor',
    labName: 'TechLab Solutions - Quality Supervisor',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    permissions: ['quality_control', 'team_management', 'case_review'],
    caseHistory: ['1', '3', '4', '7']
  },
  {
    id: '11',
    name: 'Fatima Al-Zahra',
    email: 'fatima.alzahra@precisionlab.com',
    role: 'supervisor',
    labName: 'Precision Lab - Senior Supervisor',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
    permissions: ['quality_control', 'team_management', 'case_review'],
    caseHistory: ['2', '5', '8', '10']
  },
  // Designers
  {
    id: '6',
    name: 'Maya Patel',
    email: 'maya.patel@techlabsolutions.com',
    role: 'designer',
    labName: 'TechLab Solutions - CAD Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
    permissions: ['cad_design', 'modeling', 'design_review'],
    caseHistory: ['1', '3', '4', '6', '7']
  },
  {
    id: '10',
    name: 'Omar Khaled',
    email: 'omar.khaled@precisionlab.com',
    role: 'designer',
    labName: 'Precision Lab - Senior Designer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    permissions: ['cad_design', 'modeling', 'design_review'],
    caseHistory: ['2', '5', '8', '9', '10']
  },
  {
    id: '12',
    name: 'Layla Mansouri',
    email: 'layla.mansouri@innovativedesign.com',
    role: 'designer',
    labName: 'Innovative Design Studio',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    permissions: ['cad_design', 'modeling', 'design_review'],
    caseHistory: ['6']
  },
  // Platform Owner
  {
    id: '7',
    name: 'Hassan Al-Mahmoud',
    email: 'hassan.almahmoud@dentalplatform.com',
    role: 'owner',
    practice: 'Dental Platform Management',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    permissions: ['full_access', 'financial_management', 'user_management', 'system_control'],
    caseHistory: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
  }
];

export const mockPatients: Patient[] = [
  { 
    id: '1', 
    name: 'John Smith', 
    age: 45, 
    gender: 'male',
    phone: '+1-555-0123',
    medicalHistory: 'Diabetes Type 2, controlled with medication',
    allergies: ['Penicillin'],
    dentistId: '1',
    createdAt: new Date('2023-06-15T09:00:00')
  },
  { 
    id: '2', 
    name: 'Emma Davis', 
    age: 32, 
    gender: 'female',
    phone: '+1-555-0124',
    medicalHistory: 'No significant medical history',
    allergies: [],
    dentistId: '1',
    createdAt: new Date('2023-08-22T10:30:00')
  },
  { 
    id: '3', 
    name: 'Robert Wilson', 
    age: 58, 
    gender: 'male',
    phone: '+1-555-0125',
    medicalHistory: 'Hypertension, cardiac medication',
    allergies: ['Latex'],
    dentistId: '2',
    createdAt: new Date('2023-05-10T14:15:00')
  },
  { 
    id: '4', 
    name: 'Lisa Anderson', 
    age: 28, 
    gender: 'female',
    phone: '+1-555-0126',
    medicalHistory: 'Pregnancy (2nd trimester)',
    allergies: [],
    dentistId: '2',
    createdAt: new Date('2023-09-05T11:45:00')
  },
  { 
    id: '5', 
    name: 'David Brown', 
    age: 67, 
    gender: 'male',
    phone: '+1-555-0127',
    medicalHistory: 'Osteoporosis, bisphosphonate therapy',
    allergies: ['Sulfa drugs'],
    dentistId: '9',
    createdAt: new Date('2023-07-18T13:20:00')
  },
  { 
    id: '6', 
    name: 'Aisha Ahmed', 
    age: 35, 
    gender: 'female',
    phone: '+1-555-0128',
    medicalHistory: 'No significant medical history',
    allergies: [],
    dentistId: '1',
    createdAt: new Date('2023-10-12T09:30:00')
  },
  { 
    id: '7', 
    name: 'Mohammed Ali', 
    age: 42, 
    gender: 'male',
    phone: '+1-555-0129',
    medicalHistory: 'Smoking history, quit 2 years ago',
    allergies: ['Iodine'],
    dentistId: '2',
    createdAt: new Date('2023-11-08T15:00:00')
  }
];

// Checklist templates for different case types
export const anteriorCrownChecklist: ChecklistItem[] = [
  { id: '1', title: 'Shade Selection Verified', description: 'Confirm shade match with adjacent teeth', completed: false, required: true },
  { id: '2', title: 'Emergence Profile Designed', description: 'Natural emergence profile matching gingival contours', completed: false, required: true },
  { id: '3', title: 'Occlusal Contacts Checked', description: 'Proper occlusal relationship in centric and excursive movements', completed: false, required: true },
  { id: '4', title: 'Margin Integrity Verified', description: 'Subgingival margins properly finished', completed: false, required: true },
  { id: '5', title: 'Surface Texture Applied', description: 'Natural surface texture and characterization', completed: false, required: false },
  { id: '6', title: 'Final Polish Completed', description: 'High gloss finish achieved', completed: false, required: true }
];

export const posteriorCrownChecklist: ChecklistItem[] = [
  { id: '1', title: 'Occlusal Anatomy Designed', description: 'Functional cusp anatomy with proper fossa depth', completed: false, required: true },
  { id: '2', title: 'Contact Points Established', description: 'Proper proximal contacts to prevent food impaction', completed: false, required: true },
  { id: '3', title: 'Strength Analysis Completed', description: 'Adequate material thickness for occlusal forces', completed: false, required: true },
  { id: '4', title: 'Margin Adaptation Verified', description: 'Precise margin fit and finish', completed: false, required: true },
  { id: '5', title: 'Occlusal Clearance Checked', description: 'Sufficient clearance in all jaw movements', completed: false, required: true },
  { id: '6', title: 'Final Inspection', description: 'Overall quality and dimensional accuracy', completed: false, required: true }
];

export const mockProgressSteps: ProgressStep[] = [
  {
    id: '1',
    title: 'Initial Review',
    description: 'Review case details and patient information',
    status: 'completed',
    completedAt: new Date('2024-01-15T09:00:00'),
    estimatedHours: 1,
    actualHours: 0.5
  },
  {
    id: '2',
    title: 'Digital Modeling',
    description: 'Create 3D digital model from scans',
    status: 'completed',
    completedAt: new Date('2024-01-16T14:30:00'),
    estimatedHours: 4,
    actualHours: 3.5
  },
  {
    id: '3',
    title: 'Fabrication',
    description: 'Manufacturing the crown using CAD/CAM technology',
    status: 'in_progress',
    estimatedHours: 6,
    actualHours: 4
  },
  {
    id: '4',
    title: 'Quality Control',
    description: 'Final inspection and quality assurance',
    status: 'pending',
    estimatedHours: 2
  },
  {
    id: '5',
    title: 'Packaging & Shipping',
    description: 'Package and ship to dental practice',
    status: 'pending',
    estimatedHours: 1
  }
];

export const mockFiles: CaseFile[] = [
  {
    id: '1',
    name: 'Intraoral Scan - Upper Arch',
    type: 'scan',
    url: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&h=300&fit=crop',
    uploadedAt: new Date('2024-01-14T10:30:00'),
    uploadedBy: 'Dr. Sarah Johnson'
  },
  {
    id: '2',
    name: 'X-Ray - Tooth #14',
    type: 'xray',
    url: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=300&fit=crop',
    uploadedAt: new Date('2024-01-14T10:35:00'),
    uploadedBy: 'Dr. Sarah Johnson'
  },
  {
    id: '3',
    name: 'Shade Guide Reference',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&h=300&fit=crop',
    uploadedAt: new Date('2024-01-14T10:40:00'),
    uploadedBy: 'Dr. Sarah Johnson'
  }
];

export const mockNotes: CaseNote[] = [
  {
    id: '1',
    content: 'Patient prefers a natural shade, A2 vita shade selected',
    author: mockUsers[0],
    createdAt: new Date('2024-01-14T11:00:00'),
    isInternal: false
  },
  {
    id: '2',
    content: 'Margin needs to be subgingival, 0.5mm below gum line',
    author: mockUsers[0],
    createdAt: new Date('2024-01-14T11:15:00'),
    isInternal: false
  },
  {
    id: '3',
    content: 'Starting fabrication process with zirconia material',
    author: mockUsers[2],
    createdAt: new Date('2024-01-16T09:00:00'),
    isInternal: true
  }
];

export const mockCases: Case[] = [
  {
    id: '1',
    title: 'Anterior Crown - Tooth #9',
    patient: mockPatients[0],
    dentist: mockUsers[0],
    lab: mockUsers[2],
    supervisor: mockUsers[4],
    designer: mockUsers[5],
    type: 'crown',
    subType: 'anterior',
    material: 'emax',
    description: 'Single anterior crown replacement for tooth #9 due to extensive caries',
    instructions: 'Natural A2 shade, subgingival margins, high translucency for esthetic match',
    priority: 'medium',
    status: 'in_progress',
    createdAt: new Date('2024-01-14T09:00:00'),
    dueDate: new Date('2024-01-28T17:00:00'),
    estimatedCompletion: new Date('2024-01-26T12:00:00'),
    files: mockFiles,
    progress: mockProgressSteps,
    notes: mockNotes,
    checklist: anteriorCrownChecklist.map(item => ({ ...item, id: '1-' + item.id })),
    financialInfo: {
      baseCost: 350,
      additionalCosts: [{ name: 'Rush Processing', amount: 50 }, { name: 'Custom Staining', amount: 25 }],
      totalCost: 425,
      currency: 'USD',
      paymentStatus: 'pending'
    },
    workHistory: [
      {
        id: '1-1',
        userId: '1',
        userName: 'Dr. Sarah Aldulaimy',
        userRole: 'dentist',
        action: 'Case Created',
        description: 'Initial case submission with patient details and requirements',
        timestamp: new Date('2024-01-14T09:00:00'),
        hoursSpent: 0.5
      },
      {
        id: '1-2',
        userId: '5',
        userName: 'Maya Patel',
        userRole: 'designer',
        action: 'Design Started',
        description: 'Began CAD design process based on scans',
        timestamp: new Date('2024-01-15T10:30:00'),
        hoursSpent: 2.5
      }
    ]
  },
  {
    id: '2',
    title: 'Posterior Crown - Tooth #30',
    patient: mockPatients[1],
    dentist: mockUsers[0],
    lab: mockUsers[3],
    supervisor: mockUsers[10],
    designer: mockUsers[9],
    type: 'crown',
    subType: 'posterior',
    material: 'zirconia',
    description: 'Posterior crown for molar tooth #30',
    instructions: 'Full contour zirconia, functional occlusion',
    priority: 'high',
    status: 'quality_check',
    createdAt: new Date('2024-01-10T14:30:00'),
    dueDate: new Date('2024-01-25T17:00:00'),
    estimatedCompletion: new Date('2024-01-24T15:00:00'),
    files: [],
    progress: [],
    notes: [],
    checklist: posteriorCrownChecklist.map(item => ({ ...item, id: '2-' + item.id })),
    financialInfo: {
      baseCost: 280,
      additionalCosts: [],
      totalCost: 280,
      currency: 'USD',
      paymentStatus: 'paid'
    },
    workHistory: [
      {
        id: '2-1',
        userId: '1',
        userName: 'Dr. Sarah Aldulaimy',
        userRole: 'dentist',
        action: 'Case Created',
        description: 'Posterior crown case submitted',
        timestamp: new Date('2024-01-10T14:30:00'),
        hoursSpent: 0.5
      }
    ]
  },
  {
    id: '3',
    title: 'Implant Crown - Tooth #19',
    patient: mockPatients[2],
    dentist: mockUsers[1],
    type: 'implant',
    material: 'zirconia',
    description: 'Implant-supported crown for molar replacement',
    instructions: 'Custom abutment required, emergence profile to match natural tooth',
    priority: 'medium',
    status: 'submitted',
    createdAt: new Date('2024-01-18T10:15:00'),
    dueDate: new Date('2024-02-08T17:00:00'), // 3-day minimum
    files: [],
    progress: [],
    notes: [],
    checklist: [],
    financialInfo: {
      baseCost: 450,
      additionalCosts: [{ name: 'Custom Abutment', amount: 150 }],
      totalCost: 600,
      currency: 'USD',
      paymentStatus: 'pending'
    },
    workHistory: [
      {
        id: '3-1',
        userId: '2',
        userName: 'Dr. Mohammed Taqqi',
        userRole: 'dentist',
        action: 'Case Created',
        description: 'Implant crown case submitted',
        timestamp: new Date('2024-01-18T10:15:00'),
        hoursSpent: 0.75
      }
    ]
  },
  {
    id: '4',
    title: 'Veneer Set - Teeth #6-11',
    patient: mockPatients[3],
    dentist: mockUsers[1],
    lab: mockUsers[2],
    supervisor: mockUsers[4],
    designer: mockUsers[5],
    type: 'veneer',
    material: 'emax',
    description: 'Anterior veneer set for cosmetic enhancement',
    instructions: 'Minimal preparation veneers, Hollywood white shade',
    priority: 'low',
    status: 'completed',
    createdAt: new Date('2024-01-05T16:00:00'),
    dueDate: new Date('2024-01-20T17:00:00'),
    actualCompletion: new Date('2024-01-19T14:30:00'),
    files: [],
    progress: [],
    notes: [],
    checklist: [],
    financialInfo: {
      baseCost: 1200,
      additionalCosts: [{ name: 'Custom Shade Matching', amount: 100 }],
      totalCost: 1300,
      currency: 'USD',
      paymentStatus: 'paid'
    },
    workHistory: [
      {
        id: '4-1',
        userId: '2',
        userName: 'Dr. Mohammed Taqqi',
        userRole: 'dentist',
        action: 'Case Created',
        description: 'Veneer set case submitted',
        timestamp: new Date('2024-01-05T16:00:00'),
        hoursSpent: 1.0
      },
      {
        id: '4-2',
        userId: '5',
        userName: 'Maya Patel',
        userRole: 'designer',
        action: 'Design Completed',
        description: 'Veneer design finalized',
        timestamp: new Date('2024-01-19T14:30:00'),
        hoursSpent: 8.5
      }
    ]
  }
];

export const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'message',
    title: 'Message from Supervisor',
    message: 'Please review the margin design for Case #1. The subgingival margin needs adjustment.',
    caseId: '1',
    caseTitle: 'Anterior Crown - Tooth #9',
    from: mockUsers[4], // Supervisor
    to: mockUsers[0], // Dr. Sarah Johnson
    createdAt: new Date('2024-01-20T14:30:00'),
    isRead: false
  },
  {
    id: '2',
    type: 'progress_update',
    title: 'Progress Update',
    message: 'Digital modeling has been completed for your case.',
    caseId: '1',
    caseTitle: 'Anterior Crown - Tooth #9',
    from: mockUsers[5], // Modeling Expert
    to: mockUsers[0], // Dr. Sarah Johnson
    createdAt: new Date('2024-01-19T16:45:00'),
    isRead: false,
    metadata: {
      stepName: 'Digital Modeling'
    }
  },
  {
    id: '3',
    type: 'status_change',
    title: 'Case Status Updated',
    message: 'Case has moved to Quality Check phase.',
    caseId: '2',
    caseTitle: 'Posterior Bridge - Teeth #13-15',
    from: mockUsers[3], // Precision Dental Lab
    to: mockUsers[0], // Dr. Sarah Johnson
    createdAt: new Date('2024-01-19T11:20:00'),
    isRead: true,
    metadata: {
      oldStatus: 'in_progress',
      newStatus: 'quality_check'
    }
  },
  {
    id: '4',
    type: 'comment',
    title: 'New Comment Added',
    message: 'Lab technician added a comment about shade matching requirements.',
    caseId: '1',
    caseTitle: 'Anterior Crown - Tooth #9',
    from: mockUsers[2], // TechLab Solutions
    to: mockUsers[0], // Dr. Sarah Johnson
    createdAt: new Date('2024-01-18T09:15:00'),
    isRead: true
  },
  {
    id: '5',
    type: 'file_upload',
    title: 'New File Uploaded',
    message: 'Progress photos have been uploaded for your review.',
    caseId: '1',
    caseTitle: 'Anterior Crown - Tooth #9',
    from: mockUsers[2], // TechLab Solutions
    to: mockUsers[0], // Dr. Sarah Johnson
    createdAt: new Date('2024-01-17T13:40:00'),
    isRead: true,
    metadata: {
      fileName: 'crown_progress_photos.jpg'
    }
  },
  {
    id: '6',
    type: 'case_assignment',
    title: 'Case Assigned',
    message: 'Your case has been assigned to TechLab Solutions.',
    caseId: '3',
    caseTitle: 'Implant Crown - Tooth #19',
    from: mockUsers[2], // TechLab Solutions
    to: mockUsers[1], // Dr. Michael Chen
    createdAt: new Date('2024-01-18T15:20:00'),
    isRead: false
  },
  {
    id: '7',
    type: 'case_completion',
    title: 'Case Completed',
    message: 'Your veneer set has been completed and is ready for pickup.',
    caseId: '4',
    caseTitle: 'Veneer Set - Teeth #6-11',
    from: mockUsers[2], // TechLab Solutions
    to: mockUsers[1], // Dr. Michael Chen
    createdAt: new Date('2024-01-19T14:30:00'),
    isRead: false
  },
  {
    id: '8',
    type: 'message',
    title: 'Message from Modeling Expert',
    message: 'The emergence profile looks excellent. Proceeding with final fabrication.',
    caseId: '3',
    caseTitle: 'Implant Crown - Tooth #19',
    from: mockUsers[5], // Modeling Expert
    to: mockUsers[1], // Dr. Michael Chen
    createdAt: new Date('2024-01-20T10:15:00'),
    isRead: false
  }
];