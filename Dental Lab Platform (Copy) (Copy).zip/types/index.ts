export interface User {
  id: string;
  name: string;
  role: 'dentist' | 'lab' | 'supervisor' | 'designer' | 'owner';
  avatar: string;
  practice: string;
  specialization: string;
  location: string;
  status?: 'pending' | 'approved' | 'rejected';
  licenseInfo?: {
    licenseNumber: string;
    issuingAuthority: string;
    expiryDate: Date;
    documents: string[];
  };
  registrationDate?: Date;
  approvedBy?: string;
  approvalDate?: Date;
  pricingTier?: 'standard' | 'premium' | 'enterprise' | 'custom';
  customPricing?: PricingOverride[];
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  phone: string;
  email: string;
  medicalHistory: string;
  allergies: string;
  notes: string;
  dentistId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkHistoryEntry {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  description: string;
  timestamp: Date;
  hoursSpent: number;
  attachments?: string[];
}

export interface Case {
  id: string;
  title: string;
  patient: Patient;
  type: string;
  material: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'draft' | 'submitted' | 'assigned' | 'in_progress' | 'quality_check' | 'completed' | 'delivered';
  dueDate: Date;
  description: string;
  instructions: string;
  dentist: User;
  lab?: User;
  designer?: User;
  supervisor?: User;
  createdAt: Date;
  updatedAt: Date;
  workHistory: WorkHistoryEntry[];
  attachments?: string[];
  notes?: string;
  pricing?: CasePricing;
  paymentStatus?: 'pending' | 'paid' | 'partial' | 'overdue';
  invoice?: Invoice;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'case_assigned' | 'case_completed' | 'case_update' | 'deadline_reminder' | 'quality_issue' | 'account_approved' | 'account_rejected' | 'payment_received' | 'payment_overdue';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  relatedCaseId?: string;
  relatedUserId?: string;
  priority: 'low' | 'medium' | 'high';
}

export interface AccountRequest {
  id: string;
  user: User;
  requestedRole: string;
  submittedAt: Date;
  reviewedAt?: Date;
  reviewedBy?: string;
  status: 'pending' | 'approved' | 'rejected';
  notes?: string;
  licenseDocuments: string[];
}

// Financial Management Types
export interface ServicePrice {
  id: string;
  serviceType: string;
  category: 'crown' | 'bridge' | 'implant' | 'denture' | 'orthodontic' | 'cosmetic' | 'surgical' | 'other';
  material: string;
  basePrice: number;
  labPrice: number;
  designerPrice: number;
  supervisorPrice: number;
  platformCommission: number; // percentage
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface PricingOverride {
  id: string;
  userId: string;
  serviceType: string;
  customPrice: number;
  discountPercentage?: number;
  effectiveFrom: Date;
  effectiveTo?: Date;
  reason: string;
  createdBy: string;
  createdAt: Date;
}

export interface CasePricing {
  id: string;
  caseId: string;
  servicePrice: ServicePrice;
  finalPrice: number;
  labFee: number;
  designerFee: number;
  supervisorFee: number;
  platformFee: number;
  discountApplied?: number;
  taxAmount?: number;
  totalAmount: number;
}

export interface Invoice {
  id: string;
  caseId: string;
  invoiceNumber: string;
  dentistId: string;
  labId?: string;
  designerId?: string;
  supervisorId?: string;
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  issuedAt: Date;
  dueDate: Date;
  paidAt?: Date;
  paymentMethod?: string;
  notes?: string;
}

export interface PaymentTransaction {
  id: string;
  invoiceId: string;
  amount: number;
  paymentMethod: 'credit_card' | 'bank_transfer' | 'paypal' | 'stripe' | 'cash';
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  transactionId: string;
  processedAt: Date;
  fees: number;
  netAmount: number;
}

export interface FinancialReport {
  id: string;
  reportType: 'revenue' | 'payments' | 'commissions' | 'user_earnings' | 'platform_summary';
  period: {
    from: Date;
    to: Date;
  };
  data: any;
  generatedAt: Date;
  generatedBy: string;
}

export interface PlatformFinancials {
  totalRevenue: number;
  monthlyRevenue: number;
  totalCommissions: number;
  monthlyCommissions: number;
  totalCases: number;
  activeCases: number;
  completedCases: number;
  averageCaseValue: number;
  topEarningUsers: Array<{
    userId: string;
    userName: string;
    role: string;
    earnings: number;
  }>;
  revenueByService: Array<{
    serviceType: string;
    revenue: number;
    count: number;
  }>;
  monthlyTrends: Array<{
    month: string;
    revenue: number;
    cases: number;
    newUsers: number;
  }>;
}