import { useState, useEffect } from 'react';
import { Notification } from '../types';
import { NotificationService } from '../utils/notificationService';
import { mockNotifications } from '../data/mockData';

export function useNotifications(userId: string) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Initialize with mock data
    const userNotifications = mockNotifications.filter(n => n.to.id === userId);
    setNotifications(userNotifications);

    // Set up listener for new notifications
    const handleNotificationsUpdate = (allNotifications: Notification[]) => {
      const userNotifications = allNotifications.filter(n => n.to.id === userId);
      setNotifications(userNotifications);
    };

    NotificationService.addListener(handleNotificationsUpdate);

    return () => {
      NotificationService.removeListener(handleNotificationsUpdate);
    };
  }, [userId]);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
    );
    NotificationService.markAsRead(notificationId);
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    NotificationService.markAllAsReadForUser(userId);
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
    NotificationService.deleteNotification(notificationId);
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification
  };
}