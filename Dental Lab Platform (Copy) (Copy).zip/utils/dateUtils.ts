// Utility functions for safe date handling and formatting

export const formatDate = (date: Date | string | undefined | null): string => {
  if (!date) return 'Not set';
  
  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // Check if the date is valid
    if (isNaN(dateObj.getTime())) {
      return 'Invalid date';
    }
    
    return dateObj.toLocaleDateString();
  } catch (error) {
    console.error('Error formatting date:', error);
    return 'Invalid date';
  }
};

export const formatDateTime = (date: Date | string | undefined | null): string => {
  if (!date) return 'Not set';
  
  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // Check if the date is valid
    if (isNaN(dateObj.getTime())) {
      return 'Invalid date';
    }
    
    return dateObj.toLocaleString();
  } catch (error) {
    console.error('Error formatting datetime:', error);
    return 'Invalid date';
  }
};

export const formatRelativeDate = (date: Date | string | undefined | null): string => {
  if (!date) return 'Not set';
  
  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // Check if the date is valid
    if (isNaN(dateObj.getTime())) {
      return 'Invalid date';
    }
    
    const now = new Date();
    const diffTime = now.getTime() - dateObj.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    
    return `${Math.floor(diffDays / 365)} years ago`;
  } catch (error) {
    console.error('Error formatting relative date:', error);
    return 'Invalid date';
  }
};

export const getDaysUntilDue = (dueDate: Date | string | undefined | null): number => {
  if (!dueDate) return 0;
  
  try {
    const dateObj = typeof dueDate === 'string' ? new Date(dueDate) : dueDate;
    
    // Check if the date is valid
    if (isNaN(dateObj.getTime())) {
      return 0;
    }
    
    const today = new Date();
    const diffTime = dateObj.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  } catch (error) {
    console.error('Error calculating days until due:', error);
    return 0;
  }
};

export const isValidDate = (date: any): boolean => {
  if (!date) return false;
  
  try {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj instanceof Date && !isNaN(dateObj.getTime());
  } catch (error) {
    return false;
  }
};

export const ensureDate = (date: Date | string | undefined | null): Date | null => {
  if (!date) return null;
  
  try {
    if (date instanceof Date) {
      return isNaN(date.getTime()) ? null : date;
    }
    
    const dateObj = new Date(date);
    return isNaN(dateObj.getTime()) ? null : dateObj;
  } catch (error) {
    console.error('Error ensuring date:', error);
    return null;
  }
};

export default {
  formatDate,
  formatDateTime,
  formatRelativeDate,
  getDaysUntilDue,
  isValidDate,
  ensureDate
};