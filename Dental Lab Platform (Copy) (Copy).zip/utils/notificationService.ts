import { Notification, User, Case } from '../types';

export class NotificationService {
  private static notifications: Notification[] = [];
  private static listeners: Array<(notifications: Notification[]) => void> = [];

  static addListener(callback: (notifications: Notification[]) => void) {
    this.listeners.push(callback);
  }

  static removeListener(callback: (notifications: Notification[]) => void) {
    this.listeners = this.listeners.filter(listener => listener !== callback);
  }

  private static notifyListeners() {
    this.listeners.forEach(listener => listener(this.notifications));
  }

  static createNotification(
    type: Notification['type'],
    title: string,
    message: string,
    caseId: string,
    caseTitle: string,
    from: User,
    to: User,
    metadata?: Notification['metadata']
  ): Notification {
    const notification: Notification = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      title,
      message,
      caseId,
      caseTitle,
      from,
      to,
      createdAt: new Date(),
      isRead: false,
      metadata
    };

    this.notifications.unshift(notification);
    this.notifyListeners();
    
    return notification;
  }

  static createStatusChangeNotification(
    caseItem: Case,
    oldStatus: Case['status'],
    newStatus: Case['status'],
    from: User,
    to: User
  ) {
    const statusMessages = {
      draft: 'moved to draft',
      submitted: 'submitted for review',
      assigned: 'assigned to lab',
      in_progress: 'started production',
      quality_check: 'moved to quality check',
      completed: 'completed',
      delivered: 'delivered'
    };

    return this.createNotification(
      'status_change',
      'Case Status Updated',
      `Case has been ${statusMessages[newStatus]}.`,
      caseItem.id,
      caseItem.title,
      from,
      to,
      { oldStatus, newStatus }
    );
  }

  static createProgressUpdateNotification(
    caseItem: Case,
    stepName: string,
    from: User,
    to: User
  ) {
    return this.createNotification(
      'progress_update',
      'Progress Update',
      `${stepName} has been completed for your case.`,
      caseItem.id,
      caseItem.title,
      from,
      to,
      { stepName }
    );
  }

  static createCommentNotification(
    caseItem: Case,
    from: User,
    to: User
  ) {
    return this.createNotification(
      'comment',
      'New Comment Added',
      `${from.name} added a comment to your case.`,
      caseItem.id,
      caseItem.title,
      from,
      to
    );
  }

  static createFileUploadNotification(
    caseItem: Case,
    fileName: string,
    from: User,
    to: User
  ) {
    return this.createNotification(
      'file_upload',
      'New File Uploaded',
      `New file "${fileName}" has been uploaded to your case.`,
      caseItem.id,
      caseItem.title,
      from,
      to,
      { fileName }
    );
  }

  static createCaseAssignmentNotification(
    caseItem: Case,
    from: User,
    to: User
  ) {
    return this.createNotification(
      'case_assignment',
      'Case Assigned',
      `Your case has been assigned to ${from.labName || from.name}.`,
      caseItem.id,
      caseItem.title,
      from,
      to
    );
  }

  static createCaseCompletionNotification(
    caseItem: Case,
    from: User,
    to: User
  ) {
    return this.createNotification(
      'case_completion',
      'Case Completed',
      `Your case has been completed and is ready for pickup.`,
      caseItem.id,
      caseItem.title,
      from,
      to
    );
  }

  static createMessageNotification(
    caseItem: Case,
    message: string,
    from: User,
    to: User
  ) {
    const title = from.labName?.includes('Supervisor') 
      ? 'Message from Supervisor'
      : from.labName?.includes('Modeling Expert')
      ? 'Message from Modeling Expert'
      : `Message from ${from.name}`;

    return this.createNotification(
      'message',
      title,
      message,
      caseItem.id,
      caseItem.title,
      from,
      to
    );
  }

  static getNotificationsForUser(userId: string): Notification[] {
    return this.notifications.filter(n => n.to.id === userId);
  }

  static markAsRead(notificationId: string) {
    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.isRead = true;
      this.notifyListeners();
    }
  }

  static markAllAsReadForUser(userId: string) {
    this.notifications
      .filter(n => n.to.id === userId)
      .forEach(n => n.isRead = true);
    this.notifyListeners();
  }

  static deleteNotification(notificationId: string) {
    this.notifications = this.notifications.filter(n => n.id !== notificationId);
    this.notifyListeners();
  }
}