// Service options extracted from CaseForm to ensure consistency across the platform
export const TREATMENT_CATEGORIES = {
  'fixed_prosthodontics': {
    label: 'Fixed Prosthodontics',
    treatments: {
      'crown': 'Crown',
      'bridge': 'Bridge',
      'inlay_onlay': 'Inlay/Onlay',
      'veneer': 'Veneer',
      'post_core': 'Post & Core',
      'tooth_reduction_guide': 'Tooth Reduction Guide'
    },
    requiresMaterial: true,
    requiresRetention: true
  },
  'removable_prosthodontics': {
    label: 'Removable Prosthodontics',
    treatments: {
      'full_denture': 'Full Denture',
      'partial_denture': 'Partial Denture',
      'telescopic_denture': 'Telescopic Denture',
      'immediate_denture': 'Immediate Denture',
      'try_in_denture': 'Try-In Denture',
      'primary_secondary_telescopic_crown': 'Primary/Secondary Telescopic Crown'
    },
    requiresMaterial: true,
    requiresRetention: false
  },
  'digital_services': {
    label: 'Digital Services',
    treatments: {
      'digital_try_in': 'Digital Try-In',
      'model_creation': 'Model Creation',
      'dsd': 'DSD',
      'smile_design_mockup': 'Smile Design Mockup'
    },
    requiresMaterial: false,
    requiresRetention: false
  },
  'implant_components': {
    label: 'Implant Components',
    treatments: {
      'custom_abutment': 'Custom Abutment',
      'stock_abutment': 'Stock Abutment',
      'screw_retained': 'Screw-Retained',
      'cement_retained': 'Cement-Retained',
      'connector_planning': 'Connector Planning'
    },
    requiresMaterial: true,
    requiresRetention: true,
    requiresAbutment: true
  },
  'orthodontics': {
    label: 'Orthodontics',
    treatments: {
      'clear_aligner': 'Clear Aligner',
      'retainer': 'Retainer',
      'digital_setup': 'Digital Setup'
    },
    requiresMaterial: false,
    requiresRetention: false
  },
  'surgical_appliances': {
    label: 'Surgical Appliances',
    treatments: {
      'surgical_guide': 'Surgical Guide',
      'bone_reduction_guide': 'Bone Reduction Guide',
      'implant_guide': 'Implant Guide',
      'sinus_lift': 'Sinus Lift',
      'tad_guide': 'TAD Guide'
    },
    requiresMaterial: false,
    requiresRetention: false
  },
  'other_services': {
    label: 'Other Services',
    treatments: {
      'whitening_tray': 'Whitening Tray',
      'fluoride_tray': 'Fluoride Tray',
      'custom_tray': 'Custom Tray',
      'scan_appliance': 'Scan Appliance',
      'copy_denture': 'Copy Denture'
    },
    requiresMaterial: true,
    requiresRetention: false
  }
};

export const MATERIALS = {
  'zirconia': 'Zirconia',
  'emax': 'E.max / Lithium Disilicate',
  'composite': 'Composite',
  'acrylic_pmma': 'Acrylic / PMMA',
  'resin_provisional': 'Resin (Provisional)',
  'resin_permanent': 'Resin (Permanent)',
  'nickel_chromium': 'Nickel Chromium',
  'pfm': 'PFM (Porcelain Fused to Metal)',
  'gold': 'Gold'
};

// Generate comprehensive service options for SearchableSelect components
export const generateServiceOptions = () => {
  const serviceOptions: Array<{ value: string; label: string; category: string }> = [];
  
  Object.entries(TREATMENT_CATEGORIES).forEach(([categoryKey, category]) => {
    Object.entries(category.treatments).forEach(([treatmentKey, treatmentLabel]) => {
      serviceOptions.push({
        value: treatmentKey,
        label: treatmentLabel,
        category: category.label
      });
    });
  });
  
  return serviceOptions;
};

// Generate material options for SearchableSelect components
export const generateMaterialOptions = () => {
  return Object.entries(MATERIALS).map(([key, label]) => ({
    value: key,
    label: label,
    category: 'Materials'
  }));
};

// Get service option by key
export const getServiceByKey = (key: string) => {
  for (const [categoryKey, category] of Object.entries(TREATMENT_CATEGORIES)) {
    if (category.treatments[key as keyof typeof category.treatments]) {
      return {
        key,
        label: category.treatments[key as keyof typeof category.treatments],
        category: category.label,
        categoryKey,
        requiresMaterial: category.requiresMaterial,
        requiresRetention: category.requiresRetention,
        requiresAbutment: (category as any).requiresAbutment
      };
    }
  }
  return null;
};

// Get material by key
export const getMaterialByKey = (key: string) => {
  return MATERIALS[key as keyof typeof MATERIALS] || null;
};

// Get all services by category
export const getServicesByCategory = (categoryKey: string) => {
  const category = TREATMENT_CATEGORIES[categoryKey as keyof typeof TREATMENT_CATEGORIES];
  if (!category) return [];
  
  return Object.entries(category.treatments).map(([key, label]) => ({
    value: key,
    label: label,
    category: category.label
  }));
};

// Priority options
export const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low Priority', category: 'Priority' },
  { value: 'medium', label: 'Medium Priority', category: 'Priority' },
  { value: 'high', label: 'High Priority', category: 'Priority' },
  { value: 'urgent', label: 'Urgent', category: 'Priority' }
];

// Gender options
export const GENDER_OPTIONS = [
  { value: 'male', label: 'Male', category: 'Gender' },
  { value: 'female', label: 'Female', category: 'Gender' },
  { value: 'other', label: 'Other', category: 'Gender' }
];

// Role options
export const ROLE_OPTIONS = [
  { value: '', label: 'All Roles', category: 'Filter' },
  { value: 'dentist', label: 'Dentist', category: 'Professional Roles' },
  { value: 'lab', label: 'Laboratory', category: 'Professional Roles' },
  { value: 'designer', label: 'Designer', category: 'Professional Roles' },
  { value: 'supervisor', label: 'Supervisor', category: 'Professional Roles' },
  { value: 'owner', label: 'Platform Owner', category: 'Administrative Roles' }
];

// Fabrication method options
export const FABRICATION_OPTIONS = [
  { value: 'cad_cam', label: 'CAD/CAM', category: 'Fabrication Method' },
  { value: 'traditional', label: 'Traditional', category: 'Fabrication Method' },
  { value: '3d_printing', label: '3D Printing', category: 'Fabrication Method' },
  { value: 'milling', label: 'Milling', category: 'Fabrication Method' }
];

// Common allergies for patient management
export const COMMON_ALLERGIES = [
  { value: 'penicillin', label: 'Penicillin', category: 'Antibiotics' },
  { value: 'amoxicillin', label: 'Amoxicillin', category: 'Antibiotics' },
  { value: 'sulfa_drugs', label: 'Sulfa Drugs', category: 'Antibiotics' },
  { value: 'aspirin', label: 'Aspirin', category: 'Pain Relievers' },
  { value: 'ibuprofen', label: 'Ibuprofen', category: 'Pain Relievers' },
  { value: 'codeine', label: 'Codeine', category: 'Pain Relievers' },
  { value: 'lidocaine', label: 'Lidocaine', category: 'Local Anesthetics' },
  { value: 'novocaine', label: 'Novocaine', category: 'Local Anesthetics' },
  { value: 'latex', label: 'Latex', category: 'Materials' },
  { value: 'nickel', label: 'Nickel', category: 'Materials' },
  { value: 'acrylic', label: 'Acrylic', category: 'Materials' },
  { value: 'eugenol', label: 'Eugenol', category: 'Dental Materials' },
  { value: 'dental_composite', label: 'Dental Composite', category: 'Dental Materials' },
  { value: 'amalgam', label: 'Amalgam', category: 'Dental Materials' },
  { value: 'peanuts', label: 'Peanuts', category: 'Food Allergies' },
  { value: 'shellfish', label: 'Shellfish', category: 'Food Allergies' },
  { value: 'dairy', label: 'Dairy', category: 'Food Allergies' },
  { value: 'contrast_dye', label: 'Contrast Dye', category: 'Imaging' },
  { value: 'iodine', label: 'Iodine', category: 'Imaging' }
];

export default {
  TREATMENT_CATEGORIES,
  MATERIALS,
  generateServiceOptions,
  generateMaterialOptions,
  getServiceByKey,
  getMaterialByKey,
  getServicesByCategory,
  PRIORITY_OPTIONS,
  GENDER_OPTIONS,
  ROLE_OPTIONS,
  FABRICATION_OPTIONS,
  COMMON_ALLERGIES
};